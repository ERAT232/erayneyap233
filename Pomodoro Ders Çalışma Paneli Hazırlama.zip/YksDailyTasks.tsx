import { useState, type FormEvent } from "react";
import { Check, ChevronDown, ClipboardList, Plus, Trash2 } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useYksDailyTasks } from "@/hooks/useYksDailyTasks";
import {
  YKS_DAILY_TASK_LIMIT,
  YKS_DAILY_TASK_TITLE_LIMIT,
} from "@/lib/yks/dailyTasksStorage";

export default function YksDailyTasks() {
  const auth = useAuth();
  const accountId = auth.user?.isEray ? auth.user.id : null;
  const { tasks, ready, todayKey, addTask, removeTask, toggleTask } =
    useYksDailyTasks(accountId);
  const [draft, setDraft] = useState("");
  const [expanded, setExpanded] = useState(false);
  const completedCount = tasks.filter(
    task => task.completedOn === todayKey
  ).length;
  const progress =
    tasks.length === 0 ? 0 : Math.round((completedCount / tasks.length) * 100);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (addTask(draft)) setDraft("");
  };

  return (
    <section className="space-y-4" aria-labelledby="yks-daily-tasks-title">
      <button
        type="button"
        aria-expanded={expanded}
        aria-controls="yks-daily-tasks-content"
        onClick={() => setExpanded(value => !value)}
        className="group relative mx-auto flex aspect-square w-full max-w-[350px] flex-col items-stretch justify-between gap-4 overflow-hidden rounded-2xl border border-[#bfd5b6] bg-gradient-to-br from-[#e6f0e3] via-[#fdf9ee] to-[#f5ead4] p-5 text-left shadow-[0_22px_48px_-28px_rgba(69,52,29,0.58)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_54px_-28px_rgba(69,52,29,0.65)] motion-reduce:transition-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-sage-ink sm:max-w-[380px] sm:rounded-[1.75rem] sm:p-7"
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-10 -top-16 h-64 w-64 rounded-full border border-white/55 bg-white/20 shadow-[0_0_0_18px_rgba(255,255,255,0.12),0_0_0_38px_rgba(255,255,255,0.08)] transition duration-500 group-hover:scale-110 motion-reduce:transition-none"
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute bottom-[-4.5rem] right-36 h-40 w-40 rounded-full bg-[#a8c99a]/25 blur-2xl"
        />

        <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start gap-3">
          <span className="relative grid h-16 w-16 shrink-0 place-items-center rounded-2xl border border-white/70 bg-white/60 text-sage-ink shadow-[0_12px_26px_-16px_rgba(90,66,34,0.65)] transition duration-500 group-hover:rotate-[-6deg] group-hover:scale-110 motion-reduce:transition-none sm:h-[4.5rem] sm:w-[4.5rem]">
            <ClipboardList
              className="h-8 w-8 sm:h-9 sm:w-9"
              strokeWidth={1.6}
              aria-hidden="true"
            />
            <span className="absolute -right-2 -top-2 grid h-8 w-8 place-items-center rounded-full border-2 border-[#fcf7e9] bg-[#5b7a54] text-white shadow-md">
              <Check className="h-4 w-4" aria-hidden="true" />
            </span>
          </span>
          <span className="min-w-0">
            <span className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-[#b8c8a9]/80 bg-white/50 px-3 py-1 text-[0.65rem] font-bold tracking-[0.18em] text-[#4d6a46]">
              BUGÜNÜN PLANI
            </span>
            <span
              id="yks-daily-tasks-title"
              className="block font-display text-xl font-bold leading-tight text-[#302719] sm:text-2xl"
            >
              Her Gün Yapılması Gerekenler
            </span>
            <span className="mt-2 block text-sm leading-relaxed text-[#685c48]">
              Bugünün planını burada yönet.
            </span>
            <span className="mt-3 flex flex-wrap gap-2">
              <span className="rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#4e6d49]">
                {ready
                  ? `${completedCount}/${tasks.length} tamamlandı`
                  : "Yükleniyor"}
              </span>
            </span>
            <span
              className="mt-3 block h-2 max-w-64 overflow-hidden rounded-full bg-white/75"
              role="progressbar"
              aria-label="Günlük görev ilerlemesi"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={progress}
            >
              <span
                className="block h-full rounded-full bg-gradient-to-r from-[#6e9c8c] to-[#9abf8d] transition-[width] duration-300 motion-reduce:transition-none"
                style={{ width: `${progress}%` }}
              />
            </span>
          </span>
        </span>

        <span className="relative z-10 flex w-full items-center justify-between border-t border-[#71866a]/20 pt-3">
          <span className="text-xs font-bold tracking-wide text-[#526f4b]">
            {expanded ? "KAPAT" : "GÖREVLERİ AÇ"}
          </span>
          <span className="grid h-11 w-11 place-items-center rounded-full border border-white/75 bg-white/60 text-[#526f4b] shadow-md transition duration-300 group-hover:scale-110 group-hover:bg-white motion-reduce:transition-none">
            <ChevronDown
              className={`h-5 w-5 transition-transform duration-500 motion-reduce:transition-none ${expanded ? "rotate-180" : ""}`}
              aria-hidden="true"
            />
          </span>
        </span>
      </button>

      <div
        id="yks-daily-tasks-content"
        aria-hidden={!expanded}
        inert={!expanded}
        className={`grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,0.8,0.3,1)] motion-reduce:transition-none ${expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
      >
        <div className="min-h-0 overflow-hidden">
          {expanded ? (
            <div className="yks-panel-open rounded-2xl border border-white/70 bg-white/35 p-2 shadow-[0_28px_60px_-38px_rgba(69,52,29,0.58)] sm:rounded-[1.75rem] sm:p-4">
              <div className="rounded-xl border border-white/80 bg-[#fbf8ef]/95 p-4 sm:rounded-2xl sm:p-6">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
                  <div>
                    <p className="smallcaps">
                      TÜRKİYE SAATİYLE HER GÜN YENİLENİR
                    </p>
                    <h2 className="mt-1 font-display text-2xl font-bold text-ink sm:text-3xl">
                      Bugünün görevleri
                    </h2>
                  </div>
                  <span className="rounded-full border border-[#bfd5b6] bg-[#e8f0e3] px-3 py-1.5 text-sm font-bold tabular-nums text-[#42613c]">
                    {completedCount}/{tasks.length} tamamlandı
                  </span>
                </div>

                <div
                  className="mb-5 h-2 overflow-hidden rounded-full bg-[#e7e0d1]"
                  role="progressbar"
                  aria-label="Günlük görev ilerlemesi"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={progress}
                >
                  <span
                    className="block h-full rounded-full bg-gradient-to-r from-[#6e9c8c] to-[#9abf8d] transition-[width] duration-300 motion-reduce:transition-none"
                    style={{ width: `${progress}%` }}
                  />
                </div>

                {!ready ? (
                  <p
                    className="rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-5 text-center text-sm text-ink-faint"
                    role="status"
                  >
                    Günlük görevler yükleniyor…
                  </p>
                ) : tasks.length === 0 ? (
                  <p className="rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-5 text-center text-sm text-ink-faint">
                    Henüz günlük görev eklenmedi. İlk görevini aşağıdan
                    ekleyebilirsin.
                  </p>
                ) : (
                  <ul className="space-y-2">
                    {tasks.map(task => {
                      const completed = task.completedOn === todayKey;
                      return (
                        <li
                          key={task.id}
                          className={`flex items-center gap-3 rounded-xl border px-3 py-3 transition-colors motion-reduce:transition-none ${completed ? "border-[#bfd5b6] bg-[#f0f6ed]" : "border-[#e5dac3] bg-white/65"}`}
                        >
                          <label className="flex min-w-0 flex-1 cursor-pointer items-center gap-3">
                            <input
                              type="checkbox"
                              checked={completed}
                              onChange={() => toggleTask(task.id)}
                              aria-label={`${task.title} görevini ${completed ? "bekliyor yap" : "tamamlandı işaretle"}`}
                              className="h-5 w-5 shrink-0 accent-[#5b7a54]"
                            />
                            <span
                              className={`min-w-0 break-words text-sm font-semibold ${completed ? "text-[#52734b]" : "text-ink"}`}
                            >
                              {task.title}
                            </span>
                          </label>
                          <span
                            className={`shrink-0 rounded-full px-2.5 py-1 text-[0.68rem] font-bold ${completed ? "bg-[#dcebd6] text-[#42613c]" : "bg-[#f5ead4] text-[#725b37]"}`}
                          >
                            {completed ? "Tamamlandı" : "Bekliyor"}
                          </span>
                          <button
                            type="button"
                            onClick={() => removeTask(task.id)}
                            aria-label={`${task.title} görevini sil`}
                            title="Görevi sil"
                            className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-[#e4c9be] bg-white/70 text-[#8f493b] transition hover:bg-[#fff5f0] hover:text-[#a33524] motion-reduce:transition-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#9c3b23]"
                          >
                            <Trash2 className="h-4 w-4" aria-hidden="true" />
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}

                <form
                  onSubmit={handleSubmit}
                  className="mt-4 flex flex-col gap-2 rounded-xl border border-[#e2d5bb] bg-gradient-to-r from-[#fff4df] to-[#f6f2e8] p-3 sm:flex-row"
                  aria-label="Günlük görev ekle"
                >
                  <label htmlFor="yks-daily-task-title" className="sr-only">
                    Günlük görev adı
                  </label>
                  <input
                    id="yks-daily-task-title"
                    value={draft}
                    onChange={event => setDraft(event.target.value)}
                    maxLength={YKS_DAILY_TASK_TITLE_LIMIT}
                    placeholder="Bugün yapılacak görevi yaz…"
                    disabled={!ready || tasks.length >= YKS_DAILY_TASK_LIMIT}
                    className="h-11 min-w-0 flex-1 rounded-lg border border-[#ddcda9] bg-white/90 px-4 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/15 disabled:opacity-60"
                  />
                  <button
                    type="submit"
                    disabled={
                      !ready ||
                      !draft.trim() ||
                      tasks.length >= YKS_DAILY_TASK_LIMIT
                    }
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#b45309] to-[#ce741a] px-5 text-sm font-bold text-[#fffaf0] shadow-[0_8px_16px_-9px_rgba(120,63,10,0.8)] transition hover:-translate-y-0.5 hover:brightness-105 motion-reduce:transition-none disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <Plus className="h-4 w-4" aria-hidden="true" />
                    Görev ekle
                  </button>
                </form>
                {tasks.length >= YKS_DAILY_TASK_LIMIT ? (
                  <p className="mt-2 text-xs text-ink-faint">
                    En fazla {YKS_DAILY_TASK_LIMIT} görev eklenebilir.
                  </p>
                ) : null}
                {tasks.length > 0 && completedCount === tasks.length ? (
                  <p
                    className="mt-3 inline-flex items-center gap-2 rounded-lg bg-[#e8f0e3] px-3 py-2 text-sm font-semibold text-[#42613c]"
                    role="status"
                  >
                    <Check className="h-4 w-4" aria-hidden="true" />
                    Bugünün tüm görevleri tamamlandı.
                  </p>
                ) : null}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}
