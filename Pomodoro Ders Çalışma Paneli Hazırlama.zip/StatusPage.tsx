import { Activity, BookOpen, Clock3, LockKeyhole } from "lucide-react";

const studyDays = [
  { day: "Pzt", hours: 1.8 },
  { day: "Sal", hours: 2.4 },
  { day: "Çar", hours: 1.2 },
  { day: "Per", hours: 3.1 },
  { day: "Cum", hours: 2.2 },
  { day: "Cmt", hours: 3.6 },
  { day: "Paz", hours: 1.5 },
];

const books = [
  { title: "Örnek Türkçe Soru Bankası", done: 172, total: 320 },
  { title: "Örnek Matematik Problemler", done: 94, total: 240 },
  { title: "Örnek Fen Denemeleri", done: 38, total: 160 },
];

export default function StatusPage() {
  return (
    <section className="page-section">
      <div className="page-intro">
        <div>
          <p className="eyebrow">ÖRNEK GÜNLÜK TAKİP</p>
          <h1>Eray Ne Durumda</h1>
          <p>Bu görünüm gerçek bir hesabın veya canlı çalışma durumunun verilerini içermez.</p>
        </div>
        <span className="sample-badge">ÖRNEK VERİ</span>
      </div>

      <div className="local-note status-disclaimer">
        <LockKeyhole size={19} />
        <p><strong>Canlı durum devre dışı.</strong> Statik Pages sürümünde oturum açan kullanıcı, ortak veritabanı veya başka cihazdan gelen durum bulunmaz.</p>
      </div>

      <div className="status-grid">
        <article className="paper-card study-chart-card">
          <div className="card-heading">
            <div><p className="eyebrow">SON 7 GÜN · ÖRNEK</p><h2><Activity size={19} /> Çalışma süresi</h2></div>
            <span className="tiny-label">15.8 SAAT</span>
          </div>
          <div className="study-chart" role="img" aria-label="Örnek haftalık çalışma süresi grafiği">
            {studyDays.map((item) => (
              <div className="chart-column" key={item.day}>
                <span className="chart-value">{item.hours.toFixed(1)}s</span>
                <div className="chart-bar-track"><span style={{ height: `${(item.hours / 4) * 100}%` }} /></div>
                <span className="chart-day">{item.day}</span>
              </div>
            ))}
          </div>
          <div className="chart-caption"><Clock3 size={14} /> Grafik, arayüzü göstermek için üretilmiş örnek değerler içerir.</div>
        </article>

        <article className="paper-card status-books-card">
          <div className="card-heading">
            <div><p className="eyebrow">ÖRNEK İLERLEME</p><h2><BookOpen size={19} /> Kitaplar</h2></div>
          </div>
          <div className="book-list">
            {books.map((book) => {
              const percent = Math.round((book.done / book.total) * 100);
              return (
                <div className="status-book" key={book.title}>
                  <div className="status-book-title"><strong>{book.title}</strong><b>%{percent}</b></div>
                  <span>{book.done} / {book.total} sayfa</span>
                  <div className="progress-track"><span style={{ width: `${percent}%` }} /></div>
                </div>
              );
            })}
          </div>
          <p className="book-note">Bu örnek kayıtlar ziyaretçiye özel değildir ve sunucuya gönderilmez.</p>
        </article>
      </div>
    </section>
  );
}
