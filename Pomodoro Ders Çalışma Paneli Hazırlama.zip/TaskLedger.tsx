import { useState } from "react";
import { Check, Minus, Plus, RotateCcw, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { PHASE_META, type Task } from "@/lib/pomodoro/types";
import { cn } from "@/lib/utils";

interface TaskLedgerProps {
  tasks: Task[];
  activeTaskId: string | null;
  onAdd: (title: string, estimate: number) => boolean;
  onSelect: (id: string | null) => void;
  onFinish: (id: string) => void;
  onUnfinish: (id: string) => void;
  onRemove: (id: string) => void;
}

const MAX_DOTS = 10;

function ViewChip({
  label,
  count,
  active,
  onClick,
}: {
  label: string;
  count: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-full border px-2.5 py-1 text-[0.68rem] font-semibold tracking-[0.1em] uppercase transition",
        active
          ? "border-amber-ink bg-[rgba(180,83,9,0.14)] text-amber-ink"
          : "border-[rgba(90,66,34,0.26)] text-ink-faint hover:border-ink-soft hover:text-ink-soft",
      )}
    >
      {label}
      <span className="ml-1.5 font-display text-[0.72rem] font-bold normal-case tabular-nums">{count}</span>
    </button>
  );
}

export default function TaskLedger({
  tasks,
  activeTaskId,
  onAdd,
  onSelect,
  onFinish,
  onUnfinish,
  onRemove,
}: TaskLedgerProps) {
  const [title, setTitle] = useState("");
  const [estimate, setEstimate] = useState(2);
  const [view, setView] = useState<"todo" | "done">("todo");

  const pending = tasks.filter(t => !t.done);
  const finished = tasks.filter(t => t.done);
  const listed = view === "todo" ? pending : finished;
  const remainingPomodoros = pending.reduce((sum, t) => sum + Math.max(0, t.estimate - t.completed), 0);

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!onAdd(title, estimate)) return;
    setTitle("");
    setEstimate(2);
    setView("todo");
  };

  return (
    <section className="plate relative rounded-md">
      <span className="screw top-2 left-2" />
      <span className="screw top-2 right-2" />

      <header className="border-b border-[rgba(90,66,34,0.18)] px-5 pt-4 pb-3">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-display text-lg leading-none font-bold text-ink">Çalışma Defteri</h2>
          <p className="text-right text-[0.66rem] leading-tight font-semibold tracking-[0.1em] text-ink-faint uppercase">
            {remainingPomodoros} pomodoro
            <br />
            sıraya bekliyor
          </p>
        </div>
        <div className="mt-3 flex items-center gap-1.5">
          <ViewChip label="Yapılmamış" count={pending.length} active={view === "todo"} onClick={() => setView("todo")} />
          <ViewChip label="Yapılmış" count={finished.length} active={view === "done"} onClick={() => setView("done")} />
        </div>
      </header>

      <form onSubmit={submit} className="flex items-center gap-2 px-4 py-3">
        <Input
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Hangi ders? örn. Tarih — 9. ünite"
          maxLength={80}
          className="h-10 flex-1 border-[rgba(90,66,34,0.28)] bg-[rgba(255,251,241,0.9)] text-sm placeholder:text-ink-faint focus-visible:border-amber-ink focus-visible:ring-amber-ink/25"
        />
        <div className="flex h-10 shrink-0 items-center gap-0.5 rounded-sm border border-[rgba(90,66,34,0.28)] bg-[rgba(255,251,241,0.9)] px-1">
          <button
            type="button"
            aria-label="Tahmini azalt"
            onClick={() => setEstimate(v => Math.max(1, v - 1))}
            className="grid h-7 w-6 shrink-0 place-items-center rounded-sm text-ink-soft hover:bg-[rgba(160,138,104,0.18)]"
          >
            <Minus className="h-3.5 w-3.5" />
          </button>
          <span
            className="w-7 shrink-0 text-center font-display text-sm leading-none font-bold whitespace-nowrap text-ink"
            title="Tahmini pomodoro"
          >
            {estimate}
          </span>
          <button
            type="button"
            aria-label="Tahmini artır"
            onClick={() => setEstimate(v => Math.min(24, v + 1))}
            className="grid h-7 w-6 shrink-0 place-items-center rounded-sm text-ink-soft hover:bg-[rgba(160,138,104,0.18)]"
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>
        <button
          type="submit"
          aria-label="Görevi ekle"
          className="grid h-10 w-10 shrink-0 place-items-center rounded-sm text-[#FDF8EC] transition hover:-translate-y-0.5 active:translate-y-0"
          style={{ backgroundColor: PHASE_META.focus.accent }}
        >
          <Plus className="h-5 w-5" />
        </button>
      </form>

      <ul className="ruled min-h-[7rem] px-2 pb-3">
        {tasks.length === 0 && (
          <li className="flex h-11 items-center px-3 text-sm text-ink-faint italic">
            Defter boş. Bir ders yaz, sonra saati başlat.
          </li>
        )}

        {tasks.length > 0 && listed.length === 0 && (
          <li className="flex h-11 items-center px-3 text-sm text-ink-faint italic">
            {view === "todo"
              ? "Sırada görev yok — defteri temizledin. Yeni bir ders ekleyebilirsin."
              : "Henüz tamamlanan görev yok."}
          </li>
        )}

        {listed.map(task => {
          const active = task.id === activeTaskId;
          const dots = Math.min(task.estimate, MAX_DOTS);
          const extra = task.estimate - dots;
          return (
            <li
              key={task.id}
              className={cn(
                "ink-in group flex h-11 items-center gap-2 rounded-sm px-2 transition-colors",
                active ? "bg-[rgba(180,83,9,0.10)]" : "hover:bg-[rgba(160,138,104,0.10)]",
              )}
            >
              <button
                type="button"
                onClick={() => onSelect(active ? null : task.id)}
                aria-pressed={active}
                title={active ? "Aktif görev" : "Aktif görev olarak seç"}
                className="grid h-5 w-5 shrink-0 place-items-center rounded-full border transition"
                style={{
                  borderColor: active ? PHASE_META.focus.accent : "rgba(109,91,69,0.5)",
                  backgroundColor: active ? PHASE_META.focus.accent : "transparent",
                }}
              >
                {active && <span className="h-1.5 w-1.5 rounded-full bg-[#FDF8EC]" />}
              </button>

              <button
                type="button"
                onClick={() => onSelect(active ? null : task.id)}
                className="min-w-0 flex-1 text-left"
              >
                <span
                  className={cn(
                    "line-clamp-1 text-[0.94rem] leading-tight",
                    task.done ? "strike-through text-ink-faint" : "text-ink",
                  )}
                >
                  {task.title}
                </span>
              </button>

              <span className="hidden items-center gap-[3px] sm:flex" title={`${task.completed}/${task.estimate}`}>
                {Array.from({ length: dots }, (_, i) => (
                  <span
                    key={i}
                    className="h-1.5 w-1.5 rounded-full border"
                    style={
                      i < task.completed
                        ? { borderColor: PHASE_META.focus.accent, backgroundColor: PHASE_META.focus.accent }
                        : { borderColor: "rgba(109,91,69,0.42)" }
                    }
                  />
                ))}
                {extra > 0 && <span className="text-[0.62rem] text-ink-faint">+{extra}</span>}
              </span>

              <button
                type="button"
                onClick={() => (task.done ? onUnfinish(task.id) : onFinish(task.id))}
                title={task.done ? "Tamamlanmış işaretini kaldır" : "Tamamlandı olarak işaretle"}
                className={cn(
                  "grid h-7 w-7 shrink-0 place-items-center rounded-sm text-ink-faint transition hover:bg-[rgba(91,122,84,0.16)] hover:text-sage-ink",
                  task.done && "text-sage-ink",
                )}
              >
                {task.done ? <RotateCcw className="h-3.5 w-3.5" /> : <Check className="h-4 w-4" />}
              </button>

              <button
                type="button"
                onClick={() => onRemove(task.id)}
                title="Görevi sil"
                className="grid h-7 w-7 shrink-0 place-items-center rounded-sm text-ink-faint opacity-0 transition group-hover:opacity-100 hover:bg-[rgba(156,59,35,0.14)] hover:text-destructive focus-visible:opacity-100"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
