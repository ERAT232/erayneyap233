import {
  bigint,
  boolean,
  date,
  index,
  int,
  longtext,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table; legacy provider rows are retained while password accounts are added. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  /** Legacy Manus identifier; password accounts use an internal random identifier. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  /** Canonical lower-case username. Null is permitted for retained legacy rows. */
  username: varchar("username", { length: 32 }).unique(),
  /** Shareable opaque identifier used to initiate a private one-to-one chat. */
  chatUserId: varchar("chatUserId", { length: 16 }).notNull().unique(),
  /** scrypt encoding with per-account salt; null is permitted for legacy rows. */
  passwordHash: varchar("passwordHash", { length: 255 }),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  /** Private-to-chat profile image; never part of the public profile API. */
  chatPhotoData: longtext("chatPhotoData"),
  /** Updated only when this participant enters CHEAT, not by presence polling. */
  lastChatSeenAt: timestamp("lastChatSeenAt"),
  /** Highest private chat message id explicitly marked read by this participant. */
  chatLastReadMessageId: int("chatLastReadMessageId"),
});

/** Opaque password-account sessions; only a hash of the browser token is persisted. */
export const accountSessions = mysqlTable("accountSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Public profile stores only an image and sanitized focus-history entries. */
export const publicProfiles = mysqlTable("publicProfiles", {
  id: int("id").autoincrement().primaryKey(),
  ownerOpenId: varchar("ownerOpenId", { length: 64 }).notNull().unique(),
  shareId: varchar("shareId", { length: 16 }).notNull().unique(),
  profilePhoto: longtext("profilePhoto"),
  sessionsJson: longtext("sessionsJson").notNull(),
  daysJson: longtext("daysJson").notNull(),
  isPublic: boolean("isPublic").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** The public, read-only snapshot of Eray's study workspace; never stores chat or account secrets. */
export const publicErayStudyWorkspaces = mysqlTable(
  "publicErayStudyWorkspaces",
  {
    id: int("id").primaryKey(),
    ownerUserId: int("ownerUserId")
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: "restrict" }),
    snapshotJson: longtext("snapshotJson").notNull(),
    pomodoroPhase: mysqlEnum("pomodoroPhase", ["focus", "short", "long"])
      .notNull()
      .default("focus"),
    pomodoroRunning: boolean("pomodoroRunning").notNull().default(false),
    pomodoroEndAt: bigint("pomodoroEndAt", { mode: "number" }),
    pomodoroRemainingSec: int("pomodoroRemainingSec").notNull().default(1_500),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  }
);

/** Plain-text member chat messages; only authenticated members can read or write them. */
export const memberChatMessages = mysqlTable("memberChatMessages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  message: varchar("message", { length: 500 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Private one-to-one conversation between exactly two registered users. */
export const chatConversations = mysqlTable(
  "chatConversations",
  {
    id: int("id").autoincrement().primaryKey(),
    memberOneId: int("memberOneId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    memberTwoId: int("memberTwoId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    memberOneLastReadMessageId: int("memberOneLastReadMessageId"),
    memberTwoLastReadMessageId: int("memberTwoLastReadMessageId"),
    memberOneLastSeenAt: timestamp("memberOneLastSeenAt"),
    memberTwoLastSeenAt: timestamp("memberTwoLastSeenAt"),
    /** Per-participant hide state; messages and the other participant's history remain intact. */
    memberOneHiddenAt: timestamp("memberOneHiddenAt"),
    memberTwoHiddenAt: timestamp("memberTwoHiddenAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("chatConversations_members_unique").on(
      table.memberOneId,
      table.memberTwoId
    ),
  ]
);

/** Message rows belong to a private conversation and identify their sender. */
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId")
    .notNull()
    .references(() => chatConversations.id, { onDelete: "cascade" }),
  senderId: int("senderId")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  message: varchar("message", { length: 500 }).notNull(),
  /** Small, compressed image attachment; loaded only through the participant-authorized image endpoint. */
  imageData: longtext("imageData"),
  /** Soft deletion leaves a visible tombstone for both participants and clears attachment bytes. */
  deletedAt: timestamp("deletedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Ephemeral request-rate buckets shared across all server instances. */
export const rateLimitBuckets = mysqlTable("rateLimitBuckets", {
  bucketKey: varchar("bucketKey", { length: 64 }).primaryKey(),
  hits: int("hits").notNull(),
  resetAt: timestamp("resetAt").notNull(),
});

/** Shared, read-only-on-home X/Twitter posts managed through the protected Arayüz page. */
export const homeTwitterItems = mysqlTable("homeTwitterItems", {
  id: int("id").autoincrement().primaryKey(),
  tweetId: varchar("tweetId", { length: 25 }).notNull().unique(),
  createdBy: int("createdBy")
    .notNull()
    .references(() => users.id, { onDelete: "restrict" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** Shared short messages displayed in the home page's moving text strip. */
export const homeTickerItems = mysqlTable("homeTickerItems", {
  id: int("id").autoincrement().primaryKey(),
  content: varchar("content", { length: 280 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/** One shared, replaceable home-page photo; the object bytes live in project storage. */
export const homeFeaturedPhoto = mysqlTable("homeFeaturedPhoto", {
  id: int("id").primaryKey(),
  storageKey: varchar("storageKey", { length: 255 }).notNull(),
  updatedBy: int("updatedBy").references(() => users.id, {
    onDelete: "set null",
  }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** One replaceable public stopwatch photo per Istanbul-local study date. */
export const dailyTimerPhotos = mysqlTable(
  "dailyTimerPhotos",
  {
    dayKey: date("dayKey", { mode: "string" }).notNull().primaryKey(),
    storageKey: varchar("storageKey", { length: 255 }).notNull(),
    uploadedBy: int("uploadedBy")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  }
);

/** One short shared note per account and Istanbul-local calendar day. */
export const dailyHomeNotes = mysqlTable(
  "dailyHomeNotes",
  {
    id: int("id").autoincrement().primaryKey(),
    noteDay: date("noteDay", { mode: "string" }).notNull(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    content: varchar("content", { length: 160 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("dailyHomeNotes_day_user_unique").on(
      table.noteDay,
      table.userId
    ),
  ]
);

/** Recipient-owned in-app notifications for private messages and shared Twitter links. */
export const userNotifications = mysqlTable(
  "userNotifications",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: mysqlEnum("kind", ["direct_message", "twitter_link"]).notNull(),
    actorLabel: varchar("actorLabel", { length: 80 }).notNull(),
    referenceId: int("referenceId").notNull(),
    relatedMessageId: int("relatedMessageId").references(
      () => chatMessages.id,
      { onDelete: "cascade" }
    ),
    readAt: timestamp("readAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("userNotifications_user_created_idx").on(
      table.userId,
      table.createdAt
    ),
    index("userNotifications_user_read_idx").on(table.userId, table.readAt),
    index("userNotifications_dm_message_idx").on(
      table.userId,
      table.kind,
      table.referenceId,
      table.relatedMessageId,
      table.readAt
    ),
  ]
);

/** One server-generated spin result per account and Istanbul calendar day. */
export const dailyWheelSpins = mysqlTable(
  "dailyWheelSpins",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    dayKey: date("dayKey", { mode: "string" }).notNull(),
    percentage: int("percentage").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("dailyWheelSpins_user_day_unique").on(
      table.userId,
      table.dayKey
    ),
    index("dailyWheelSpins_day_idx").on(table.dayKey),
  ]
);

export type PublicProfile = typeof publicProfiles.$inferSelect;
