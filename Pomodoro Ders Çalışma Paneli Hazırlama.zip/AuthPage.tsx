import { useState } from "react";
import { Eye, EyeOff, KeyRound, NotebookTabs } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  claimLegacyWorkspaceData,
  hasUnclaimedLegacyWorkspaceData,
  migrateLegacyWorkspaceData,
} from "@/lib/pomodoro/storage";

type AccessMode = "login" | "signup";

export default function AuthPage() {
  const [mode, setMode] = useState<AccessMode>("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [passwordAgain, setPasswordAgain] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [importLegacy, setImportLegacy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();

  const acceptAccount = (user: {
    id: number;
    username: string;
    name: string;
    role: "user" | "admin";
    chatUserId: string;
    isEray: boolean;
  }) => {
    if (importLegacy && !user.isEray) {
      const claimed = claimLegacyWorkspaceData(user.id);
      if (claimed && migrateLegacyWorkspaceData(user.id)) {
        toast.success("Eski çalışma verilerin bu hesaba taşındı");
      } else {
        toast.error("Bu tarayıcıdaki eski veriler bu hesaba taşınamadı", {
          description:
            "Eski veriler varsa başka bir hesap bunları zaten sahiplenmiş olabilir.",
        });
      }
    }
    utils.auth.me.setData(undefined, user);
    setLocation("/");
  };

  const login = trpc.auth.login.useMutation({
    onSuccess: acceptAccount,
    onError: result => setError(result.message),
  });
  const signup = trpc.auth.signup.useMutation({
    onSuccess: acceptAccount,
    onError: result => setError(result.message),
  });
  const pending = login.isPending || signup.isPending;
  const canImportLegacy =
    username.trim().toLowerCase() !== "eray" &&
    hasUnclaimedLegacyWorkspaceData();

  const switchMode = (nextMode: AccessMode) => {
    setMode(nextMode);
    setError(null);
    setPassword("");
    setPasswordAgain("");
    setImportLegacy(false);
  };

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    if (mode === "signup" && password !== passwordAgain) {
      setError("Şifreler birbiriyle aynı değil.");
      return;
    }
    const credentials = { username: username.trim(), password };
    try {
      if (mode === "signup") await signup.mutateAsync(credentials);
      else await login.mutateAsync(credentials);
    } catch {
      // The mutation's onError renders a Turkish error beside the form.
    }
  };

  return (
    <main className="desk-glow paper-grain relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-10">
      <div className="relative z-10 w-full max-w-md">
        <div className="mb-6 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-[rgba(90,66,34,0.32)] bg-[rgba(253,248,236,0.85)] text-amber-ink shadow-sm">
            <NotebookTabs className="h-6 w-6" strokeWidth={1.6} />
          </div>
          <p className="smallcaps mt-4">Odak Paneli</p>
          <h1 className="mt-1 font-display text-3xl font-bold tracking-tight text-ink">
            Masana giriş yap
          </h1>
          <p className="mt-2 text-sm text-ink-soft">
            Her kullanıcının çalışma defteri kendine özeldir.
          </p>
        </div>

        <section className="plate relative rounded-md p-5 sm:p-7">
          <span className="screw top-2 left-2" />
          <span className="screw top-2 right-2" />
          <div
            className="grid grid-cols-2 rounded-sm border border-[rgba(90,66,34,0.22)] bg-[rgba(233,215,179,0.38)] p-1"
            role="tablist"
            aria-label="Hesap işlemi"
          >
            <button
              type="button"
              role="tab"
              aria-selected={mode === "login"}
              onClick={() => switchMode("login")}
              className={`rounded-sm px-3 py-2 text-sm font-semibold transition ${mode === "login" ? "bg-[#fdf8ec] text-ink shadow-sm" : "text-ink-soft hover:text-ink"}`}
            >
              Giriş yap
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === "signup"}
              onClick={() => switchMode("signup")}
              className={`rounded-sm px-3 py-2 text-sm font-semibold transition ${mode === "signup" ? "bg-[#fdf8ec] text-ink shadow-sm" : "text-ink-soft hover:text-ink"}`}
            >
              Kayıt ol
            </button>
          </div>

          <form
            className="mt-5 space-y-4"
            onSubmit={event => void submit(event)}
          >
            <div className="space-y-1.5">
              <label
                htmlFor="account-username"
                className="text-sm font-semibold text-ink"
              >
                Kullanıcı adı
              </label>
              <input
                id="account-username"
                name="username"
                autoComplete="username"
                required
                minLength={3}
                maxLength={24}
                value={username}
                onChange={event => setUsername(event.target.value)}
                className="h-11 w-full rounded-sm border border-[rgba(90,66,34,0.32)] bg-[#fffdf7] px-3 text-base text-ink outline-none transition placeholder:text-ink-faint focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/20"
                placeholder="Kendi kullanıcı adını seç"
              />
              <p className="text-xs text-ink-faint">
                3–24 karakter; harf, sayı, nokta, tire ve alt çizgi
                kullanabilirsin.
              </p>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="account-password"
                className="text-sm font-semibold text-ink"
              >
                Şifre
              </label>
              <div className="relative">
                <input
                  id="account-password"
                  name="password"
                  autoComplete={
                    mode === "signup" ? "new-password" : "current-password"
                  }
                  required
                  minLength={10}
                  maxLength={128}
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={event => setPassword(event.target.value)}
                  className="h-11 w-full rounded-sm border border-[rgba(90,66,34,0.32)] bg-[#fffdf7] px-3 pr-11 text-base text-ink outline-none transition placeholder:text-ink-faint focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/20"
                  placeholder={
                    mode === "signup" ? "En az 10 karakter" : "Şifren"
                  }
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(value => !value)}
                  aria-label={showPassword ? "Şifreyi gizle" : "Şifreyi göster"}
                  className="absolute inset-y-0 right-0 grid w-11 place-items-center text-ink-faint hover:text-ink"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            {mode === "signup" && (
              <div className="space-y-1.5">
                <label
                  htmlFor="account-password-again"
                  className="text-sm font-semibold text-ink"
                >
                  Şifreyi tekrar yaz
                </label>
                <input
                  id="account-password-again"
                  name="passwordAgain"
                  autoComplete="new-password"
                  required
                  minLength={10}
                  maxLength={128}
                  type={showPassword ? "text" : "password"}
                  value={passwordAgain}
                  onChange={event => setPasswordAgain(event.target.value)}
                  className="h-11 w-full rounded-sm border border-[rgba(90,66,34,0.32)] bg-[#fffdf7] px-3 text-base text-ink outline-none transition focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/20"
                />
              </div>
            )}

            {canImportLegacy && (
              <label className="flex items-start gap-2.5 rounded-sm border border-[rgba(90,66,34,0.2)] bg-[rgba(233,215,179,0.3)] p-3 text-sm text-ink-soft">
                <input
                  type="checkbox"
                  checked={importLegacy}
                  onChange={event => setImportLegacy(event.target.checked)}
                  className="mt-0.5 accent-[#b45309]"
                />
                <span>
                  Bu tarayıcıdaki eski çalışma defterini, ayarları ve fotoğrafı
                  bu hesaba taşı.
                </span>
              </label>
            )}

            {mode === "signup" && (
              <p className="rounded-sm border border-[rgba(156,59,35,0.24)] bg-[rgba(156,59,35,0.06)] p-3 text-xs leading-relaxed text-ink-soft">
                Kullanıcı adını ve şifreni bir kez belirliyorsun. Şifre
                unutulursa sıfırlama veya hesap kurtarma yok; bilgilerini
                güvenli bir yere not et.
              </p>
            )}

            {error && (
              <p
                role="alert"
                className="rounded-sm border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive"
              >
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={pending}
              className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-sm bg-amber-ink px-4 text-sm font-semibold text-[#fffaf0] shadow-sm transition hover:-translate-y-0.5 hover:bg-[#934006] active:translate-y-0 disabled:cursor-wait disabled:opacity-60"
            >
              <KeyRound className="h-4 w-4" />
              {pending
                ? "Bekle…"
                : mode === "signup"
                  ? "Hesap oluştur"
                  : "Panele giriş yap"}
            </button>
          </form>
        </section>
        <p className="mt-4 text-center text-xs text-ink-faint">
          Paylaşım profilleri bağlantısı olan herkese açık kalır.
        </p>
      </div>
    </main>
  );
}
