import {
  DEFAULT_SETTINGS,
  DEFAULT_TIMER,
  LIMITS,
  clampInt,
  durationOf,
  type Phase,
  type SessionRecord,
  type Settings,
  type Task,
  type TimerState,
} from "./types";
import { PROFILE_PHOTO_STORAGE_KEY } from "@shared/publicProfile";
import {
  sanitizeStudyEntries,
  sanitizeStudySelection,
  type StudyEntry,
} from "@shared/studyTracking";
import {
  notifyErayPomodoroStatusChanged,
  notifyErayStudyDataChanged,
} from "@/lib/erayStudyEvents";

const NS = "odak-paneli/v1";
const LEGACY_CLAIM_KEY = `${NS}/legacy-claimed-account`;
let activeAccountId: string | null = null;

const SUFFIXES = {
  settings: "settings",
  tasks: "tasks",
  activeTaskId: "activeTaskId",
  timer: "timer",
  sessions: "sessions",
  history: "history",
  studyEntries: "studyEntries",
} as const;

type StorageField = keyof typeof SUFFIXES;

function keysForAccount(accountId: string | null) {
  const prefix = accountId
    ? `${NS}/accounts/${encodeURIComponent(accountId)}`
    : NS;
  return Object.fromEntries(
    Object.entries(SUFFIXES).map(([field, suffix]) => [
      field,
      `${prefix}/${suffix}`,
    ])
  ) as Record<StorageField, string>;
}

const LEGACY_KEYS = keysForAccount(null);

/** Set before the protected page mounts, so a user never reads another account's workspace. */
export function setStorageScope(accountId: number | string | null): void {
  activeAccountId = accountId === null ? null : String(accountId);
}

export function getProfilePhotoStorageKey(): string {
  return activeAccountId
    ? `${PROFILE_PHOTO_STORAGE_KEY}/accounts/${encodeURIComponent(activeAccountId)}`
    : PROFILE_PHOTO_STORAGE_KEY;
}

/** The current account's keys are resolved dynamically when read or cleared. */
export const KEYS = {
  get settings() {
    return keysForAccount(activeAccountId).settings;
  },
  get tasks() {
    return keysForAccount(activeAccountId).tasks;
  },
  get activeTaskId() {
    return keysForAccount(activeAccountId).activeTaskId;
  },
  get timer() {
    return keysForAccount(activeAccountId).timer;
  },
  get sessions() {
    return keysForAccount(activeAccountId).sessions;
  },
  get history() {
    return keysForAccount(activeAccountId).history;
  },
  get studyEntries() {
    return keysForAccount(activeAccountId).studyEntries;
  },
} as const;

export const MAX_SESSIONS = 400;

export function readJson<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function writeJson(key: string, value: unknown): void {
  try {
    const serialized = JSON.stringify(value);
    const existing = localStorage.getItem(key);
    if (existing === serialized) return;
    const isTimer = key === KEYS.timer;
    const previousTimer = isTimer ? readJson<TimerState>(key) : null;
    localStorage.setItem(key, serialized);
    if (isTimer) {
      notifyErayPomodoroStatusChanged();
      const nextTimer = value as TimerState;
      if (
        !previousTimer ||
        previousTimer.startedAt !== nextTimer.startedAt ||
        previousTimer.cycle !== nextTimer.cycle ||
        JSON.stringify(previousTimer.studySelection) !==
          JSON.stringify(nextTimer.studySelection)
      ) {
        notifyErayStudyDataChanged();
      }
    } else {
      notifyErayStudyDataChanged();
    }
  } catch {
    // Storage disabled (private mode / quota): the panel keeps working in memory.
  }
}

function num(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function bool(value: unknown, fallback: boolean): boolean {
  return typeof value === "boolean" ? value : fallback;
}

export function hasLegacyWorkspaceData(): boolean {
  try {
    return [...Object.values(LEGACY_KEYS), PROFILE_PHOTO_STORAGE_KEY].some(
      key => localStorage.getItem(key) !== null
    );
  } catch {
    return false;
  }
}

export function hasUnclaimedLegacyWorkspaceData(): boolean {
  try {
    return (
      hasLegacyWorkspaceData() &&
      localStorage.getItem(LEGACY_CLAIM_KEY) === null
    );
  } catch {
    return false;
  }
}

/** The first signed-in account on this browser claims legacy data before any other account can import it. */
export function claimLegacyWorkspaceData(accountId: number | string): boolean {
  try {
    if (!hasLegacyWorkspaceData()) return false;
    const normalizedId = String(accountId);
    const owner = localStorage.getItem(LEGACY_CLAIM_KEY);
    if (owner && owner !== normalizedId) return false;
    if (!owner) localStorage.setItem(LEGACY_CLAIM_KEY, normalizedId);
    return true;
  } catch {
    return false;
  }
}

/** Copy pre-account study keys into Eray's account namespace, retaining every source key. */
export function copyLegacyWorkspaceDataToAccount(
  accountId: number | string
): boolean {
  const normalizedId = String(accountId);
  let copied = false;
  try {
    if (!hasLegacyWorkspaceData()) return false;
    const owner = localStorage.getItem(LEGACY_CLAIM_KEY);
    if (owner && owner !== normalizedId) return false;
    if (!owner) localStorage.setItem(LEGACY_CLAIM_KEY, normalizedId);

    const targetKeys = keysForAccount(normalizedId);
    for (const field of Object.keys(SUFFIXES) as StorageField[]) {
      const value = localStorage.getItem(LEGACY_KEYS[field]);
      if (value === null || localStorage.getItem(targetKeys[field]) !== null)
        continue;
      localStorage.setItem(targetKeys[field], value);
      copied = true;
    }

    const legacyPhoto = localStorage.getItem(PROFILE_PHOTO_STORAGE_KEY);
    const accountPhotoKey = `${PROFILE_PHOTO_STORAGE_KEY}/accounts/${encodeURIComponent(normalizedId)}`;
    if (
      legacyPhoto !== null &&
      localStorage.getItem(accountPhotoKey) === null
    ) {
      localStorage.setItem(accountPhotoKey, legacyPhoto);
      copied = true;
    }
  } catch {
    return copied;
  }
  return copied;
}

export function hasLegacyWorkspaceDataForAccount(
  accountId: number | string
): boolean {
  try {
    return (
      localStorage.getItem(LEGACY_CLAIM_KEY) === String(accountId) &&
      hasLegacyWorkspaceData()
    );
  } catch {
    return false;
  }
}

/** Copy legacy keys only with explicit user action; remove each source key only after a successful copy. */
export function migrateLegacyWorkspaceData(
  accountId: number | string
): boolean {
  const normalizedId = String(accountId);
  if (!claimLegacyWorkspaceData(normalizedId)) return false;
  const targetKeys = keysForAccount(normalizedId);
  let copied = false;
  try {
    for (const field of Object.keys(SUFFIXES) as StorageField[]) {
      const source = LEGACY_KEYS[field];
      const destination = targetKeys[field];
      const value = localStorage.getItem(source);
      if (value === null || localStorage.getItem(destination) !== null)
        continue;
      localStorage.setItem(destination, value);
      localStorage.removeItem(source);
      copied = true;
    }

    const legacyPhoto = localStorage.getItem(PROFILE_PHOTO_STORAGE_KEY);
    const destinationPhoto = `${PROFILE_PHOTO_STORAGE_KEY}/accounts/${encodeURIComponent(normalizedId)}`;
    if (
      legacyPhoto !== null &&
      localStorage.getItem(destinationPhoto) === null
    ) {
      localStorage.setItem(destinationPhoto, legacyPhoto);
      localStorage.removeItem(PROFILE_PHOTO_STORAGE_KEY);
      copied = true;
    }
    if (copied && !hasLegacyWorkspaceData())
      localStorage.removeItem(LEGACY_CLAIM_KEY);
    return copied;
  } catch {
    return copied;
  }
}

function currentKeys(): Record<StorageField, string> {
  return keysForAccount(activeAccountId);
}

function numFrom<T>(source: T | null, key: keyof T, fallback: number): number {
  return source ? num(source[key], fallback) : fallback;
}

export function loadSettings(): Settings {
  const raw = readJson<Partial<Settings>>(currentKeys().settings) ?? {};
  return {
    focusMin: clampInt(
      numFrom(raw, "focusMin", DEFAULT_SETTINGS.focusMin),
      LIMITS.minutes.min,
      LIMITS.minutes.max
    ),
    shortMin: clampInt(
      numFrom(raw, "shortMin", DEFAULT_SETTINGS.shortMin),
      LIMITS.minutes.min,
      LIMITS.minutes.max
    ),
    longMin: clampInt(
      numFrom(raw, "longMin", DEFAULT_SETTINGS.longMin),
      LIMITS.minutes.min,
      LIMITS.minutes.max
    ),
    longBreakInterval: clampInt(
      numFrom(raw, "longBreakInterval", DEFAULT_SETTINGS.longBreakInterval),
      LIMITS.interval.min,
      LIMITS.interval.max
    ),
    autoStartNext: bool(raw.autoStartNext, DEFAULT_SETTINGS.autoStartNext),
    soundEnabled: bool(raw.soundEnabled, DEFAULT_SETTINGS.soundEnabled),
    notifyEnabled: bool(raw.notifyEnabled, DEFAULT_SETTINGS.notifyEnabled),
    dailyGoal: clampInt(
      numFrom(raw, "dailyGoal", DEFAULT_SETTINGS.dailyGoal),
      LIMITS.goal.min,
      LIMITS.goal.max
    ),
  };
}

export function loadTasks(): Task[] {
  const raw = readJson<Task[]>(currentKeys().tasks);
  if (!Array.isArray(raw)) return [];
  return raw
    .filter(
      (t): t is Task =>
        Boolean(t) && typeof t.id === "string" && typeof t.title === "string"
    )
    .map(t => ({
      id: t.id,
      title: t.title,
      estimate: clampInt(
        num(t.estimate, 1),
        LIMITS.estimate.min,
        LIMITS.estimate.max
      ),
      done: bool(t.done, false),
      completed: clampInt(num(t.completed, 0), 0, 9999),
      createdAt: num(t.createdAt, Date.now()),
    }));
}

const PHASES: Phase[] = ["focus", "short", "long"];
const DAY_KEY_RE = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/;

export function loadTimer(settings: Settings): TimerState {
  const raw = readJson<Partial<TimerState>>(currentKeys().timer);
  if (!raw)
    return { ...DEFAULT_TIMER, remainingSec: durationOf("focus", settings) };
  const phase = PHASES.includes(raw.phase as Phase)
    ? (raw.phase as Phase)
    : "focus";
  const fallbackSec = durationOf(phase, settings);
  const endAt = typeof raw.endAt === "number" ? raw.endAt : null;
  return {
    phase,
    running: bool(raw.running, false) && endAt !== null,
    endAt,
    remainingSec: clampInt(num(raw.remainingSec, fallbackSec), 0, 24 * 60 * 60),
    startedAt: typeof raw.startedAt === "number" ? raw.startedAt : null,
    cycle: clampInt(num(raw.cycle, 0), 0, 999),
    studySelection: sanitizeStudySelection(raw.studySelection),
  };
}

export function loadSessions(): SessionRecord[] {
  const raw = readJson<SessionRecord[]>(currentKeys().sessions);
  if (!Array.isArray(raw)) return [];
  return raw
    .filter(
      (s): s is SessionRecord =>
        Boolean(s) &&
        typeof s.id === "string" &&
        typeof s.endedAt === "number" &&
        PHASES.includes(s.phase)
    )
    .slice(0, MAX_SESSIONS);
}

export function loadStudyEntries(): StudyEntry[] {
  return sanitizeStudyEntries(readJson<unknown>(currentKeys().studyEntries));
}

export function loadHistory(): Record<
  string,
  { pomodoros: number; focusSeconds: number }
> {
  const raw = readJson<
    Record<string, { pomodoros?: number; focusSeconds?: number }>
  >(currentKeys().history);
  if (!raw || typeof raw !== "object") return {};
  const clean: Record<string, { pomodoros: number; focusSeconds: number }> = {};
  for (const [key, value] of Object.entries(raw)) {
    if (!DAY_KEY_RE.test(key)) continue;
    clean[key] = {
      pomodoros: clampInt(num(value?.pomodoros, 0), 0, 9999),
      focusSeconds: clampInt(num(value?.focusSeconds, 0), 0, 24 * 60 * 60),
    };
  }
  return clean;
}

export function loadActiveTaskId(tasks: Task[]): string | null {
  const raw = readJson<string | null>(currentKeys().activeTaskId);
  if (typeof raw !== "string") return null;
  return tasks.some(t => t.id === raw && !t.done) ? raw : null;
}
