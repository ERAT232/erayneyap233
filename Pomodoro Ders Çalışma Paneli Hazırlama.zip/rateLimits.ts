import { createHmac } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { bumpRateLimitBucket } from "../db";
import { ENV } from "./env";

export function makeRateLimitKey(...parts: string[]): string {
  const secret = ENV.cookieSecret;
  if (secret.length < 16) throw new Error("MANUS_JWT_SECRET is required for request rate limiting.");
  const derivedKey = createHmac("sha256", secret).update("odak-panel-rate-limits-v1").digest();
  return createHmac("sha256", derivedKey).update(parts.join("\u0000")).digest("hex");
}

export async function enforceDistributedRateLimit(input: {
  bucketKey: string;
  limit: number;
  windowMs: number;
  message: string;
}): Promise<void> {
  const bucket = await bumpRateLimitBucket({ bucketKey: input.bucketKey, windowMs: input.windowMs });
  if (bucket.count > input.limit) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: input.message });
  }
}
