import { describe, expect, it } from "vitest";
import {
  getIstanbulDayKey,
  getRecentStudyDays,
  sanitizeStudyEntries,
  summarizeStudyDay,
  type StudyEntry,
} from "../../shared/studyTracking";

const pomodoro: StudyEntry = {
  id: "p1",
  source: "pomodoro",
  subjectId: "math",
  subjectName: "Matematik",
  topicId: "functions",
  topicName: "Fonksiyonlar",
  seconds: 1500,
  dayKey: "2026-11-15",
  startedAt: Date.parse("2026-11-15T09:00:00+03:00"),
  endedAt: Date.parse("2026-11-15T09:25:00+03:00"),
};

const manual: StudyEntry = {
  id: "m1",
  source: "manual",
  subjectId: "math",
  subjectName: "Matematik",
  topicId: "functions",
  topicName: "Fonksiyonlar",
  seconds: 600,
  dayKey: "2026-11-15",
  startedAt: Date.parse("2026-11-15T11:00:00+03:00"),
  endedAt: Date.parse("2026-11-15T11:10:00+03:00"),
};

describe("daily study tracking", () => {
  it("assigns activity to the Europe/Istanbul calendar day", () => {
    expect(getIstanbulDayKey(Date.parse("2026-11-14T20:59:59.000Z"))).toBe("2026-11-14");
    expect(getIstanbulDayKey(Date.parse("2026-11-14T21:00:00.000Z"))).toBe("2026-11-15");
  });

  it("combines Pomodoro and manual time while preserving source and topic totals", () => {
    const summary = summarizeStudyDay([pomodoro, manual], "2026-11-15");
    expect(summary.totalSeconds).toBe(2100);
    expect(summary.pomodoroSeconds).toBe(1500);
    expect(summary.manualSeconds).toBe(600);
    expect(summary.entries).toHaveLength(2);
    expect(summary.subjects).toEqual([{
      id: "math",
      name: "Matematik",
      seconds: 2100,
      pomodoroSeconds: 1500,
      manualSeconds: 600,
    }]);
  });

  it("creates a seven-day chart from recorded entries without inventing study time", () => {
    const days = getRecentStudyDays([pomodoro, manual], "2026-11-15", 7);
    expect(days).toHaveLength(7);
    expect(days.at(-1)).toMatchObject({ dayKey: "2026-11-15", totalSeconds: 2100 });
    expect(days.slice(0, 6).every(day => day.totalSeconds === 0)).toBe(true);
  });

  it("filters malformed entries and keeps valid manual and Pomodoro records", () => {
    const clean = sanitizeStudyEntries([pomodoro, manual, { ...manual, seconds: 30 }, { ...manual, dayKey: "not-a-day" }]);
    expect(clean.map(entry => entry.id).sort()).toEqual(["m1", "p1"]);
  });
});
