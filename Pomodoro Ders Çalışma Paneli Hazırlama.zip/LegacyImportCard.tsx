import { useState } from "react";
import { ArchiveRestore } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  hasLegacyWorkspaceDataForAccount,
  migrateLegacyWorkspaceData,
} from "@/lib/pomodoro/storage";

export default function LegacyImportCard() {
  const { user } = useAuth();
  const [pending, setPending] = useState(false);
  if (!user || user.isEray || !hasLegacyWorkspaceDataForAccount(user.id))
    return null;

  const importData = () => {
    if (pending || !user) return;
    setPending(true);
    const copied = migrateLegacyWorkspaceData(user.id);
    if (copied) {
      toast.success("Eski çalışma verileri bu hesaba taşındı", {
        description:
          "Panel yeni hesaba ait görevleri, ayarları ve geçmişi açacak.",
      });
      window.location.reload();
      return;
    }
    setPending(false);
    toast.error("Eski veriler taşınamadı", {
      description: "Bu tarayıcıda taşınabilir eski veri kalmamış olabilir.",
    });
  };

  return (
    <section className="plate-flat rounded-md px-4 py-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-start gap-2.5">
          <ArchiveRestore className="mt-0.5 h-4 w-4 shrink-0 text-amber-ink" />
          <div>
            <h2 className="text-sm font-semibold text-ink">
              Bu tarayıcıda eski çalışma verileri var
            </h2>
            <p className="mt-0.5 text-xs text-ink-faint">
              İstersen bunları yalnızca bu hesaba taşı; başka hesaplar göremez.
            </p>
          </div>
        </div>
        <button
          type="button"
          disabled={pending}
          onClick={importData}
          className="rounded-sm bg-amber-ink px-3 py-2 text-xs font-semibold text-[#fffaf0] transition hover:bg-[#934006] disabled:opacity-60"
        >
          {pending ? "Taşınıyor…" : "Eski verileri bu hesaba taşı"}
        </button>
      </div>
    </section>
  );
}
