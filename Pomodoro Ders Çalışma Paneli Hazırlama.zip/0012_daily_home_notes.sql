CREATE TABLE `dailyHomeNotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`noteDay` date NOT NULL,
	`userId` int NOT NULL,
	`content` varchar(160) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dailyHomeNotes_id` PRIMARY KEY(`id`),
	CONSTRAINT `dailyHomeNotes_day_user_unique` UNIQUE(`noteDay`,`userId`)
);
--> statement-breakpoint
ALTER TABLE `dailyHomeNotes` ADD CONSTRAINT `dailyHomeNotes_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;