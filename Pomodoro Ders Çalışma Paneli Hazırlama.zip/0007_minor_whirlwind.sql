CREATE TABLE `chatConversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberOneId` int NOT NULL,
	`memberTwoId` int NOT NULL,
	`memberOneLastReadMessageId` int,
	`memberTwoLastReadMessageId` int,
	`memberOneLastSeenAt` timestamp,
	`memberTwoLastSeenAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chatConversations_id` PRIMARY KEY(`id`),
	CONSTRAINT `chatConversations_members_unique` UNIQUE(`memberOneId`,`memberTwoId`)
);
--> statement-breakpoint
CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`senderId` int NOT NULL,
	`message` varchar(500) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `chatUserId` varchar(16);--> statement-breakpoint
UPDATE `users` SET `chatUserId` = LOWER(SUBSTRING(REPLACE(UUID(), '-', ''), 1, 16)) WHERE `chatUserId` IS NULL;--> statement-breakpoint
ALTER TABLE `users` MODIFY `chatUserId` varchar(16) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_chatUserId_unique` UNIQUE(`chatUserId`);--> statement-breakpoint
ALTER TABLE `chatConversations` ADD CONSTRAINT `chatConversations_memberOneId_users_id_fk` FOREIGN KEY (`memberOneId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chatConversations` ADD CONSTRAINT `chatConversations_memberTwoId_users_id_fk` FOREIGN KEY (`memberTwoId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chatMessages` ADD CONSTRAINT `chatMessages_conversationId_chatConversations_id_fk` FOREIGN KEY (`conversationId`) REFERENCES `chatConversations`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chatMessages` ADD CONSTRAINT `chatMessages_senderId_users_id_fk` FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;
