import { useEffect, useRef } from "react";
import { ExternalLink, Trash2 } from "lucide-react";
import { canonicalTweetUrl } from "@shared/twitter";

export type TweetItem = { id: number; tweetId: string };
const X_WIDGETS_URL = "https://platform.twitter.com/widgets.js";

declare global {
  interface Window {
    twttr?: {
      widgets?: { load: (container?: HTMLElement) => void | Promise<void> };
    };
  }
}

export default function TweetEmbedList({
  items,
  onRemove,
  emptyMessage = "Henüz Twitter köşesine tweet eklenmedi.",
}: {
  items: TweetItem[];
  onRemove?: (id: number) => void;
  emptyMessage?: string;
}) {
  const embedRoot = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!items.length || !embedRoot.current) return;
    let active = true;
    const loadEmbeds = () => {
      if (active) window.twttr?.widgets?.load(embedRoot.current ?? undefined);
    };

    if (window.twttr?.widgets) {
      loadEmbeds();
      return () => { active = false; };
    }

    let script = document.querySelector<HTMLScriptElement>(`script[src="${X_WIDGETS_URL}"]`);
    const createdScript = !script;
    if (!script) {
      script = document.createElement("script");
      script.src = X_WIDGETS_URL;
      script.async = true;
      script.charset = "utf-8";
    }
    script.addEventListener("load", loadEmbeds);
    if (createdScript) document.body.appendChild(script);
    return () => {
      active = false;
      script?.removeEventListener("load", loadEmbeds);
    };
  }, [items]);

  if (!items.length) {
    return (
      <p className="mt-4 rounded-sm border border-dashed border-[rgba(90,66,34,0.24)] px-3 py-5 text-center text-sm text-ink-faint">
        {emptyMessage}
      </p>
    );
  }

  return (
    <div ref={embedRoot} className="mt-4 max-h-[min(68vh,38rem)] space-y-3 overflow-y-auto pr-1">
      {items.map(item => {
        const url = canonicalTweetUrl(item.tweetId);
        return (
          <article id={`twitter-item-${item.id}`} key={item.id} className="relative rounded-sm border border-[rgba(90,66,34,0.18)] bg-white/75 p-2">
            <div className="mb-1 flex justify-end gap-1">
              <a
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Tweeti X'te aç"
                className="grid h-8 w-8 place-items-center rounded-sm text-ink-faint transition hover:bg-amber-ink/10 hover:text-amber-ink"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
              {onRemove && (
                <button
                  type="button"
                  onClick={() => onRemove(item.id)}
                  aria-label="Tweeti Twitter köşesinden kaldır"
                  className="grid h-8 w-8 place-items-center rounded-sm text-ink-faint transition hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </div>
            <blockquote className="twitter-tweet" data-theme="light" data-dnt="true">
              <a href={url}>Tweeti görüntüle</a>
            </blockquote>
          </article>
        );
      })}
    </div>
  );
}
