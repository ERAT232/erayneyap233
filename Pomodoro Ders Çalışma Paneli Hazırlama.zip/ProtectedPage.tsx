import { useEffect, useState, type ReactNode } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { ensureCsrfToken } from "@/lib/csrf";
import {
  copyLegacyWorkspaceDataToAccount,
  setStorageScope,
} from "@/lib/pomodoro/storage";
import AuthPage from "@/pages/AuthPage";

type CsrfState = "loading" | "ready" | "error";

export default function ProtectedPage({ children }: { children: ReactNode }) {
  const auth = useAuth();
  const userId = auth.user?.id ?? null;
  const [scopedUserId, setScopedUserId] = useState<number | null>(null);
  const [csrfState, setCsrfState] = useState<CsrfState>("loading");
  const [retry, setRetry] = useState(0);

  useEffect(() => {
    let active = true;
    setCsrfState("loading");
    ensureCsrfToken()
      .then(() => {
        if (active) setCsrfState("ready");
      })
      .catch(() => {
        if (active) setCsrfState("error");
      });
    return () => {
      active = false;
    };
  }, [retry]);

  useEffect(() => {
    if (userId !== null && auth.user?.isEray)
      copyLegacyWorkspaceDataToAccount(userId);
    setStorageScope(userId);
    setScopedUserId(userId);
  }, [auth.user?.isEray, userId]);

  if (
    csrfState === "loading" ||
    auth.loading ||
    (userId !== null && scopedUserId !== userId)
  ) {
    return (
      <main className="desk-glow paper-grain grid min-h-screen place-items-center px-4">
        <p
          className="plate rounded-md px-6 py-4 text-sm text-ink-soft"
          role="status"
        >
          Güvenli hesap bağlantısı hazırlanıyor…
        </p>
      </main>
    );
  }

  if (csrfState === "error") {
    return (
      <main className="desk-glow paper-grain grid min-h-screen place-items-center px-4">
        <section className="plate max-w-md rounded-md p-6 text-center">
          <h1 className="font-display text-xl font-bold text-ink">
            Güvenli bağlantı kurulamadı
          </h1>
          <button
            type="button"
            onClick={() => setRetry(value => value + 1)}
            className="mt-4 rounded-sm bg-amber-ink px-4 py-2 text-sm font-semibold text-[#fffaf0]"
          >
            Yeniden dene
          </button>
        </section>
      </main>
    );
  }

  if (!auth.user) return <AuthPage />;
  return <>{children}</>;
}
