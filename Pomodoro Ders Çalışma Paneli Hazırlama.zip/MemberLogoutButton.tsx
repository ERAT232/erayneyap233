import { LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { ensureCsrfToken } from "@/lib/csrf";

type MemberLogoutButtonProps = {
  className?: string;
};

export default function MemberLogoutButton({
  className = "",
}: MemberLogoutButtonProps) {
  const auth = useAuth();
  const [, setLocation] = useLocation();

  if (!auth.isAuthenticated || auth.user?.isEray) return null;

  const handleLogout = async () => {
    try {
      await ensureCsrfToken();
      await auth.logout();
      toast.success("Hesaptan çıkış yapıldı.");
      setLocation("/");
    } catch (error) {
      toast.error("Çıkış yapılamadı", {
        description:
          error instanceof Error ? error.message : "Biraz sonra yeniden dene.",
      });
    }
  };

  return (
    <button
      type="button"
      onClick={() => void handleLogout()}
      disabled={auth.loading}
      aria-label="Hesaptan çıkış yap"
      title="Hesaptan çıkış yap"
      className={`inline-flex h-10 items-center justify-center gap-2 rounded-sm border border-[rgba(130,64,50,0.32)] bg-[rgba(255,248,241,0.9)] px-3.5 text-sm font-semibold text-[#804437] transition hover:border-[#804437] hover:bg-[#fae8df] disabled:cursor-not-allowed disabled:opacity-55 ${className}`}
    >
      <LogOut className="h-4 w-4" aria-hidden="true" />
      <span>{auth.loading ? "Çıkış yapılıyor…" : "Çıkış yap"}</span>
    </button>
  );
}
