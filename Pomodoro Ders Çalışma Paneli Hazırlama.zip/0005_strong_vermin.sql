ALTER TABLE `users` ADD `chatPhotoData` longtext;--> statement-breakpoint
ALTER TABLE `users` ADD `lastChatSeenAt` timestamp;