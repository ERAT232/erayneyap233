export const PROFILE_PHOTO_STORAGE_KEY = "odak-paneli/profile-photo/v1";

/** Public profile includes no task name, task id, account name, or e-mail. */
export interface PublicFocusSession {
  endedAt: number;
  minutes: number;
}

export interface PublicFocusDay {
  date: string;
  pomodoros: number;
  focusSeconds: number;
}
