import {
  Activity,
  ArrowLeft,
  BookOpen,
  CalendarDays,
  Check,
  ChevronDown,
  ClipboardList,
  Clock3,
  MessageCircle,
  PanelsTopLeft,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";
import YksCountdown from "@/components/YksCountdown";
import YksTimerPhotos from "@/components/YksTimerPhotos";
import MemberLogoutButton from "@/components/MemberLogoutButton";
import { useIstanbulTodayKey } from "@/hooks/useIstanbulTodayKey";
import { trpc } from "@/lib/trpc";
import { countCompletedDailyTasks } from "@shared/dailyTasks";
import {
  getIstanbulDayKey,
  includeManualStudyFocusHistory,
  getRecentStudyDays,
  summarizeStudyDay,
} from "@shared/studyTracking";
import {
  calculateTytAverages,
  calculateTytExamNets,
  calculateTytExamTotal,
  TYT_SUBJECTS,
} from "@shared/tyt";

function formatDuration(seconds: number): string {
  const safeSeconds = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(safeSeconds / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  if (hours > 0) return `${hours} sa ${minutes} dk`;
  if (minutes > 0) return `${minutes} dk`;
  return "0 dk";
}

function formatNet(value: number | null): string {
  return value === null
    ? "—"
    : value.toLocaleString("tr-TR", { maximumFractionDigits: 2 });
}

function formatDay(
  dayKey: string,
  options: Intl.DateTimeFormatOptions = {
    weekday: "short",
    day: "numeric",
    month: "short",
  }
): string {
  const date = new Date(`${dayKey}T12:00:00.000Z`);
  return new Intl.DateTimeFormat("tr-TR", {
    ...options,
    timeZone: "UTC",
  }).format(date);
}

function formatClock(epochMs: number): string {
  return new Intl.DateTimeFormat("tr-TR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Istanbul",
  }).format(new Date(epochMs));
}

export default function PublicErayStatus() {
  const workspace = trpc.erayStudyData.view.useQuery(undefined, {
    refetchInterval: 60_000,
  });
  const liveStatus = trpc.erayStudyData.status.useQuery(undefined, {
    refetchInterval: 3_000,
    retry: false,
  });
  const snapshot = workspace.data?.snapshot;
  const today = useIstanbulTodayKey();
  const [selectedDay, setSelectedDay] = useState(today);
  const [dailyTasksExpanded, setDailyTasksExpanded] = useState(false);
  const entries = snapshot?.pomodoro.studyEntries ?? [];
  const dailyTasks = snapshot?.dailyTasks ?? [];
  const completedDailyTasks = countCompletedDailyTasks(dailyTasks, today);
  const days = useMemo(
    () => getRecentStudyDays(entries, today, 7),
    [entries, today]
  );
  const summary = useMemo(
    () => summarizeStudyDay(entries, selectedDay),
    [entries, selectedDay]
  );
  const maxSeconds = Math.max(3_600, ...days.map(day => day.totalSeconds));
  const averages = calculateTytAverages(snapshot?.tyt.exams ?? []);
  const timer = liveStatus.data;
  const timerActive = Boolean(
    timer &&
      timer.running &&
      typeof timer.endAt === "number" &&
      timer.endAt > Date.now()
  );
  const status = !timerActive
    ? "Eray şu an çalışmıyor"
    : timer?.phase === "focus"
      ? "Eray şu an çalışıyor"
      : "Eray şu an molada";
  const totalStudySeconds = useMemo(() => {
    const history = includeManualStudyFocusHistory(
      snapshot?.pomodoro.history ?? {},
      snapshot?.pomodoro.studyEntries ?? []
    );
    return Object.values(history).reduce(
      (total, day) => total + day.focusSeconds,
      0
    );
  }, [snapshot?.pomodoro.history, snapshot?.pomodoro.studyEntries]);

  return (
    <main className="desk-glow paper-grain min-h-screen px-4 py-7 sm:px-6 sm:py-10">
      <div className="mx-auto w-full max-w-7xl">
        <header className="mb-6 flex flex-wrap items-center justify-between gap-4 border-b border-[rgba(90,66,34,0.2)] pb-5">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/75 bg-white/60 text-sage-ink shadow-sm">
              <Activity className="h-6 w-6" aria-hidden="true" />
            </span>
            <div>
              <p className="smallcaps">ERAY'IN HERKESE AÇIK ÇALIŞMA ALANI</p>
              <h1 className="font-display text-3xl font-bold text-ink sm:text-4xl">
                Eray Ne Durumda
              </h1>
            </div>
          </div>
          <nav className="flex flex-wrap gap-2" aria-label="Sayfa gezinme">
            <Link
              href="/"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.8)] px-3.5 text-sm font-semibold text-ink-soft"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Ana sayfa
            </Link>
            <Link
              href="/eray-bugun"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.8)] px-3.5 text-sm font-semibold text-ink-soft"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" /> Sohbet
            </Link>
            <Link
              href="/arayuz"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.8)] px-3.5 text-sm font-semibold text-ink-soft"
            >
              <PanelsTopLeft className="h-4 w-4" aria-hidden="true" /> Arayüz
            </Link>
            <MemberLogoutButton />
          </nav>
        </header>

        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[#d7c8a7] bg-gradient-to-r from-[#fff8e7] via-[#fbf7ed] to-[#e7efdf] p-4 sm:p-5">
          <div>
            <p className="smallcaps">CANLI DURUM</p>
            <p className="mt-1 inline-flex items-center gap-2 font-display text-xl font-bold text-ink">
              <span
                className={`h-3 w-3 rounded-full ${timerActive ? (timer?.phase === "focus" ? "bg-[#5b7a54]" : "bg-[#4c6b8a]") : "bg-ink-faint"}`}
              />
              {status}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <YksCountdown />
            <span className="rounded-xl border border-white/80 bg-white/70 px-4 py-2 text-sm font-semibold text-ink-soft">
              Toplam odak:{" "}
              <strong className="text-sage-ink">
                {formatDuration(totalStudySeconds)}
              </strong>
            </span>
          </div>
        </div>

        {workspace.isLoading ? (
          <p
            className="plate rounded-xl p-6 text-center text-sm text-ink-faint"
            role="status"
          >
            Eray'ın çalışma verileri yükleniyor…
          </p>
        ) : null}
        {workspace.isError ? (
          <p
            className="rounded-xl border border-[#e7c4b5] bg-[#fff5f0] p-5 text-sm text-[#8d4a3c]"
            role="alert"
          >
            Çalışma verileri şu anda yüklenemedi. Biraz sonra yeniden dene.
          </p>
        ) : null}
        {!workspace.isLoading && !workspace.isError && !snapshot ? (
          <p className="plate rounded-xl p-6 text-center text-sm leading-relaxed text-ink-soft">
            Eray'ın çalışma verileri henüz eşitlenmedi. Bu alan, Eray hesabı
            çalışma panelini açtığında otomatik güncellenecek.
          </p>
        ) : null}

        {snapshot ? (
          <div className="space-y-6">
            <section className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(19rem,0.8fr)]">
              <article
                className="plate relative overflow-hidden rounded-md p-4 sm:p-5"
                aria-labelledby="books-title"
              >
                <span className="screw top-2 left-2" />
                <span className="screw top-2 right-2" />
                <header className="mb-4 flex items-end justify-between gap-3">
                  <div>
                    <p className="smallcaps">OKUMA &amp; SORU BANKASI</p>
                    <h2
                      id="books-title"
                      className="mt-1 font-display text-2xl font-bold text-ink"
                    >
                      Kitap Takip
                    </h2>
                  </div>
                  <span className="rounded-full bg-[#e7eef6] px-3 py-1 text-xs font-semibold text-[#4d6c8a]">
                    {snapshot.books.length} kitap
                  </span>
                </header>
                {snapshot.books.length ? (
                  <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {snapshot.books.map(book => {
                      const completion = Math.round(
                        (book.solvedPages / book.totalPages) * 100
                      );
                      return (
                        <li
                          key={book.id}
                          className="flex gap-3 rounded-xl border border-[#d7e1e8] bg-white/70 p-3"
                        >
                          {book.cover ? (
                            <img
                              src={book.cover}
                              alt={`${book.title} kapak görseli`}
                              className="h-24 w-16 shrink-0 rounded-md border border-white object-contain shadow-sm"
                              loading="lazy"
                            />
                          ) : (
                            <span className="grid h-24 w-16 shrink-0 place-items-center rounded-md bg-[#e7eef6] text-[#4d6c8a]">
                              <BookOpen
                                className="h-6 w-6"
                                aria-hidden="true"
                              />
                            </span>
                          )}
                          <div className="min-w-0 flex-1">
                            <h3 className="line-clamp-2 font-semibold text-ink">
                              {book.title}
                            </h3>
                            <p className="mt-1 text-xs text-ink-faint">
                              {book.solvedPages.toLocaleString("tr-TR")} /{" "}
                              {book.totalPages.toLocaleString("tr-TR")} sayfa
                            </p>
                            <div className="mt-2 h-2 overflow-hidden rounded-full bg-[#e6ebee]">
                              <span
                                className="block h-full rounded-full bg-[#6e9c8c]"
                                style={{ width: `${completion}%` }}
                              />
                            </div>
                            <p className="mt-1 text-right text-xs font-bold text-[#507466]">
                              %{completion}
                            </p>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                ) : (
                  <p className="rounded-xl border border-dashed border-[#d7e1e8] bg-white/40 p-6 text-center text-sm text-ink-faint">
                    Henüz kitap eklenmedi.
                  </p>
                )}
              </article>

              <article
                className="plate relative overflow-hidden rounded-md p-4 sm:p-5"
                aria-labelledby="subjects-title"
              >
                <span className="screw top-2 left-2" />
                <span className="screw top-2 right-2" />
                <p className="smallcaps">YKS ÇALIŞMA DEFTERİ</p>
                <h2
                  id="subjects-title"
                  className="mt-1 font-display text-2xl font-bold text-ink"
                >
                  Dersler ve konular
                </h2>
                {snapshot.subjects.length ? (
                  <ul className="mt-4 space-y-3">
                    {snapshot.subjects.map(subject => (
                      <li
                        key={subject.id}
                        className="rounded-xl border border-[#e5dac3] bg-white/65 p-3"
                      >
                        <h3 className="font-semibold text-ink">
                          {subject.name}
                        </h3>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {subject.topics.length ? (
                            subject.topics.map(topic => (
                              <span
                                key={topic.id}
                                className="rounded-full bg-[#f5ead4] px-2.5 py-1 text-xs text-[#725b37]"
                              >
                                {topic.name}
                              </span>
                            ))
                          ) : (
                            <span className="text-xs text-ink-faint">
                              Konu eklenmedi
                            </span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-4 rounded-xl border border-dashed border-[#e5dac3] bg-white/40 p-6 text-center text-sm text-ink-faint">
                    Henüz ders eklenmedi.
                  </p>
                )}
              </article>
            </section>

            <section className="space-y-4" aria-labelledby="daily-tasks-title">
              <button
                type="button"
                aria-expanded={dailyTasksExpanded}
                aria-controls="daily-tasks-content"
                onClick={() => setDailyTasksExpanded(value => !value)}
                className="group relative mx-auto flex aspect-square w-full max-w-[350px] flex-col items-stretch justify-between gap-4 overflow-hidden rounded-2xl border border-[#bfd5b6] bg-gradient-to-br from-[#e6f0e3] via-[#fdf9ee] to-[#e9f2f1] p-5 text-left shadow-[0_22px_48px_-28px_rgba(69,52,29,0.58)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_54px_-28px_rgba(69,52,29,0.65)] motion-reduce:transition-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-sage-ink sm:max-w-[380px] sm:rounded-[1.75rem] sm:p-7"
              >
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute -right-10 -top-16 h-64 w-64 rounded-full border border-white/55 bg-white/20 shadow-[0_0_0_18px_rgba(255,255,255,0.12),0_0_0_38px_rgba(255,255,255,0.08)] transition duration-500 group-hover:scale-110 motion-reduce:transition-none"
                />
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute bottom-[-4.5rem] right-36 h-40 w-40 rounded-full bg-[#a8c99a]/25 blur-2xl"
                />

                <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start gap-3">
                  <span className="relative grid h-16 w-16 shrink-0 place-items-center rounded-2xl border border-white/70 bg-white/60 text-sage-ink shadow-[0_12px_26px_-16px_rgba(90,66,34,0.65)] transition duration-500 group-hover:rotate-[-6deg] group-hover:scale-110 motion-reduce:transition-none sm:h-[4.5rem] sm:w-[4.5rem]">
                    <ClipboardList
                      className="h-8 w-8 sm:h-9 sm:w-9"
                      strokeWidth={1.6}
                      aria-hidden="true"
                    />
                    <span className="absolute -right-2 -top-2 grid h-8 w-8 place-items-center rounded-full border-2 border-[#fcf7e9] bg-[#5b7a54] text-white shadow-md">
                      <Check className="h-4 w-4" aria-hidden="true" />
                    </span>
                  </span>
                  <span className="min-w-0">
                    <span className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-[#b8c8a9]/80 bg-white/50 px-3 py-1 text-[0.65rem] font-bold tracking-[0.18em] text-[#4d6a46]">
                      BUGÜNÜN PLANI · SALT OKUNUR
                    </span>
                    <span
                      id="daily-tasks-title"
                      className="block font-display text-xl font-bold leading-tight text-[#302719] sm:text-2xl"
                    >
                      Her Gün Yapılması Gerekenler
                    </span>
                    <span className="mt-2 block text-sm leading-relaxed text-[#685c48]">
                      Eray&apos;ın günlük görev ilerlemesini takip et.
                    </span>
                    <span className="mt-3 flex flex-wrap gap-2">
                      <span className="rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#4e6d49]">
                        {completedDailyTasks}/{dailyTasks.length} tamamlandı
                      </span>
                    </span>
                    <span
                      className="mt-3 block h-2 max-w-64 overflow-hidden rounded-full bg-white/75"
                      role="progressbar"
                      aria-label="Eray'ın günlük görev ilerlemesi"
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-valuenow={
                        dailyTasks.length === 0
                          ? 0
                          : Math.round(
                              (completedDailyTasks / dailyTasks.length) * 100
                            )
                      }
                    >
                      <span
                        className="block h-full rounded-full bg-gradient-to-r from-[#6e9c8c] to-[#9abf8d] transition-[width] duration-300 motion-reduce:transition-none"
                        style={{
                          width: `${dailyTasks.length === 0 ? 0 : Math.round((completedDailyTasks / dailyTasks.length) * 100)}%`,
                        }}
                      />
                    </span>
                  </span>
                </span>

                <span className="relative z-10 flex w-full items-center justify-between border-t border-[#71866a]/20 pt-3">
                  <span className="text-xs font-bold tracking-wide text-[#526f4b]">
                    {dailyTasksExpanded ? "KAPAT" : "GÖREVLERİ GÖR"}
                  </span>
                  <span className="grid h-11 w-11 place-items-center rounded-full border border-white/75 bg-white/60 text-[#526f4b] shadow-md transition duration-300 group-hover:scale-110 group-hover:bg-white motion-reduce:transition-none">
                    <ChevronDown
                      className={`h-5 w-5 transition-transform duration-500 motion-reduce:transition-none ${dailyTasksExpanded ? "rotate-180" : ""}`}
                      aria-hidden="true"
                    />
                  </span>
                </span>
              </button>

              <div
                id="daily-tasks-content"
                aria-hidden={!dailyTasksExpanded}
                inert={!dailyTasksExpanded}
                className={`grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,0.8,0.3,1)] motion-reduce:transition-none ${dailyTasksExpanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
              >
                <div className="min-h-0 overflow-hidden">
                  {dailyTasksExpanded ? (
                    <section className="yks-panel-open plate relative overflow-hidden rounded-md p-4 sm:p-5">
                      <span className="screw top-2 left-2" />
                      <span className="screw top-2 right-2" />
                      <div className="flex flex-wrap items-end justify-between gap-3">
                        <div>
                          <p className="smallcaps">
                            BUGÜNÜN PLANI · SALT OKUNUR
                          </p>
                          <h2 className="mt-1 font-display text-2xl font-bold text-ink">
                            Eray&apos;ın görevleri
                          </h2>
                          <p className="mt-1 text-sm text-ink-soft">
                            Durum Türkiye takvim gününe göre yenilenir.
                          </p>
                        </div>
                        <span className="rounded-full border border-[#bfd5b6] bg-[#e8f0e3] px-3 py-1.5 text-sm font-bold tabular-nums text-[#42613c]">
                          {completedDailyTasks}/{dailyTasks.length} tamamlandı
                        </span>
                      </div>

                      <div
                        className="mt-4 h-2 overflow-hidden rounded-full bg-[#e7e0d1]"
                        role="progressbar"
                        aria-label="Eray'ın günlük görev ilerlemesi"
                        aria-valuemin={0}
                        aria-valuemax={100}
                        aria-valuenow={
                          dailyTasks.length === 0
                            ? 0
                            : Math.round(
                                (completedDailyTasks / dailyTasks.length) * 100
                              )
                        }
                      >
                        <span
                          className="block h-full rounded-full bg-gradient-to-r from-[#6e9c8c] to-[#9abf8d] transition-[width] duration-300 motion-reduce:transition-none"
                          style={{
                            width: `${dailyTasks.length === 0 ? 0 : Math.round((completedDailyTasks / dailyTasks.length) * 100)}%`,
                          }}
                        />
                      </div>

                      {dailyTasks.length ? (
                        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                          {dailyTasks.map(task => {
                            const completed = task.completedOn === today;
                            return (
                              <li
                                key={task.id}
                                className={`flex min-w-0 items-center gap-3 rounded-xl border px-3 py-3 ${completed ? "border-[#bfd5b6] bg-[#f0f6ed]" : "border-[#e5dac3] bg-white/65"}`}
                              >
                                <span
                                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${completed ? "bg-[#dcebd6] text-[#42613c]" : "bg-[#f5ead4] text-[#8b795a]"}`}
                                  role="img"
                                  aria-label={
                                    completed ? "Tamamlandı" : "Bekliyor"
                                  }
                                >
                                  {completed ? (
                                    <Check
                                      className="h-4 w-4"
                                      aria-hidden="true"
                                    />
                                  ) : null}
                                </span>
                                <span className="min-w-0 flex-1 break-words text-sm font-semibold text-ink">
                                  {task.title}
                                </span>
                                <span
                                  className={`shrink-0 rounded-full px-2.5 py-1 text-[0.68rem] font-bold ${completed ? "bg-[#dcebd6] text-[#42613c]" : "bg-[#f5ead4] text-[#725b37]"}`}
                                >
                                  {completed ? "Tamamlandı" : "Bekliyor"}
                                </span>
                              </li>
                            );
                          })}
                        </ul>
                      ) : (
                        <p className="mt-4 rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-5 text-center text-sm text-ink-faint">
                          Eray henüz günlük görev eklemedi.
                        </p>
                      )}
                    </section>
                  ) : null}
                </div>
              </div>
            </section>

            <YksTimerPhotos mode="public" />

            <section className="grid items-start gap-5 lg:grid-cols-[minmax(0,1.2fr)_minmax(18rem,0.8fr)]">
              <article
                className="plate relative overflow-hidden rounded-md p-4 sm:p-5"
                aria-labelledby="weekly-study-title"
              >
                <span className="screw top-2 left-2" />
                <span className="screw top-2 right-2" />
                <div className="flex flex-wrap items-end justify-between gap-3">
                  <div>
                    <p className="smallcaps">GERÇEK KAYITLAR · SALT OKUNUR</p>
                    <h2
                      id="weekly-study-title"
                      className="mt-1 font-display text-2xl font-bold text-ink"
                    >
                      Son 7 gün
                    </h2>
                  </div>
                  <label className="flex aspect-square w-28 flex-col items-center justify-center gap-1 rounded-xl border border-[rgba(90,66,34,0.24)] bg-gradient-to-br from-white/80 to-[#e9f0e5]/75 p-2 text-center text-xs font-semibold text-ink-soft">
                    <CalendarDays
                      className="h-5 w-5 text-sage-ink"
                      aria-hidden="true"
                    />
                    <span className="text-[0.58rem] font-bold tracking-wide">
                      GÜNÜ SEÇ
                    </span>
                    <input
                      type="date"
                      aria-label="Görüntülenecek çalışma gününü seç"
                      value={selectedDay}
                      onChange={event => setSelectedDay(event.target.value)}
                      className="w-full min-w-0 bg-transparent text-center text-[0.58rem] font-semibold text-ink outline-none"
                    />
                  </label>
                </div>
                <div
                  className="mt-4 grid grid-cols-7 items-end gap-2"
                  aria-label="Son yedi günün toplam çalışma süreleri"
                >
                  {days.map(day => (
                    <button
                      key={day.dayKey}
                      type="button"
                      onClick={() => setSelectedDay(day.dayKey)}
                      aria-pressed={selectedDay === day.dayKey}
                      aria-label={`${formatDay(day.dayKey, { weekday: "long", day: "numeric", month: "long" })}: ${formatDuration(day.totalSeconds)}`}
                      className={`rounded-lg p-1 text-center transition ${selectedDay === day.dayKey ? "bg-[#e7f0e4] ring-1 ring-sage-ink/30" : "hover:bg-white/50"}`}
                    >
                      <span className="block truncate text-[0.62rem] font-semibold text-ink-faint">
                        {formatDuration(day.totalSeconds) === "0 dk"
                          ? "—"
                          : formatDuration(day.totalSeconds)}
                      </span>
                      <span className="mx-auto mt-1 flex h-28 w-full max-w-11 items-end overflow-hidden rounded-md bg-[#f0ece2]">
                        <span
                          className="block w-full rounded-t-md bg-gradient-to-t from-[#6e9c8c] to-[#b4cfb7]"
                          style={{
                            height: `${Math.max(day.totalSeconds > 0 ? 5 : 0, (day.totalSeconds / maxSeconds) * 100)}%`,
                          }}
                        />
                      </span>
                      <span className="mt-1 block text-[0.65rem] font-bold capitalize text-ink-soft">
                        {day.label}
                      </span>
                    </button>
                  ))}
                </div>
                <div className="mt-5 rounded-xl border border-[#e6dcc8] bg-white/65 p-4">
                  <div className="flex flex-wrap items-end justify-between gap-2">
                    <div>
                      <p className="smallcaps">SEÇİLEN GÜN</p>
                      <h3 className="mt-1 font-display text-xl font-bold capitalize text-ink">
                        {formatDay(selectedDay, {
                          weekday: "long",
                          day: "numeric",
                          month: "long",
                        })}
                      </h3>
                    </div>
                    <p className="font-display text-2xl font-bold tabular-nums text-sage-ink">
                      {formatDuration(summary.totalSeconds)}
                    </p>
                  </div>
                  <p className="mt-1 text-xs text-ink-faint">
                    Pomodoro {formatDuration(summary.pomodoroSeconds)} · Manuel{" "}
                    {formatDuration(summary.manualSeconds)} ·{" "}
                    {summary.entries.length} kayıt
                  </p>
                  {summary.entries.length ? (
                    <ul className="mt-3 space-y-2">
                      {summary.entries.map(entry => (
                        <li
                          key={entry.id}
                          className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-white/80 bg-white/55 px-3 py-2"
                        >
                          <div>
                            <span className="text-xs font-bold text-ink-faint">
                              {entry.subjectName}
                            </span>
                            <p className="text-sm font-semibold text-ink">
                              {entry.topicName}
                            </p>
                            <span className="text-[0.65rem] text-ink-faint">
                              {entry.source === "pomodoro"
                                ? `Pomodoro · ${formatClock(entry.endedAt)}`
                                : "Manuel kayıt"}
                            </span>
                          </div>
                          <span className="font-display text-lg font-bold tabular-nums text-sage-ink">
                            {formatDuration(entry.seconds)}
                          </span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="mt-3 text-sm text-ink-faint">
                      Bu gün için çalışma kaydı yok.
                    </p>
                  )}
                </div>
              </article>

              <article
                className="plate relative overflow-hidden rounded-md p-4 sm:p-5"
                aria-labelledby="pomodoro-history-title"
              >
                <span className="screw top-2 left-2" />
                <span className="screw top-2 right-2" />
                <p className="smallcaps">ODAK OTURUMLARI</p>
                <h2
                  id="pomodoro-history-title"
                  className="mt-1 font-display text-2xl font-bold text-ink"
                >
                  Pomodoro geçmişi
                </h2>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <div className="rounded-xl bg-[#e8f0e3] p-3">
                    <span className="text-xs text-ink-faint">Görev</span>
                    <p className="mt-1 font-display text-xl font-bold text-ink">
                      {snapshot.pomodoro.tasks.length}
                    </p>
                  </div>
                  <div className="rounded-xl bg-[#e8eef5] p-3">
                    <span className="text-xs text-ink-faint">Oturum</span>
                    <p className="mt-1 font-display text-xl font-bold text-ink">
                      {snapshot.pomodoro.sessions.length}
                    </p>
                  </div>
                </div>
                <h3 className="mt-4 font-semibold text-ink">Görevler</h3>
                {snapshot.pomodoro.tasks.length ? (
                  <ul className="mt-2 space-y-1.5">
                    {snapshot.pomodoro.tasks.map(task => (
                      <li
                        key={task.id}
                        className="flex items-center justify-between gap-3 rounded-lg bg-white/60 px-3 py-2 text-sm"
                      >
                        <span className="min-w-0 truncate text-ink">
                          {task.title}
                        </span>
                        <span className="shrink-0 text-xs text-ink-faint">
                          {task.done
                            ? "Tamamlandı"
                            : `${task.completed}/${task.estimate} tur`}
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-2 text-sm text-ink-faint">
                    Henüz görev eklenmedi.
                  </p>
                )}
                <h3 className="mt-5 font-semibold text-ink">Son oturumlar</h3>
                {snapshot.pomodoro.sessions.length ? (
                  <ul className="mt-2 space-y-1.5">
                    {snapshot.pomodoro.sessions.slice(0, 8).map(session => (
                      <li
                        key={session.id}
                        className="rounded-lg border border-white/75 bg-white/60 px-3 py-2"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="truncate text-sm font-semibold text-ink">
                            {session.taskTitle}
                          </span>
                          <span className="shrink-0 font-display font-bold tabular-nums text-sage-ink">
                            {formatDuration(session.actualSec)}
                          </span>
                        </div>
                        <p className="mt-0.5 text-[0.65rem] text-ink-faint">
                          {session.phase === "focus"
                            ? "Odak"
                            : session.phase === "short"
                              ? "Kısa mola"
                              : "Uzun mola"}{" "}
                          ·{" "}
                          {formatDay(getIstanbulDayKey(session.endedAt), {
                            day: "numeric",
                            month: "short",
                          })}{" "}
                          {formatClock(session.endedAt)}
                        </p>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-2 text-sm text-ink-faint">
                    Henüz oturum kaydı yok.
                  </p>
                )}
              </article>
            </section>

            <section className="grid items-start gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
              <article
                className="plate relative overflow-hidden rounded-md p-4 sm:p-5"
                aria-labelledby="tyt-data-title"
              >
                <span className="screw top-2 left-2" />
                <span className="screw top-2 right-2" />
                <p className="smallcaps">HEDEF NET · ORTALAMA NET</p>
                <h2
                  id="tyt-data-title"
                  className="mt-1 font-display text-2xl font-bold text-ink"
                >
                  TYT performansı
                </h2>
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full min-w-[28rem] text-left text-sm">
                    <thead>
                      <tr className="border-b border-[rgba(90,66,34,0.18)] text-xs text-ink-faint">
                        <th className="py-2">Ders</th>
                        <th className="py-2 text-right">Hedef</th>
                        <th className="py-2 text-right">Ortalama</th>
                        <th className="py-2 text-right">Soru</th>
                      </tr>
                    </thead>
                    <tbody>
                      {TYT_SUBJECTS.map(subject => (
                        <tr
                          key={subject.id}
                          className="border-b border-[rgba(90,66,34,0.1)]"
                        >
                          <th className="py-2 font-semibold text-ink">
                            {subject.label}
                          </th>
                          <td className="py-2 text-right tabular-nums">
                            {formatNet(snapshot.tyt.goals[subject.id])}
                          </td>
                          <td className="py-2 text-right tabular-nums">
                            {formatNet(averages[subject.id])}
                          </td>
                          <td className="py-2 text-right text-ink-faint">
                            {subject.questionCount}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <h3 className="mt-5 font-semibold text-ink">Denemeler</h3>
                {snapshot.tyt.exams.length ? (
                  <ul className="mt-2 space-y-2">
                    {[...snapshot.tyt.exams]
                      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
                      .map(exam => (
                        <li
                          key={exam.id}
                          className="rounded-xl border border-white/80 bg-white/60 p-3"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <h4 className="font-semibold text-ink">
                              {exam.name}
                            </h4>
                            <strong className="font-display text-lg tabular-nums text-sage-ink">
                              {formatNet(calculateTytExamTotal(exam.results))}{" "}
                              net
                            </strong>
                          </div>
                          <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-ink-faint sm:grid-cols-4">
                            {TYT_SUBJECTS.map(subject => (
                              <span key={subject.id}>
                                {subject.label}:{" "}
                                {formatNet(
                                  calculateTytExamNets(exam.results)[subject.id]
                                )}
                              </span>
                            ))}
                          </div>
                        </li>
                      ))}
                  </ul>
                ) : (
                  <p className="mt-2 text-sm text-ink-faint">
                    Henüz deneme eklenmedi.
                  </p>
                )}
              </article>
              <article
                className="plate relative overflow-hidden rounded-md p-4 sm:p-5"
                aria-labelledby="program-title"
              >
                <span className="screw top-2 left-2" />
                <span className="screw top-2 right-2" />
                <p className="smallcaps">YKS HEDEFİ</p>
                <h2
                  id="program-title"
                  className="mt-1 font-display text-2xl font-bold text-ink"
                >
                  Girmek istediği bölümler
                </h2>
                {snapshot.programs.length ? (
                  <ul className="mt-4 space-y-2">
                    {snapshot.programs.map(program => (
                      <li
                        key={program.id}
                        className="flex items-center justify-between gap-3 rounded-xl border border-[#bad6d5] bg-[#eff7f6] px-3 py-3"
                      >
                        <span className="font-semibold text-ink">
                          {program.name}
                        </span>
                        <span className="shrink-0 rounded-full bg-white/75 px-3 py-1 text-sm font-bold tabular-nums text-[#396466]">
                          {formatNet(program.requiredNet)} net
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-4 text-sm text-ink-faint">
                    Henüz hedef bölüm eklenmedi.
                  </p>
                )}
              </article>
            </section>
            <p className="rounded-xl border border-[#c5d6bd] bg-[#f2f7ef] px-4 py-3 text-center text-xs leading-relaxed text-[#4e6d49]">
              Bu sayfa herkes için salt okunurdur. Yalnız Eray kendi hesabından
              çalışma verilerini güncelleyebilir; hesap ve CHEAT mesajları
              gösterilmez.
            </p>
          </div>
        ) : null}
      </div>
    </main>
  );
}
