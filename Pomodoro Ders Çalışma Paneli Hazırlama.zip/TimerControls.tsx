import { Pause, Play, RotateCcw, SkipForward } from "lucide-react";
import { PHASE_META, type Phase } from "@/lib/pomodoro/types";
import { cn } from "@/lib/utils";

interface TimerControlsProps {
  phase: Phase;
  running: boolean;
  onToggle: () => void;
  onReset: () => void;
  onSkip: () => void;
}

export default function TimerControls({ phase, running, onToggle, onReset, onSkip }: TimerControlsProps) {
  const accent = PHASE_META[phase].accent;

  return (
    <div className="flex items-center justify-center gap-3">
      <button
        type="button"
        onClick={onReset}
        title="Sıfırla (R)"
        aria-label="Aşama süresini sıfırla"
        className="grid h-11 w-11 place-items-center rounded-full border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.8)] text-ink-soft transition hover:-translate-y-0.5 hover:border-ink-soft hover:text-ink active:translate-y-0"
      >
        <RotateCcw className="h-4.5 w-4.5" />
      </button>

      <button
        type="button"
        onClick={onToggle}
        aria-label={running ? "Duraklat" : "Başlat"}
        className={cn(
          "group relative flex h-16 min-w-[9.5rem] items-center justify-center gap-2.5 rounded-full px-8 font-semibold tracking-[0.16em] text-[#FDF8EC] uppercase transition",
          "shadow-[0_14px_24px_-14px_rgba(60,40,15,0.85),inset_0_1px_0_rgba(255,255,255,0.28)]",
          "hover:-translate-y-0.5 active:translate-y-0",
        )}
        style={{ backgroundColor: accent }}
      >
        {running ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 translate-x-[1px]" />}
        <span className="font-display text-sm">{running ? "Duraklat" : "Başlat"}</span>
      </button>

      <button
        type="button"
        onClick={onSkip}
        title="Atla (S)"
        aria-label="Mevcut aşamayı atla"
        className="grid h-11 w-11 place-items-center rounded-full border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.8)] text-ink-soft transition hover:-translate-y-0.5 hover:border-ink-soft hover:text-ink active:translate-y-0"
      >
        <SkipForward className="h-4.5 w-4.5" />
      </button>
    </div>
  );
}
