export type StudySource = "pomodoro" | "manual";

export interface StudySelection {
  subjectId: string;
  subjectName: string;
  topicId: string;
  topicName: string;
}

export interface StudyEntry extends StudySelection {
  id: string;
  source: StudySource;
  sessionId?: string;
  /** Actual focused/manual seconds; breaks are never included. */
  seconds: number;
  /** The study day is explicit so manual entries can be backfilled. */
  dayKey: string;
  startedAt: number;
  endedAt: number;
}

export interface StudySubjectTotal {
  id: string;
  name: string;
  seconds: number;
  pomodoroSeconds: number;
  manualSeconds: number;
}

export interface StudyDaySummary {
  dayKey: string;
  totalSeconds: number;
  pomodoroSeconds: number;
  manualSeconds: number;
  entries: StudyEntry[];
  subjects: StudySubjectTotal[];
}

export interface RecentStudyDay {
  dayKey: string;
  label: string;
  totalSeconds: number;
  subjects: StudySubjectTotal[];
}

export const MAX_STUDY_ENTRIES = 3000;
export const ISTANBUL_TIME_ZONE = "Europe/Istanbul";
const DAY_KEY_RE = /^\d{4}-\d{2}-\d{2}$/;
const DAY_KEY_FORMATTER = new Intl.DateTimeFormat("en-CA", {
  timeZone: ISTANBUL_TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});
const SHORT_WEEKDAY_FORMATTER = new Intl.DateTimeFormat("tr-TR", {
  timeZone: "UTC",
  weekday: "short",
});

export function isStudyDayKey(value: unknown): value is string {
  if (typeof value !== "string" || !DAY_KEY_RE.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day;
}

export function getIstanbulDayKey(value: number | Date = Date.now()): string {
  const date = typeof value === "number" ? new Date(value) : value;
  const parts = DAY_KEY_FORMATTER.formatToParts(date);
  const part = (type: string) => parts.find(item => item.type === type)?.value ?? "00";
  return `${part("year")}-${part("month")}-${part("day")}`;
}

export function sanitizeStudySelection(value: unknown): StudySelection | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Partial<StudySelection>;
  if (
    typeof candidate.subjectId !== "string" || !candidate.subjectId.trim()
    || typeof candidate.subjectName !== "string" || !candidate.subjectName.trim()
    || typeof candidate.topicId !== "string" || !candidate.topicId.trim()
    || typeof candidate.topicName !== "string" || !candidate.topicName.trim()
  ) return null;
  return {
    subjectId: candidate.subjectId.slice(0, 120),
    subjectName: candidate.subjectName.trim().slice(0, 80),
    topicId: candidate.topicId.slice(0, 120),
    topicName: candidate.topicName.trim().slice(0, 80),
  };
}

function sanitizeStudyEntry(value: unknown): StudyEntry | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Partial<StudyEntry>;
  const selection = sanitizeStudySelection(candidate);
  if (
    !selection
    || typeof candidate.id !== "string" || !candidate.id.trim()
    || (candidate.source !== "pomodoro" && candidate.source !== "manual")
    || typeof candidate.seconds !== "number" || !Number.isInteger(candidate.seconds) || candidate.seconds < 60 || candidate.seconds > 24 * 60 * 60
    || !isStudyDayKey(candidate.dayKey)
    || typeof candidate.startedAt !== "number" || !Number.isFinite(candidate.startedAt)
    || typeof candidate.endedAt !== "number" || !Number.isFinite(candidate.endedAt)
  ) return null;
  return {
    ...selection,
    id: candidate.id.slice(0, 120),
    source: candidate.source,
    ...(typeof candidate.sessionId === "string" && candidate.sessionId.trim()
      ? { sessionId: candidate.sessionId.slice(0, 120) }
      : {}),
    seconds: candidate.seconds,
    dayKey: candidate.dayKey,
    startedAt: candidate.startedAt,
    endedAt: candidate.endedAt,
  };
}

export function sanitizeStudyEntries(value: unknown): StudyEntry[] {
  if (!Array.isArray(value)) return [];
  return value
    .map(sanitizeStudyEntry)
    .filter((entry): entry is StudyEntry => entry !== null)
    .sort((a, b) => b.endedAt - a.endedAt)
    .slice(0, MAX_STUDY_ENTRIES);
}

export function reconcilePomodoroFocusHistory(
  history: Record<string, { pomodoros: number; focusSeconds: number }>,
  previous: StudyEntry | null,
  next: StudyEntry | null,
): Record<string, { pomodoros: number; focusSeconds: number }> {
  const deltas = new Map<string, number>();
  const recordDelta = (entry: StudyEntry | null, direction: -1 | 1) => {
    if (!entry || entry.source !== "pomodoro") return;
    deltas.set(entry.dayKey, (deltas.get(entry.dayKey) ?? 0) + direction * entry.seconds);
  };
  recordDelta(previous, -1);
  recordDelta(next, 1);

  if (![...deltas.values()].some(delta => delta !== 0)) return history;

  const updated = { ...history };
  deltas.forEach((delta, dayKey) => {
    if (delta === 0) return;
    const current = updated[dayKey] ?? { pomodoros: 0, focusSeconds: 0 };
    const focusSeconds = Math.max(0, current.focusSeconds + delta);
    if (focusSeconds === current.focusSeconds && updated[dayKey]) return;
    updated[dayKey] = { ...current, focusSeconds };
  });
  return updated;
}

export interface PomodoroHistorySession {
  phase: "focus" | "short" | "long";
  actualSec: number;
  completed: boolean;
  endedAt: number;
}

export function reconcilePomodoroSessionHistory(
  history: Record<string, { pomodoros: number; focusSeconds: number }>,
  previous: PomodoroHistorySession | null,
  next: PomodoroHistorySession | null,
): Record<string, { pomodoros: number; focusSeconds: number }> {
  const deltas = new Map<string, { pomodoros: number; focusSeconds: number }>();
  const recordDelta = (session: PomodoroHistorySession | null, direction: -1 | 1) => {
    if (!session || session.phase !== "focus") return;
    const key = getIstanbulDayKey(session.endedAt);
    const current = deltas.get(key) ?? { pomodoros: 0, focusSeconds: 0 };
    deltas.set(key, {
      pomodoros: current.pomodoros + direction * (session.completed ? 1 : 0),
      focusSeconds: current.focusSeconds + direction * session.actualSec,
    });
  };

  recordDelta(previous, -1);
  recordDelta(next, 1);
  if (![...deltas.values()].some(delta => delta.pomodoros !== 0 || delta.focusSeconds !== 0))
    return history;

  const updated = { ...history };
  deltas.forEach((delta, key) => {
    if (delta.pomodoros === 0 && delta.focusSeconds === 0) return;
    const current = updated[key] ?? { pomodoros: 0, focusSeconds: 0 };
    const pomodoros = Math.max(0, current.pomodoros + delta.pomodoros);
    const focusSeconds = Math.max(0, current.focusSeconds + delta.focusSeconds);
    if (updated[key] && current.pomodoros === pomodoros && current.focusSeconds === focusSeconds) return;
    updated[key] = { pomodoros, focusSeconds };
  });
  return updated;
}

export function includeManualStudyFocusHistory(
  history: Record<string, { pomodoros: number; focusSeconds: number }>,
  entries: readonly Pick<StudyEntry, "source" | "dayKey" | "seconds">[]
): Record<string, { pomodoros: number; focusSeconds: number }> {
  let updated: Record<
    string,
    { pomodoros: number; focusSeconds: number }
  > | null = null;

  for (const entry of entries) {
    if (
      entry.source !== "manual" ||
      !isStudyDayKey(entry.dayKey) ||
      !Number.isSafeInteger(entry.seconds) ||
      entry.seconds <= 0
    )
      continue;

    updated ??= { ...history };
    const current = updated[entry.dayKey] ?? { pomodoros: 0, focusSeconds: 0 };
    updated[entry.dayKey] = {
      ...current,
      focusSeconds: Math.min(86_400, current.focusSeconds + entry.seconds),
    };
  }

  return updated ?? history;
}

export function summarizeStudyDay(entries: StudyEntry[], dayKey: string): StudyDaySummary {
  const selectedEntries = entries
    .filter(entry => entry.dayKey === dayKey)
    .sort((a, b) => b.endedAt - a.endedAt);
  const bySubject = new Map<string, StudySubjectTotal>();
  let pomodoroSeconds = 0;
  let manualSeconds = 0;

  for (const entry of selectedEntries) {
    if (entry.source === "pomodoro") pomodoroSeconds += entry.seconds;
    else manualSeconds += entry.seconds;

    const existing = bySubject.get(entry.subjectId) ?? {
      id: entry.subjectId,
      name: entry.subjectName,
      seconds: 0,
      pomodoroSeconds: 0,
      manualSeconds: 0,
    };
    existing.seconds += entry.seconds;
    if (entry.source === "pomodoro") existing.pomodoroSeconds += entry.seconds;
    else existing.manualSeconds += entry.seconds;
    bySubject.set(entry.subjectId, existing);
  }

  const subjects = [...bySubject.values()].sort((a, b) => b.seconds - a.seconds);
  return {
    dayKey,
    totalSeconds: pomodoroSeconds + manualSeconds,
    pomodoroSeconds,
    manualSeconds,
    entries: selectedEntries,
    subjects,
  };
}

export function shiftIstanbulDayKey(dayKey: string, offset: number): string {
  if (!isStudyDayKey(dayKey)) return getIstanbulDayKey();
  const [year, month, day] = dayKey.split("-").map(Number);
  const shifted = new Date(Date.UTC(year, month - 1, day + offset));
  return `${shifted.getUTCFullYear()}-${String(shifted.getUTCMonth() + 1).padStart(2, "0")}-${String(shifted.getUTCDate()).padStart(2, "0")}`;
}

function shortDayLabel(dayKey: string): string {
  const [year, month, day] = dayKey.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day, 12));
  return SHORT_WEEKDAY_FORMATTER.format(date).replace(/\.$/, "");
}

export function getRecentStudyDays(entries: StudyEntry[], anchorDayKey = getIstanbulDayKey(), count = 7): RecentStudyDay[] {
  const safeCount = Math.max(1, Math.min(31, Math.floor(count)));
  const keys = Array.from({ length: safeCount }, (_, index) => shiftIstanbulDayKey(anchorDayKey, index - safeCount + 1));
  return keys.map(dayKey => {
    const summary = summarizeStudyDay(entries, dayKey);
    return {
      dayKey,
      label: shortDayLabel(dayKey),
      totalSeconds: summary.totalSeconds,
      subjects: summary.subjects,
    };
  });
}
