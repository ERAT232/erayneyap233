import { describe, expect, it } from "vitest";
import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { createContext } from "./context";

describe("account request context", () => {
  it("ignores the old platform/Preview login cookie for app account access", async () => {
    const req = {
      originalUrl: "/api/trpc/auth.me",
      path: "/api/trpc/auth.me",
      headers: { cookie: "webdev_app_session=legacy-preview-token" },
    } as unknown as CreateExpressContextOptions["req"];
    const res = {} as CreateExpressContextOptions["res"];

    const context = await createContext({ req, res } as unknown as CreateExpressContextOptions);
    expect(context.user).toBeNull();
  });
});
