import { describe, expect, it } from "vitest";
import { isValidChatImageData } from "./chatImage";

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

function makeJpeg(width: number, height: number, paddingBytes = 0): Buffer {
  const header = Buffer.from([
    0xff, 0xd8,
    0xff, 0xc0, 0x00, 0x0b,
    0x08,
    (height >> 8) & 0xff, height & 0xff,
    (width >> 8) & 0xff, width & 0xff,
    0x01, 0x01, 0x11, 0x00,
  ]);
  return Buffer.concat([header, Buffer.alloc(paddingBytes), Buffer.from([0xff, 0xd9])]);
}

function asDataUrl(bytes: Buffer): string {
  return `data:image/jpeg;base64,${bytes.toString("base64")}`;
}

describe("private chat image validation", () => {
  it("accepts a JPEG whose decoded bytes and pixel edges are within limits", () => {
    expect(isValidChatImageData(asDataUrl(makeJpeg(1600, 1200)))).toBe(true);
  });

  it("rejects an image larger than the server-enforced pixel edge", () => {
    expect(isValidChatImageData(asDataUrl(makeJpeg(1601, 1200)))).toBe(false);
    expect(isValidChatImageData(asDataUrl(makeJpeg(1200, 1601)))).toBe(false);
  });

  it("enforces the 3 MB decoded size even if a caller bypasses browser compression", () => {
    const headerAndEndBytes = makeJpeg(1, 1).length;
    const atLimit = makeJpeg(1, 1, MAX_IMAGE_BYTES - headerAndEndBytes);
    const aboveLimit = makeJpeg(1, 1, MAX_IMAGE_BYTES - headerAndEndBytes + 1);
    expect(atLimit.length).toBe(MAX_IMAGE_BYTES);
    expect(isValidChatImageData(asDataUrl(atLimit))).toBe(true);
    expect(isValidChatImageData(asDataUrl(aboveLimit))).toBe(false);
  });

  it("rejects non-JPEG, malformed, and non-canonical base64 data", () => {
    expect(isValidChatImageData("data:image/png;base64,Zm9v")).toBe(false);
    expect(isValidChatImageData("data:image/jpeg;base64,Zm9v")).toBe(false);
    expect(isValidChatImageData("data:image/jpeg;base64,Zm9v?=")).toBe(false);
  });
});
