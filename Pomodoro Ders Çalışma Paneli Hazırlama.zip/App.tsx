import { ArrowLeft, LockKeyhole } from "lucide-react";
import type { ReactNode } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ProtectedPage from "@/components/ProtectedPage";
import ErayStudySyncGate from "@/components/ErayStudySyncGate";
import MemberLogoutButton from "@/components/MemberLogoutButton";
import { PomodoroProvider } from "@/hooks/usePomodoro";
import { useAuth } from "@/_core/hooks/useAuth";
import NotFound from "@/pages/NotFound";
import PublicProfile from "@/pages/PublicProfile";
import ErayToday from "@/pages/ErayToday";
import Home from "@/pages/Home";
import PublicHome from "@/pages/PublicHome";
import PomodoroPage from "@/pages/Pomodoro";
import YksModePage from "@/pages/YksMode";
import ErayStatusPage from "@/pages/ErayStatus";
import PublicErayStatus from "@/pages/PublicErayStatus";
import Arayuz from "@/pages/Arayuz";
import { Link, Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function LoadingPage() {
  return (
    <main className="desk-glow paper-grain grid min-h-screen place-items-center px-4">
      <p
        className="plate rounded-md px-6 py-4 text-sm text-ink-soft"
        role="status"
      >
        Odak Paneli açılıyor…
      </p>
    </main>
  );
}

function OwnerOnlyPage() {
  return (
    <main className="desk-glow paper-grain grid min-h-screen place-items-center px-4 py-10">
      <section className="plate max-w-lg rounded-2xl p-6 text-center">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-[#f5e7c8] text-amber-ink">
          <LockKeyhole className="h-7 w-7" aria-hidden="true" />
        </span>
        <p className="smallcaps mt-4">ERAY'IN ÇALIŞMA ALANI</p>
        <h1 className="mt-1 font-display text-2xl font-bold text-ink">
          Bu bölüm yalnızca Eray'a açık
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-ink-soft">
          Üyeler Eray'ın çalışma verilerini görüntüleyebilir; Pomodoro başlatma
          ve YKS düzenleme işlemlerini yalnız Eray yapabilir.
        </p>
        <Link
          href="/"
          className="mt-5 inline-flex h-10 items-center gap-2 rounded-sm bg-amber-ink px-4 text-sm font-semibold text-white"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Ana sayfaya dön
        </Link>
        <MemberLogoutButton className="mt-3" />
      </section>
    </main>
  );
}

function OwnerShell({ children }: { children: ReactNode }) {
  return (
    <ProtectedPage>
      <ErayStudySyncGate>
        <PomodoroProvider>{children}</PomodoroProvider>
      </ErayStudySyncGate>
    </ProtectedPage>
  );
}

function HomeRoute() {
  const auth = useAuth();
  if (auth.loading) return <LoadingPage />;
  return auth.user?.isEray ? (
    <OwnerShell>
      <Home />
    </OwnerShell>
  ) : (
    <PublicHome />
  );
}

function StatusRoute() {
  const auth = useAuth();
  if (auth.loading) return <LoadingPage />;
  return auth.user?.isEray ? (
    <OwnerShell>
      <ErayStatusPage />
    </OwnerShell>
  ) : (
    <PublicErayStatus />
  );
}

function OwnerWorkspaceRoutes() {
  return (
    <OwnerShell>
      <Switch>
        <Route path="/pomodoro" component={PomodoroPage} />
        <Route path="/yks-mod" component={YksModePage} />
        <Route path="/eray-bugun" component={ErayToday} />
        <Route path="/arayuz" component={Arayuz} />
        <Route component={NotFound} />
      </Switch>
    </OwnerShell>
  );
}

function MemberWorkspaceRoutes() {
  return (
    <ProtectedPage>
      <Switch>
        <Route path="/eray-bugun" component={ErayToday} />
        <Route path="/arayuz" component={Arayuz} />
        <Route path="/pomodoro" component={OwnerOnlyPage} />
        <Route path="/yks-mod" component={OwnerOnlyPage} />
        <Route component={NotFound} />
      </Switch>
    </ProtectedPage>
  );
}

function PrivateRoutes() {
  const auth = useAuth();
  if (auth.loading) return <LoadingPage />;
  if (!auth.user)
    return (
      <ProtectedPage>
        <NotFound />
      </ProtectedPage>
    );
  return auth.user.isEray ? (
    <OwnerWorkspaceRoutes />
  ) : (
    <MemberWorkspaceRoutes />
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/paylasim/:shareId" component={PublicProfile} />
      <Route path="/" component={HomeRoute} />
      <Route path="/eray-ne-durumda" component={StatusRoute} />
      <Route component={PrivateRoutes} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
