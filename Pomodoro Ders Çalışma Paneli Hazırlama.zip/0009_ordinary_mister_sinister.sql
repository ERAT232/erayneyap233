CREATE TABLE `homeTwitterItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tweetId` varchar(25) NOT NULL,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `homeTwitterItems_id` PRIMARY KEY(`id`),
	CONSTRAINT `homeTwitterItems_tweetId_unique` UNIQUE(`tweetId`)
);
--> statement-breakpoint
ALTER TABLE `homeTwitterItems` ADD CONSTRAINT `homeTwitterItems_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;