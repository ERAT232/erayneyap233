import mysql from "mysql2/promise";
import { publicErayStudySnapshotSchema } from "./shared/erayStudyData";

const targetDay = "2026-11-16";
const expected = { focusSeconds: 12_590, historyPomodoros: 8, sessions: 9, entries: 7 };
const connection = await mysql.createConnection(process.env.DATABASE_URL!);
const dateParts = new Intl.DateTimeFormat("en-US", {
  timeZone: "Europe/Istanbul",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});
function istanbulDayKey(timestamp: number): string {
  const parts = Object.fromEntries(
    dateParts.formatToParts(new Date(timestamp)).map(part => [part.type, part.value])
  );
  return `${parts.year}-${parts.month}-${parts.day}`;
}
function daySessions(snapshot: ReturnType<typeof publicErayStudySnapshotSchema.parse>) {
  return snapshot.pomodoro.sessions.filter(
    session => istanbulDayKey(session.endedAt) === targetDay
  );
}
function dayEntries(snapshot: ReturnType<typeof publicErayStudySnapshotSchema.parse>) {
  return snapshot.pomodoro.studyEntries.filter(entry => entry.dayKey === targetDay);
}
function sameJson(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

try {
  await connection.beginTransaction();
  const [rows] = await connection.execute<any[]>(
    "SELECT `snapshotJson`, `pomodoroPhase`, `pomodoroRunning`, `pomodoroEndAt`, `pomodoroRemainingSec` FROM `publicErayStudyWorkspaces` WHERE `id` = 1 FOR UPDATE"
  );
  const row = rows[0];
  if (!row) throw new Error("Public Eray workspace row was not found; nothing changed.");

  const raw = typeof row.snapshotJson === "string" ? row.snapshotJson : String(row.snapshotJson);
  const snapshot = publicErayStudySnapshotSchema.parse(JSON.parse(raw));
  const beforeHistory = snapshot.pomodoro.history[targetDay];
  const sessions = daySessions(snapshot);
  const entries = dayEntries(snapshot);
  const sessionSeconds = sessions.reduce((sum, session) => sum + session.actualSec, 0);

  if (
    beforeHistory?.focusSeconds !== expected.focusSeconds ||
    beforeHistory.pomodoros !== expected.historyPomodoros ||
    sessions.length !== expected.sessions ||
    entries.length !== expected.entries ||
    sessionSeconds !== expected.focusSeconds ||
    sessions.some(session => session.phase !== "focus") ||
    entries.some(entry => entry.source !== "pomodoro")
  ) {
    throw new Error(
      `Current data no longer matches the approved reset scope; nothing changed. ` +
        JSON.stringify({
          day: targetDay,
          history: beforeHistory ?? null,
          sessions: sessions.length,
          sessionSeconds,
          entries: entries.length,
        })
    );
  }

  const statusBefore = {
    phase: row.pomodoroPhase,
    running: row.pomodoroRunning,
    endAt: row.pomodoroEndAt,
    remainingSec: row.pomodoroRemainingSec,
  };
  const unchanged = {
    settings: snapshot.pomodoro.settings,
    tasks: snapshot.pomodoro.tasks,
    activeTaskId: snapshot.pomodoro.activeTaskId,
    timer: snapshot.pomodoro.timer,
    subjects: snapshot.subjects,
    books: snapshot.books,
    programs: snapshot.programs,
    tyt: snapshot.tyt,
  };
  const otherHistory = Object.fromEntries(
    Object.entries(snapshot.pomodoro.history).filter(([key]) => key !== targetDay)
  );
  const otherSessions = snapshot.pomodoro.sessions.filter(
    session => istanbulDayKey(session.endedAt) !== targetDay
  );
  const otherEntries = snapshot.pomodoro.studyEntries.filter(
    entry => entry.dayKey !== targetDay
  );

  const next = structuredClone(snapshot);
  next.pomodoro.history[targetDay] = { pomodoros: 0, focusSeconds: 0 };
  next.pomodoro.sessions = next.pomodoro.sessions.filter(
    session => istanbulDayKey(session.endedAt) !== targetDay
  );
  next.pomodoro.studyEntries = next.pomodoro.studyEntries.filter(
    entry => entry.dayKey !== targetDay
  );
  const validated = publicErayStudySnapshotSchema.parse(next);

  const [update] = await connection.execute<any>(
    "UPDATE `publicErayStudyWorkspaces` SET `snapshotJson` = ?, `updatedAt` = CURRENT_TIMESTAMP WHERE `id` = 1",
    [JSON.stringify(validated)]
  );
  if (update.affectedRows !== 1)
    throw new Error("Expected exactly one workspace row to update; transaction rolled back.");

  const [verifyRows] = await connection.execute<any[]>(
    "SELECT `snapshotJson`, `pomodoroPhase`, `pomodoroRunning`, `pomodoroEndAt`, `pomodoroRemainingSec` FROM `publicErayStudyWorkspaces` WHERE `id` = 1"
  );
  const verifyRow = verifyRows[0];
  const verified = publicErayStudySnapshotSchema.parse(JSON.parse(String(verifyRow.snapshotJson)));
  const statusAfter = {
    phase: verifyRow.pomodoroPhase,
    running: verifyRow.pomodoroRunning,
    endAt: verifyRow.pomodoroEndAt,
    remainingSec: verifyRow.pomodoroRemainingSec,
  };
  const unchangedAfter = {
    settings: verified.pomodoro.settings,
    tasks: verified.pomodoro.tasks,
    activeTaskId: verified.pomodoro.activeTaskId,
    timer: verified.pomodoro.timer,
    subjects: verified.subjects,
    books: verified.books,
    programs: verified.programs,
    tyt: verified.tyt,
  };
  const otherHistoryAfter = Object.fromEntries(
    Object.entries(verified.pomodoro.history).filter(([key]) => key !== targetDay)
  );

  if (
    verified.pomodoro.history[targetDay]?.focusSeconds !== 0 ||
    verified.pomodoro.history[targetDay]?.pomodoros !== 0 ||
    daySessions(verified).length !== 0 ||
    dayEntries(verified).length !== 0 ||
    !sameJson(otherHistory, otherHistoryAfter) ||
    !sameJson(otherSessions, verified.pomodoro.sessions) ||
    !sameJson(otherEntries, verified.pomodoro.studyEntries) ||
    !sameJson(unchanged, unchangedAfter) ||
    !sameJson(statusBefore, statusAfter)
  ) {
    throw new Error("Post-update verification failed; transaction rolled back.");
  }

  await connection.commit();
  console.log(
    JSON.stringify({
      updated: true,
      date: targetDay,
      removedFocusSessions: sessions.length,
      removedStudyEntries: entries.length,
      removedFocusSeconds: expected.focusSeconds,
      focusAfterSeconds: 0,
      otherDatesPreserved: true,
      pomodoroTimerAndLiveStatusPreserved: true,
    })
  );
} catch (error) {
  await connection.rollback();
  throw error;
} finally {
  await connection.end();
}
