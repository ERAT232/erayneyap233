CREATE TABLE `homeFeaturedPhoto` (
	`id` int NOT NULL,
	`storageKey` varchar(255) NOT NULL,
	`updatedBy` int,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `homeFeaturedPhoto_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `homeFeaturedPhoto` ADD CONSTRAINT `homeFeaturedPhoto_updatedBy_users_id_fk` FOREIGN KEY (`updatedBy`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;