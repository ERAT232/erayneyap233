export const TYT_SUBJECTS = [
  { id: "turkce", label: "Türkçe", questionCount: 40 },
  { id: "sosyal", label: "Sosyal", questionCount: 20 },
  { id: "matematik", label: "Matematik", questionCount: 40 },
  { id: "fen", label: "Fen", questionCount: 20 },
] as const;

export type TytSubjectId = (typeof TYT_SUBJECTS)[number]["id"];
export type TytSubjectResult = { correct: number; wrong: number };
export type TytExamResults = Record<TytSubjectId, TytSubjectResult>;
export type TytGoals = Record<TytSubjectId, number | null>;

export type TytExam = {
  id: string;
  name: string;
  createdAt: string;
  results: TytExamResults;
};

export type TytStudyData = {
  version: 1;
  goals: TytGoals;
  exams: TytExam[];
};

export const TYT_STORAGE_PREFIX = "odak-paneli/tyt-study/v1/accounts/";
export const TYT_MAX_EXAMS = 200;
export const TYT_EXAM_NAME_LIMIT = 100;

export function createEmptyTytData(): TytStudyData {
  return {
    version: 1,
    goals: { turkce: null, sosyal: null, matematik: null, fen: null },
    exams: [],
  };
}

export function getTytStorageKey(accountId: string | number): string {
  return `${TYT_STORAGE_PREFIX}${encodeURIComponent(String(accountId))}`;
}

export function calculateTytNet(result: TytSubjectResult): number {
  return Math.round((result.correct - result.wrong / 4) * 100) / 100;
}

export type TytNetChartSegment = {
  startPercent: number;
  sizePercent: number;
  zeroPercent: number;
  isNegative: boolean;
};

export function getTytNetChartSegment(net: number | null, questionCount: number): TytNetChartSegment {
  const minimum = -questionCount / 4;
  const maximum = questionCount;
  const range = maximum - minimum;
  const zeroPercent = ((0 - minimum) / range) * 100;
  if (net === null) return { startPercent: zeroPercent, sizePercent: 0, zeroPercent, isNegative: false };
  const bounded = Math.max(minimum, Math.min(maximum, net));
  const valuePercent = ((bounded - minimum) / range) * 100;
  return {
    startPercent: Math.min(zeroPercent, valuePercent),
    sizePercent: Math.abs(valuePercent - zeroPercent),
    zeroPercent,
    isNegative: bounded < 0,
  };
}

export function calculateTytExamNets(results: TytExamResults): Record<TytSubjectId, number> {
  return {
    turkce: calculateTytNet(results.turkce),
    sosyal: calculateTytNet(results.sosyal),
    matematik: calculateTytNet(results.matematik),
    fen: calculateTytNet(results.fen),
  };
}

export function calculateTytExamTotal(results: TytExamResults): number {
  return Object.values(calculateTytExamNets(results)).reduce((total, net) => total + net, 0);
}

export function calculateTytAverages(exams: readonly TytExam[]): Record<TytSubjectId, number | null> {
  if (exams.length === 0) return { turkce: null, sosyal: null, matematik: null, fen: null };
  const totals = { turkce: 0, sosyal: 0, matematik: 0, fen: 0 };
  for (const exam of exams) {
    const nets = calculateTytExamNets(exam.results);
    for (const subject of TYT_SUBJECTS) totals[subject.id] += nets[subject.id];
  }
  return {
    turkce: Math.round((totals.turkce / exams.length) * 100) / 100,
    sosyal: Math.round((totals.sosyal / exams.length) * 100) / 100,
    matematik: Math.round((totals.matematik / exams.length) * 100) / 100,
    fen: Math.round((totals.fen / exams.length) * 100) / 100,
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function isValidTytResults(results: unknown): results is TytExamResults {
  if (!isRecord(results)) return false;
  return TYT_SUBJECTS.every(subject => {
    const entry = results[subject.id];
    if (!isRecord(entry)) return false;
    const correct = entry.correct;
    const wrong = entry.wrong;
    return Number.isInteger(correct)
      && Number.isInteger(wrong)
      && Number(correct) >= 0
      && Number(wrong) >= 0
      && Number(correct) + Number(wrong) <= subject.questionCount;
  });
}

function sanitizeExam(value: unknown): TytExam | null {
  if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string" || typeof value.createdAt !== "string") return null;
  const name = value.name.trim().slice(0, TYT_EXAM_NAME_LIMIT);
  if (!name || !isValidTytResults(value.results)) return null;
  return {
    id: value.id,
    name,
    createdAt: value.createdAt,
    results: {
      turkce: { correct: value.results.turkce.correct, wrong: value.results.turkce.wrong },
      sosyal: { correct: value.results.sosyal.correct, wrong: value.results.sosyal.wrong },
      matematik: { correct: value.results.matematik.correct, wrong: value.results.matematik.wrong },
      fen: { correct: value.results.fen.correct, wrong: value.results.fen.wrong },
    },
  };
}

export function parseTytStudyData(raw: string | null): TytStudyData {
  const empty = createEmptyTytData();
  if (!raw) return empty;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!isRecord(parsed)) return empty;
    const goals: TytGoals = { ...empty.goals };
    if (isRecord(parsed.goals)) {
      for (const subject of TYT_SUBJECTS) {
        const value = parsed.goals[subject.id];
        if (typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= subject.questionCount) {
          goals[subject.id] = Math.round(value * 100) / 100;
        }
      }
    }
    const seen = new Set<string>();
    const exams = Array.isArray(parsed.exams)
      ? parsed.exams.map(sanitizeExam).filter((exam): exam is TytExam => {
        if (!exam || seen.has(exam.id)) return false;
        seen.add(exam.id);
        return true;
      }).slice(-TYT_MAX_EXAMS)
      : [];
    return { version: 1, goals, exams };
  } catch {
    return empty;
  }
}
