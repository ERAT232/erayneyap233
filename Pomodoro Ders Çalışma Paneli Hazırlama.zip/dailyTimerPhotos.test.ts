import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { User } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const dbMocks = vi.hoisted(() => ({
  listDailyTimerPhotos: vi.fn(),
  upsertDailyTimerPhoto: vi.fn(),
}));
const storageMocks = vi.hoisted(() => ({ storagePut: vi.fn() }));
vi.mock("./db", () => dbMocks);
vi.mock("./storage", () => storageMocks);

import * as db from "./db";
import * as storage from "./storage";
import { appRouter } from "./routers";
import { getIstanbulDayKey } from "../shared/studyTracking";

let serial = 4_000;
function makeUser(username: string): User {
  serial += 1;
  const now = new Date();
  return {
    id: serial,
    openId: `daily_photo_test_${serial}`,
    chatUserId: `daily-photo-${serial}`,
    username,
    passwordHash: "not-used-in-this-test",
    name: username,
    email: null,
    loginMethod: "password",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
    chatPhotoData: null,
    lastChatSeenAt: null,
    chatLastReadMessageId: null,
  };
}

function makeContext(user: User | null): TrpcContext {
  const req = {
    protocol: "https",
    method: "POST",
    originalUrl: "/api/trpc/dailyTimerPhotos",
    ip: "198.51.100.72",
    socket: { remoteAddress: "198.51.100.72" },
    headers: {},
  } as unknown as TrpcContext["req"];
  const res = {
    cookie: vi.fn(),
    clearCookie: vi.fn(),
  } as unknown as TrpcContext["res"];
  return { req, res, user };
}

function smallJpegDataUrl(): string {
  const bytes = Buffer.from([
    0xff, 0xd8, 0xff, 0xc0, 0x00, 0x0b, 0x08,
    0x00, 0x01, 0x00, 0x01, 0x01, 0x01, 0x11, 0x00,
    0xff, 0xd9,
  ]);
  return `data:image/jpeg;base64,${bytes.toString("base64")}`;
}

beforeEach(() => {
  vi.clearAllMocks();
});
afterEach(() => vi.unstubAllEnvs());

describe("daily timer photo gallery", () => {
  it("allows public visitors to read dates and storage-backed URLs", async () => {
    const uploadedAt = new Date("2026-11-16T15:00:00.000Z");
    vi.mocked(db.listDailyTimerPhotos).mockResolvedValue([
      {
        dayKey: "2026-11-16",
        storageKey: "daily-timer-photos/2026-11-16.jpg_abc12345",
        uploadedAt,
      },
    ]);

    const caller = appRouter.createCaller(makeContext(null));
    await expect(caller.dailyTimerPhotos.list()).resolves.toEqual([
      {
        dayKey: "2026-11-16",
        url: "/manus-storage/daily-timer-photos/2026-11-16.jpg_abc12345",
        uploadedAt,
      },
    ]);
  });

  it("rejects member uploads before object storage or database writes", async () => {
    const caller = appRouter.createCaller(makeContext(makeUser("ilayda")));
    await expect(
      caller.dailyTimerPhotos.replace({
        dayKey: getIstanbulDayKey(),
        imageData: smallJpegDataUrl(),
      })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(storage.storagePut).not.toHaveBeenCalled();
    expect(db.upsertDailyTimerPhoto).not.toHaveBeenCalled();
  });

  it("lets only Eray store a validated photo for the selected Istanbul day", async () => {
    const owner = makeUser("eray");
    const dayKey = getIstanbulDayKey();
    vi.mocked(storage.storagePut).mockResolvedValue({
      key: `daily-timer-photos/${dayKey}.jpg_abc12345`,
      url: `/manus-storage/daily-timer-photos/${dayKey}.jpg_abc12345`,
    });
    vi.mocked(db.upsertDailyTimerPhoto).mockResolvedValue({
      dayKey,
      storageKey: `daily-timer-photos/${dayKey}.jpg_abc12345`,
      uploadedAt: new Date(),
    });

    const caller = appRouter.createCaller(makeContext(owner));
    await expect(
      caller.dailyTimerPhotos.replace({ dayKey, imageData: smallJpegDataUrl() })
    ).resolves.toEqual({
      dayKey,
      url: `/manus-storage/daily-timer-photos/${dayKey}.jpg_abc12345`,
    });
    expect(storage.storagePut).toHaveBeenCalledWith(
      `daily-timer-photos/${dayKey}.jpg`,
      expect.any(Buffer),
      "image/jpeg"
    );
    expect(db.upsertDailyTimerPhoto).toHaveBeenCalledWith({
      dayKey,
      storageKey: `daily-timer-photos/${dayKey}.jpg_abc12345`,
      uploadedBy: owner.id,
    });
  });

  it("rejects invalid image bytes and future dates", async () => {
    const caller = appRouter.createCaller(makeContext(makeUser("eray")));
    await expect(
      caller.dailyTimerPhotos.replace({
        dayKey: getIstanbulDayKey(),
        imageData: "data:image/jpeg;base64,not-a-jpeg",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });

    await expect(
      caller.dailyTimerPhotos.replace({
        dayKey: "2999-01-01",
        imageData: smallJpegDataUrl(),
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(storage.storagePut).not.toHaveBeenCalled();
    expect(db.upsertDailyTimerPhoto).not.toHaveBeenCalled();
  });
});
