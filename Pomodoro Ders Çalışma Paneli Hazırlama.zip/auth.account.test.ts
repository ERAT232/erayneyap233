import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";
import type { Request } from "express";
import type { User } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";
import { hashPassword } from "./_core/accountAuth";

const dbMocks = vi.hoisted(() => ({
  createPasswordUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  getUserByUsername: vi.fn(),
  createAccountSession: vi.fn(),
  updateUserLastSignedIn: vi.fn(),
  deleteAccountSession: vi.fn(),
  getPublicProfileByOwner: vi.fn(),
  getPublicProfileByShareId: vi.fn(),
  upsertPublicProfile: vi.fn(),
  bumpRateLimitBucket: vi.fn(),
}));

vi.mock("./db", () => dbMocks);

import * as db from "./db";
import { appRouter } from "./routers";

let serial = 0;
function makeUser(username: string, passwordHash: string | null): User {
  const now = new Date();
  return {
    id: 17,
    openId: "local_test_account_17",
    chatUserId: "account_170001",
    username,
    passwordHash,
    name: username,
    email: null,
    loginMethod: "password",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
    chatPhotoData: null,
    lastChatSeenAt: null,
    chatLastReadMessageId: null,
  };
}

function makeContext() {
  serial += 1;
  const ip = `198.51.100.${(serial % 200) + 1}`;
  const req = {
    protocol: "https",
    method: "POST",
    originalUrl: "/api/trpc/auth",
    ip,
    socket: { remoteAddress: ip },
    headers: {},
  } as unknown as TrpcContext["req"];
  const res = {
    cookie: vi.fn(),
    clearCookie: vi.fn(),
  } as unknown as TrpcContext["res"];
  return { req, res, user: null } satisfies TrpcContext;
}

const bucketCounts = new Map<string, number>();
beforeEach(() => {
  vi.clearAllMocks();
  bucketCounts.clear();
  vi.stubEnv("MANUS_JWT_SECRET", "test-rate-limit-secret-long-enough-0123456789");
  vi.mocked(db.bumpRateLimitBucket).mockImplementation(async input => {
    const count = (bucketCounts.get(input.bucketKey) ?? 0) + 1;
    bucketCounts.set(input.bucketKey, count);
    return { count, resetAt: new Date((input.now ?? new Date()).getTime() + input.windowMs) };
  });
});
afterEach(() => vi.unstubAllEnvs());

describe("password account procedures", () => {
  it("creates an account and stores only a password hash plus a hashed revocable session token", async () => {
    const username = `new_user_${serial + 1}`;
    const insertedUsers: User[] = [];
    vi.mocked(db.createPasswordUser).mockImplementation(async input => {
      const created = makeUser(input.username, input.passwordHash);
      insertedUsers.push(created);
      return created;
    });
    vi.mocked(db.createAccountSession).mockResolvedValue(undefined);

    const ctx = makeContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.signup({ username: `  ${username}  `, password: "one-time-strong-password" });

    expect(result).toMatchObject({ username, name: username, role: "user" });
    expect(result.chatUserId).toMatch(/^[A-Za-z0-9_-]{8,16}$/);
    expect(result).not.toHaveProperty("email");
    expect(insertedUsers[0]?.passwordHash).toMatch(/^scrypt\$16384\$8\$1\$/);
    expect(insertedUsers[0]?.passwordHash).not.toContain("one-time-strong-password");
    expect(db.createAccountSession).toHaveBeenCalledOnce();
    const session = vi.mocked(db.createAccountSession).mock.calls[0]?.[0];
    expect(session?.tokenHash).toMatch(/^[a-f0-9]{64}$/);
    expect(session?.tokenHash).not.toEqual((ctx.res.cookie as ReturnType<typeof vi.fn>).mock.calls[0]?.[1]);
    expect(ctx.res.cookie).toHaveBeenCalledOnce();
  });

  it("returns the same public account shape on correct username/password login", async () => {
    const username = `login_${serial + 1}`;
    const passwordHash = await hashPassword("correct-long-login-password");
    const user = makeUser(username, passwordHash);
    vi.mocked(db.getUserByUsername).mockResolvedValue(user);
    vi.mocked(db.updateUserLastSignedIn).mockResolvedValue(undefined);
    vi.mocked(db.createAccountSession).mockResolvedValue(undefined);

    const ctx = makeContext();
    const result = await appRouter.createCaller(ctx).auth.login({ username: username.toUpperCase(), password: "correct-long-login-password" });

    expect(result).toMatchObject({ username, role: "user" });
    expect(result).not.toHaveProperty("email");
    expect(ctx.res.cookie).toHaveBeenCalledOnce();
  });

  it("does not reveal whether a username exists when login fails", async () => {
    const absentName = `absent_${serial + 1}`;
    vi.mocked(db.getUserByUsername).mockResolvedValue(undefined as never);
    const caller = appRouter.createCaller(makeContext());
    const absentError = await caller.auth.login({ username: absentName, password: "incorrect-long-password" }).catch(error => error);

    const existingName = `exists_${serial + 1}`;
    vi.mocked(db.getUserByUsername).mockResolvedValue(makeUser(existingName, await hashPassword("other-long-password")));
    const existingError = await appRouter.createCaller(makeContext()).auth.login({ username: existingName, password: "incorrect-long-password" }).catch(error => error);

    expect(absentError).toBeInstanceOf(TRPCError);
    expect(existingError).toBeInstanceOf(TRPCError);
    expect((absentError as TRPCError).message).toBe("Kullanıcı adı veya şifre yanlış.");
    expect((existingError as TRPCError).message).toBe("Kullanıcı adı veya şifre yanlış.");
  });

  it("rejects a duplicate username without issuing a session", async () => {
    vi.mocked(db.createPasswordUser).mockRejectedValue({ code: "ER_DUP_ENTRY" });
    const ctx = makeContext();
    const error = await appRouter.createCaller(ctx).auth.signup({
      username: `duplicate_${serial + 1}`,
      password: "one-time-strong-password",
    }).catch(value => value);
    expect(error).toBeInstanceOf(TRPCError);
    expect((error as TRPCError).code).toBe("CONFLICT");
    expect(ctx.res.cookie).not.toHaveBeenCalled();
  });
});
