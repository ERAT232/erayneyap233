import { useEffect, useState, type FormEvent } from "react";
import {
  BookOpen,
  ChevronDown,
  Layers3,
  Plus,
  Sparkles,
  Trash2,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { notifyErayStudyDataChanged } from "@/lib/erayStudyEvents";
import {
  getYksSubjectsStorageKey,
  readYksSubjects,
  YKS_NAME_LIMIT as NAME_LIMIT,
  YKS_SUBJECT_LIMIT as SUBJECT_LIMIT,
  YKS_TOPIC_LIMIT as TOPIC_LIMIT,
  type YksSubject,
} from "@/lib/yks/subjectsStorage";

const cardTones = [
  {
    card: "from-[#fff0d1] via-[#fff9ec] to-[#fbefda]",
    badge: "bg-[#f5d391] text-[#7c4a10]",
    chip: "bg-[#fff0d1] text-[#80521c]",
    border: "border-[#e9c781]",
    glow: "bg-[#efc56f]",
  },
  {
    card: "from-[#e7eef9] via-[#f8faff] to-[#eaf1f7]",
    badge: "bg-[#c8d8ef] text-[#395878]",
    chip: "bg-[#e2ebf7] text-[#456788]",
    border: "border-[#bdcfe7]",
    glow: "bg-[#9cb8df]",
  },
  {
    card: "from-[#e6f0e3] via-[#f8fbf5] to-[#eaf3e5]",
    badge: "bg-[#c7ddbe] text-[#42613c]",
    chip: "bg-[#e5f0e1] text-[#4f6e48]",
    border: "border-[#bfd5b6]",
    glow: "bg-[#a8c99a]",
  },
  {
    card: "from-[#f5e8f1] via-[#fdf8fc] to-[#f3e7f0]",
    badge: "bg-[#e3c5dd] text-[#71486c]",
    chip: "bg-[#f1e3ee] text-[#775571]",
    border: "border-[#ddc0d7]",
    glow: "bg-[#d3a9ca]",
  },
  {
    card: "from-[#f8e6e2] via-[#fff9f7] to-[#f7e9e4]",
    badge: "bg-[#efc2b5] text-[#86493b]",
    chip: "bg-[#f8e6e1] text-[#86584f]",
    border: "border-[#e8c2b8]",
    glow: "bg-[#dfa394]",
  },
  {
    card: "from-[#e6f0f1] via-[#f8fcfc] to-[#e9f2f1]",
    badge: "bg-[#c2dddc] text-[#396466]",
    chip: "bg-[#e3f0ef] text-[#4a7070]",
    border: "border-[#bad6d5]",
    glow: "bg-[#96c3c3]",
  },
];

function makeId(): string {
  return typeof crypto !== "undefined" &&
    typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export default function YksSubjects() {
  const auth = useAuth();
  const accountId = auth.user?.id;
  const storageKey =
    accountId === undefined ? null : getYksSubjectsStorageKey(accountId);
  const [subjects, setSubjects] = useState<YksSubject[]>([]);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);
  const [newSubject, setNewSubject] = useState("");
  const [topicDrafts, setTopicDrafts] = useState<Record<string, string>>({});
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!storageKey) {
      setSubjects([]);
      setLoadedKey(null);
      return;
    }
    setSubjects(readYksSubjects(storageKey));
    setTopicDrafts({});
    setLoadedKey(storageKey);
  }, [storageKey]);

  useEffect(() => {
    if (!storageKey || loadedKey !== storageKey) return;
    try {
      const serialized = JSON.stringify(subjects);
      if (localStorage.getItem(storageKey) !== serialized) {
        localStorage.setItem(storageKey, serialized);
        notifyErayStudyDataChanged();
      }
    } catch {
      // Keep the in-memory list usable if browser storage is unavailable or full.
    }
  }, [loadedKey, storageKey, subjects]);

  const addSubject = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const name = newSubject.trim();
    if (!name || subjects.length >= SUBJECT_LIMIT || loadedKey !== storageKey)
      return;
    setSubjects(current => [
      ...current,
      { id: makeId(), name: name.slice(0, NAME_LIMIT), topics: [] },
    ]);
    setNewSubject("");
  };

  const removeSubject = (subjectId: string) => {
    setSubjects(current => current.filter(subject => subject.id !== subjectId));
    setTopicDrafts(current => {
      const next = { ...current };
      delete next[subjectId];
      return next;
    });
  };

  const addTopic = (event: FormEvent<HTMLFormElement>, subjectId: string) => {
    event.preventDefault();
    const name = (topicDrafts[subjectId] ?? "").trim();
    if (!name || loadedKey !== storageKey) return;
    setSubjects(current =>
      current.map(subject => {
        if (subject.id !== subjectId || subject.topics.length >= TOPIC_LIMIT)
          return subject;
        return {
          ...subject,
          topics: [
            ...subject.topics,
            { id: makeId(), name: name.slice(0, NAME_LIMIT) },
          ],
        };
      })
    );
    setTopicDrafts(current => ({ ...current, [subjectId]: "" }));
  };

  const removeTopic = (subjectId: string, topicId: string) => {
    setSubjects(current =>
      current.map(subject =>
        subject.id === subjectId
          ? {
              ...subject,
              topics: subject.topics.filter(topic => topic.id !== topicId),
            }
          : subject
      )
    );
  };

  const ready = Boolean(storageKey && loadedKey === storageKey);
  const topicCount = subjects.reduce(
    (total, subject) => total + subject.topics.length,
    0
  );

  return (
    <section className="space-y-4" aria-labelledby="yks-subjects-title">
      <button
        type="button"
        aria-expanded={expanded}
        aria-controls="yks-subjects-content"
        onClick={() => setExpanded(value => !value)}
        className="group relative mx-auto flex aspect-square w-full max-w-[350px] flex-col items-stretch justify-between gap-4 overflow-hidden rounded-2xl border border-[#cdb88f] bg-gradient-to-br from-[#f9e8c4] via-[#fdf9ee] to-[#dce8d7] p-5 text-left shadow-[0_22px_48px_-28px_rgba(69,52,29,0.58)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_54px_-28px_rgba(69,52,29,0.65)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-amber-ink sm:max-w-[380px] sm:rounded-[1.75rem] sm:p-7"
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-10 -top-16 h-64 w-64 rounded-full border border-white/55 bg-white/20 shadow-[0_0_0_18px_rgba(255,255,255,0.12),0_0_0_38px_rgba(255,255,255,0.08)] transition duration-500 group-hover:scale-110"
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute bottom-[-4.5rem] right-36 h-40 w-40 rounded-full bg-[#a8c99a]/25 blur-2xl"
        />

        <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start gap-3">
          <span className="relative grid h-16 w-16 shrink-0 place-items-center rounded-2xl border border-white/70 bg-white/60 text-amber-ink shadow-[0_12px_26px_-16px_rgba(90,66,34,0.65)] transition duration-500 group-hover:rotate-[-6deg] group-hover:scale-110 sm:h-[4.5rem] sm:w-[4.5rem]">
            <BookOpen
              className="h-8 w-8 sm:h-9 sm:w-9"
              strokeWidth={1.6}
              aria-hidden="true"
            />
            <span className="absolute -right-2 -top-2 grid h-8 w-8 place-items-center rounded-full border-2 border-[#fcf7e9] bg-[#5b7a54] text-white shadow-md">
              <Sparkles className="h-4 w-4" aria-hidden="true" />
            </span>
          </span>
          <span className="min-w-0">
            <span className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-[#b8c8a9]/80 bg-white/50 px-3 py-1 text-[0.65rem] font-bold tracking-[0.18em] text-[#4d6a46]">
              YKS ÇALIŞMA DEFTERİ
            </span>
            <span
              id="yks-subjects-title"
              className="block font-display text-3xl font-bold leading-tight text-[#302719] sm:text-4xl"
            >
              Derslerim
            </span>
            <span className="mt-2 block text-sm leading-relaxed text-[#685c48]">
              Derslerini ve konularını tek yerde topla, çalışma planını kendine
              göre şekillendir.
            </span>
            <span className="mt-3 flex flex-wrap gap-2">
              <span className="rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#5b4a32]">
                {subjects.length} ders
              </span>
              <span className="rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#4e6d49]">
                {topicCount} konu
              </span>
            </span>
          </span>
        </span>

        <span className="relative z-10 flex w-full items-center justify-between border-t border-[#8b7355]/15 pt-3">
          <span className="text-xs font-bold tracking-wide text-[#526f4b]">
            {expanded ? "KAPAT" : "DERSLERİ AÇ"}
          </span>
          <span className="grid h-11 w-11 place-items-center rounded-full border border-white/75 bg-white/60 text-[#526f4b] shadow-md transition duration-300 group-hover:scale-110 group-hover:bg-white">
            <ChevronDown
              className={`h-5 w-5 transition-transform duration-500 ${expanded ? "rotate-180" : ""}`}
              aria-hidden="true"
            />
          </span>
        </span>
      </button>

      <div
        id="yks-subjects-content"
        aria-hidden={!expanded}
        inert={!expanded}
        className={`grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,0.8,0.3,1)] ${expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
      >
        <div className="min-h-0 overflow-hidden">
          {expanded && (
            <div className="yks-panel-open rounded-2xl border border-white/70 bg-white/35 p-2 shadow-[0_28px_60px_-38px_rgba(69,52,29,0.58)] sm:rounded-[1.75rem] sm:p-4">
              <div className="rounded-xl border border-white/80 bg-[#fbf8ef]/90 p-4 sm:rounded-2xl sm:p-6">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
                  <div>
                    <p className="smallcaps">KENDİ PLANINI OLUŞTUR</p>
                    <h2 className="mt-1 font-display text-2xl font-bold text-ink sm:text-3xl">
                      Ders ve konu panon
                    </h2>
                  </div>
                  <span className="inline-flex items-center gap-2 rounded-full bg-[#e8f0e3] px-3 py-1.5 text-xs font-semibold text-[#4c6b45]">
                    <Layers3 className="h-4 w-4" aria-hidden="true" />
                    Kişisel çalışma alanın
                  </span>
                </div>

                <form
                  onSubmit={addSubject}
                  className="mb-5 flex flex-col gap-2 rounded-xl border border-[#e2d5bb] bg-gradient-to-r from-[#fff4df] to-[#f6f2e8] p-3 sm:flex-row sm:p-4"
                  aria-label="Ders ekle"
                >
                  <label htmlFor="yks-new-subject" className="sr-only">
                    Ders adı
                  </label>
                  <input
                    id="yks-new-subject"
                    value={newSubject}
                    onChange={event => setNewSubject(event.target.value)}
                    maxLength={NAME_LIMIT}
                    placeholder="Ders adı yaz… örn. Matematik"
                    disabled={!ready || subjects.length >= SUBJECT_LIMIT}
                    className="h-12 min-w-0 flex-1 rounded-lg border border-[#ddcda9] bg-white/90 px-4 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/15 disabled:opacity-60"
                  />
                  <button
                    type="submit"
                    disabled={
                      !ready ||
                      !newSubject.trim() ||
                      subjects.length >= SUBJECT_LIMIT
                    }
                    className="inline-flex h-12 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#b45309] to-[#ce741a] px-5 text-sm font-bold text-[#fffaf0] shadow-[0_8px_16px_-9px_rgba(120,63,10,0.8)] transition hover:-translate-y-0.5 hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <Plus className="h-4 w-4" aria-hidden="true" />
                    Ders ekle
                  </button>
                </form>

                {!ready ? (
                  <p className="px-2 py-5 text-sm text-ink-faint" role="status">
                    Derslerin yükleniyor…
                  </p>
                ) : subjects.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-[#d6c5a4] bg-[#fffdf7] px-4 py-9 text-center">
                    <span className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-[#f7ead1] text-amber-ink">
                      <BookOpen className="h-6 w-6" aria-hidden="true" />
                    </span>
                    <p className="font-display text-lg font-semibold text-ink">
                      İlk dersini ekleyerek başla
                    </p>
                    <p className="mt-1 text-sm text-ink-faint">
                      Her dersin içine konularını da ekleyebilirsin.
                    </p>
                  </div>
                ) : (
                  <ul className="grid grid-cols-1 gap-4 2xl:grid-cols-2">
                    {subjects.map((subject, index) => {
                      const tone = cardTones[index % cardTones.length];
                      return (
                        <li
                          key={subject.id}
                          className={`group/card relative overflow-hidden rounded-2xl border ${tone.border} bg-gradient-to-br ${tone.card} p-4 shadow-[0_18px_28px_-24px_rgba(55,42,24,0.65)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_23px_34px_-24px_rgba(55,42,24,0.72)]`}
                        >
                          <span
                            aria-hidden="true"
                            className={`pointer-events-none absolute -right-8 -top-9 h-28 w-28 rounded-full ${tone.glow} opacity-20 blur-xl transition duration-500 group-hover/card:scale-125`}
                          />
                          <div className="relative flex items-start justify-between gap-3">
                            <div className="flex min-w-0 items-center gap-3">
                              <span
                                className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${tone.badge} shadow-sm`}
                              >
                                <BookOpen
                                  className="h-5 w-5"
                                  aria-hidden="true"
                                />
                              </span>
                              <div className="min-w-0">
                                <span className="text-[0.62rem] font-bold tracking-[0.16em] text-ink-faint">
                                  DERS {String(index + 1).padStart(2, "0")}
                                </span>
                                <h3 className="break-words font-display text-lg font-bold leading-tight text-ink">
                                  {subject.name}
                                </h3>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeSubject(subject.id)}
                              aria-label={`${subject.name} dersini sil`}
                              title="Dersi sil"
                              className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-white/75 bg-white/50 text-[#8f493b] transition hover:bg-white hover:text-[#a33524]"
                            >
                              <Trash2 className="h-4 w-4" aria-hidden="true" />
                            </button>
                          </div>

                          <div className="relative mt-4 min-h-12">
                            {subject.topics.length ? (
                              <ul className="flex flex-wrap gap-2">
                                {subject.topics.map(topic => (
                                  <li
                                    key={topic.id}
                                    className={`inline-flex max-w-full items-center gap-1 rounded-full ${tone.chip} py-1 pl-3 pr-1 text-xs font-semibold shadow-sm`}
                                  >
                                    <span className="break-words">
                                      {topic.name}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        removeTopic(subject.id, topic.id)
                                      }
                                      aria-label={`${subject.name} dersinden ${topic.name} konusunu sil`}
                                      title="Konuyu sil"
                                      className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-current/70 transition hover:bg-white/70 hover:text-[#9f392c]"
                                    >
                                      <Trash2
                                        className="h-3 w-3"
                                        aria-hidden="true"
                                      />
                                    </button>
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              <p className="rounded-lg border border-dashed border-black/10 bg-white/35 px-3 py-2 text-xs text-ink-faint">
                                Henüz konu eklenmedi
                              </p>
                            )}
                          </div>

                          <form
                            onSubmit={event => addTopic(event, subject.id)}
                            className="relative mt-4 flex gap-2 border-t border-black/10 pt-3"
                            aria-label={`${subject.name} dersine konu ekle`}
                          >
                            <label
                              htmlFor={`yks-topic-${subject.id}`}
                              className="sr-only"
                            >
                              {subject.name} konusu
                            </label>
                            <input
                              id={`yks-topic-${subject.id}`}
                              value={topicDrafts[subject.id] ?? ""}
                              onChange={event =>
                                setTopicDrafts(current => ({
                                  ...current,
                                  [subject.id]: event.target.value,
                                }))
                              }
                              maxLength={NAME_LIMIT}
                              placeholder="Yeni konu…"
                              disabled={subject.topics.length >= TOPIC_LIMIT}
                              className="h-10 min-w-0 flex-1 rounded-lg border border-white/80 bg-white/75 px-3 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-sage-ink focus:ring-2 focus:ring-sage-ink/15 disabled:opacity-60"
                            />
                            <button
                              type="submit"
                              disabled={
                                !(topicDrafts[subject.id] ?? "").trim() ||
                                subject.topics.length >= TOPIC_LIMIT
                              }
                              aria-label={`${subject.name} dersine konu ekle`}
                              title="Konu ekle"
                              className={`grid h-10 w-10 shrink-0 place-items-center rounded-lg ${tone.badge} shadow-sm transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-45`}
                            >
                              <Plus className="h-5 w-5" aria-hidden="true" />
                            </button>
                          </form>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
