ALTER TABLE `chatMessages` ADD `imageData` longtext;--> statement-breakpoint
ALTER TABLE `chatMessages` ADD `deletedAt` timestamp;