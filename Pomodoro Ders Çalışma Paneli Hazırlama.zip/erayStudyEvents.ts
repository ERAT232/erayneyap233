export const ERAY_STUDY_DATA_CHANGED = "odak-paneli:eray-study-data-changed";
export const ERAY_POMODORO_STATUS_CHANGED =
  "odak-paneli:eray-pomodoro-status-changed";

export function notifyErayStudyDataChanged(): void {
  if (typeof window !== "undefined")
    window.dispatchEvent(new Event(ERAY_STUDY_DATA_CHANGED));
}

export function notifyErayPomodoroStatusChanged(): void {
  if (typeof window !== "undefined")
    window.dispatchEvent(new Event(ERAY_POMODORO_STATUS_CHANGED));
}
