CREATE TABLE `rateLimitBuckets` (
	`bucketKey` varchar(64) NOT NULL,
	`hits` int NOT NULL,
	`resetAt` timestamp NOT NULL,
	CONSTRAINT `rateLimitBuckets_bucketKey` PRIMARY KEY(`bucketKey`)
);
