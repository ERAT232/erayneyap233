export const DAILY_WHEEL_OPTIONS = [
  { percentage: 10, weight: 1 },
  { percentage: 20, weight: 2 },
  { percentage: 30, weight: 4 },
  { percentage: 40, weight: 8 },
  { percentage: 50, weight: 14 },
  { percentage: 60, weight: 15 },
  { percentage: 70, weight: 15 },
  { percentage: 80, weight: 15 },
  { percentage: 90, weight: 15 },
  { percentage: 100, weight: 11 },
] as const;

export const DAILY_WHEEL_TOTAL_WEIGHT = DAILY_WHEEL_OPTIONS.reduce((total, option) => total + option.weight, 0);
export const DAILY_WHEEL_HIGH_WEIGHT = DAILY_WHEEL_OPTIONS
  .filter(option => option.percentage >= 50)
  .reduce((total, option) => total + option.weight, 0);
export const DAILY_WHEEL_TWENTY_WEIGHT = DAILY_WHEEL_OPTIONS.find(option => option.percentage === 20)?.weight ?? 0;

export type DailyWheelPercentage = typeof DAILY_WHEEL_OPTIONS[number]["percentage"];

/** Maps a zero-based secure random roll to the public weighted wheel distribution. */
export function pickDailyWheelPercentage(roll: number): DailyWheelPercentage {
  if (!Number.isSafeInteger(roll) || roll < 0 || roll >= DAILY_WHEEL_TOTAL_WEIGHT) {
    throw new RangeError(`Wheel roll must be an integer from 0 to ${DAILY_WHEEL_TOTAL_WEIGHT - 1}.`);
  }

  let upperBound = 0;
  for (const option of DAILY_WHEEL_OPTIONS) {
    upperBound += option.weight;
    if (roll < upperBound) return option.percentage;
  }

  throw new RangeError("Wheel roll could not be mapped to an option.");
}
