CREATE TABLE `publicProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerOpenId` varchar(64) NOT NULL,
	`shareId` varchar(16) NOT NULL,
	`profilePhoto` longtext,
	`sessionsJson` longtext NOT NULL,
	`daysJson` longtext NOT NULL,
	`isPublic` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `publicProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `publicProfiles_ownerOpenId_unique` UNIQUE(`ownerOpenId`),
	CONSTRAINT `publicProfiles_shareId_unique` UNIQUE(`shareId`)
);
