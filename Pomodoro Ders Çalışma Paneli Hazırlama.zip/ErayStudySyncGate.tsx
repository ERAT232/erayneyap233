import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  readLocalErayStudySnapshot,
  restoreErayStudySnapshot,
} from "@/lib/erayStudySnapshot";
import {
  ERAY_POMODORO_STATUS_CHANGED,
  ERAY_STUDY_DATA_CHANGED,
} from "@/lib/erayStudyEvents";
import { loadSettings, loadTimer } from "@/lib/pomodoro/storage";
import { trpc } from "@/lib/trpc";

const DIRTY_PREFIX = "odak-paneli/eray-study-sync/v1/accounts/";

function dirtyKey(accountId: number): string {
  return `${DIRTY_PREFIX}${encodeURIComponent(String(accountId))}/dirty`;
}

function getDirtyMarker(accountId: number): string | null {
  try {
    return localStorage.getItem(dirtyKey(accountId));
  } catch {
    return null;
  }
}

function markDirty(accountId: number): string | null {
  const marker = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  try {
    localStorage.setItem(dirtyKey(accountId), marker);
    return marker;
  } catch {
    return null;
  }
}

function clearDirtyIfUnchanged(accountId: number, marker: string | null): void {
  if (!marker) return;
  try {
    const key = dirtyKey(accountId);
    if (localStorage.getItem(key) === marker) localStorage.removeItem(key);
  } catch {
    // A stale dirty marker only causes a safe repeat sync on the next session.
  }
}

export default function ErayStudySyncGate({
  children,
}: {
  children: ReactNode;
}) {
  const { user } = useAuth();
  const ownerId = user?.isEray ? user.id : null;
  const view = trpc.erayStudyData.view.useQuery(undefined, {
    enabled: ownerId !== null,
    retry: false,
    refetchOnWindowFocus: false,
  });
  const sync = trpc.erayStudyData.sync.useMutation();
  const statusSync = trpc.erayStudyData.statusSync.useMutation();
  const utils = trpc.useUtils();
  const initializedOwner = useRef<number | null>(null);
  const syncQueue = useRef<Promise<void>>(Promise.resolve());
  const lastSyncFailed = useRef(false);
  const [readyOwner, setReadyOwner] = useState<number | null>(null);

  useEffect(() => {
    if (ownerId === null) {
      initializedOwner.current = null;
      setReadyOwner(null);
      return;
    }
    if (!view.isSuccess && !view.isError) return;
    if (initializedOwner.current === ownerId) return;

    initializedOwner.current = ownerId;
    let active = true;
    void (async () => {
      try {
        if (view.data?.snapshot) {
          const dirtyMarker = getDirtyMarker(ownerId);
          if (dirtyMarker) {
            const localSnapshot = readLocalErayStudySnapshot(ownerId);
            await sync.mutateAsync({ snapshot: localSnapshot });
            clearDirtyIfUnchanged(ownerId, dirtyMarker);
            utils.erayStudyData.view.setData(undefined, {
              snapshot: localSnapshot,
              updatedAt: new Date(),
            });
          } else {
            restoreErayStudySnapshot(view.data.snapshot, ownerId);
          }
        } else if (view.isSuccess) {
          const localSnapshot = readLocalErayStudySnapshot(ownerId);
          const dirtyMarker = markDirty(ownerId);
          await sync.mutateAsync({ snapshot: localSnapshot });
          clearDirtyIfUnchanged(ownerId, dirtyMarker);
          utils.erayStudyData.view.setData(undefined, {
            snapshot: localSnapshot,
            updatedAt: new Date(),
          });
        } else {
          toast.error(
            "Sunucu verisine ulaşılamadı; Eray'ın bu cihazdaki kayıtları açılıyor."
          );
        }
      } catch {
        toast.error(
          "Eray'ın çalışma verileri eşitlenemedi; bu cihazdaki kayıtlar korunuyor."
        );
      } finally {
        if (active) setReadyOwner(ownerId);
      }
    })();

    return () => {
      active = false;
    };
  }, [
    ownerId,
    view.isSuccess,
    view.isError,
    view.data,
    sync.mutateAsync,
    utils,
  ]);

  const pushCurrentSnapshot = useCallback(
    (accountId: number) => {
      const save = syncQueue.current
        .catch(() => undefined)
        .then(async () => {
          const dirtyMarker = markDirty(accountId);
          const snapshot = readLocalErayStudySnapshot(accountId);
          await sync.mutateAsync({ snapshot });
          clearDirtyIfUnchanged(accountId, dirtyMarker);
          utils.erayStudyData.view.setData(undefined, {
            snapshot,
            updatedAt: new Date(),
          });
          lastSyncFailed.current = false;
        })
        .catch(() => {
          if (!lastSyncFailed.current) {
            toast.error(
              "Çalışma verileri ortak panele eşitlenemedi; tarayıcıdaki kayıtlar korunuyor."
            );
          }
          lastSyncFailed.current = true;
        });
      syncQueue.current = save;
    },
    [sync.mutateAsync, utils]
  );

  const pushCurrentStatus = useCallback(() => {
    const timer = loadTimer(loadSettings());
    const status = {
      phase: timer.phase,
      running: timer.running,
      endAt: timer.endAt,
      remainingSec: timer.remainingSec,
    };
    void statusSync
      .mutateAsync(status)
      .then(() => {
        utils.erayStudyData.status.setData(undefined, {
          ...status,
          updatedAt: new Date(),
        });
        lastSyncFailed.current = false;
      })
      .catch(() => {
        if (!lastSyncFailed.current) {
          toast.error(
            "Canlı Pomodoro durumu eşitlenemedi; bu cihazdaki kayıtlar korunuyor."
          );
        }
        lastSyncFailed.current = true;
      });
  }, [statusSync.mutateAsync, utils]);

  useEffect(() => {
    if (ownerId === null || readyOwner !== ownerId) return;
    let studyTimer: number | undefined;
    let statusTimer: number | undefined;
    let lastStatusSentAt = 0;
    const scheduleStudy = () => {
      markDirty(ownerId);
      if (studyTimer !== undefined) window.clearTimeout(studyTimer);
      studyTimer = window.setTimeout(() => pushCurrentSnapshot(ownerId), 650);
    };
    const scheduleStatus = () => {
      const delay = 2_000 - (Date.now() - lastStatusSentAt);
      if (delay <= 0) {
        if (statusTimer !== undefined) window.clearTimeout(statusTimer);
        statusTimer = undefined;
        lastStatusSentAt = Date.now();
        pushCurrentStatus();
      } else if (statusTimer === undefined) {
        statusTimer = window.setTimeout(() => {
          statusTimer = undefined;
          lastStatusSentAt = Date.now();
          pushCurrentStatus();
        }, delay);
      }
    };
    window.addEventListener(ERAY_STUDY_DATA_CHANGED, scheduleStudy);
    window.addEventListener(ERAY_POMODORO_STATUS_CHANGED, scheduleStatus);
    return () => {
      window.removeEventListener(ERAY_STUDY_DATA_CHANGED, scheduleStudy);
      window.removeEventListener(ERAY_POMODORO_STATUS_CHANGED, scheduleStatus);
      if (studyTimer !== undefined) window.clearTimeout(studyTimer);
      if (statusTimer !== undefined) window.clearTimeout(statusTimer);
    };
  }, [ownerId, readyOwner, pushCurrentSnapshot, pushCurrentStatus]);

  if (ownerId !== null && readyOwner !== ownerId) {
    return (
      <main className="desk-glow paper-grain grid min-h-[40vh] place-items-center px-4">
        <p
          className="plate rounded-md px-6 py-4 text-sm text-ink-soft"
          role="status"
        >
          Eray'ın çalışma alanı hazırlanıyor…
        </p>
      </main>
    );
  }

  return <>{children}</>;
}
