import { createHash, randomBytes, randomUUID, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import type { Request } from "express";
import { parse as parseCookieHeader } from "cookie";
import { ACCOUNT_SESSION_COOKIE_NAME } from "@shared/const";
import { enforceDistributedRateLimit, makeRateLimitKey } from "./rateLimits";

const SCRYPT_N = 16_384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const SCRYPT_KEY_BYTES = 64;
export const ACCOUNT_SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1_000;
const SCRYPT_OPTIONS = { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P, maxmem: 64 * 1024 * 1024 };

function deriveKey(password: string, salt: Buffer): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCallback(password, salt, SCRYPT_KEY_BYTES, SCRYPT_OPTIONS, (error, derived) => {
      if (error) reject(error);
      else resolve(derived as Buffer);
    });
  });
}

export function normalizeUsername(value: string): string {
  return value.normalize("NFKC").trim().toLowerCase();
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const derived = await deriveKey(password, salt);
  return ["scrypt", SCRYPT_N, SCRYPT_R, SCRYPT_P, salt.toString("base64url"), derived.toString("base64url")].join("$");
}

export async function verifyPassword(password: string, encoded: string): Promise<boolean> {
  const parts = encoded.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  if (Number(parts[1]) !== SCRYPT_N || Number(parts[2]) !== SCRYPT_R || Number(parts[3]) !== SCRYPT_P) return false;
  try {
    const salt = Buffer.from(parts[4], "base64url");
    const expected = Buffer.from(parts[5], "base64url");
    if (salt.length !== 16 || expected.length !== SCRYPT_KEY_BYTES) return false;
    const actual = await deriveKey(password, salt);
    return timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

let dummyHashPromise: Promise<string> | null = null;
export async function verifyPasswordOrDummy(password: string, storedHash: string | null | undefined): Promise<boolean> {
  if (!storedHash) dummyHashPromise ??= hashPassword(randomBytes(24).toString("hex"));
  const hash = storedHash ?? await dummyHashPromise!;
  const matches = await verifyPassword(password, hash);
  return Boolean(storedHash) && matches;
}

export function createAccountOpenId(): string {
  return `local_${randomUUID().replaceAll("-", "")}`;
}

export function createSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

export function hashSessionToken(token: string): string {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

export function readAccountSessionToken(req: Request): string | null {
  const token = parseCookieHeader(req.headers.cookie ?? "")[ACCOUNT_SESSION_COOKIE_NAME];
  return typeof token === "string" && /^[A-Za-z0-9_-]{40,50}$/.test(token) ? token : null;
}

export function getSessionExpiry(now = Date.now()): Date {
  return new Date(now + ACCOUNT_SESSION_TTL_MS);
}

export async function enforceAuthRateLimit(req: Request, username: string, action: "login" | "signup"): Promise<void> {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const usernameKey = normalizeUsername(username).slice(0, 32);
  const windowMs = action === "signup" ? 60 * 60 * 1_000 : 15 * 60 * 1_000;
  const ipLimit = action === "signup" ? 40 : 300;
  const usernameLimit = action === "signup" ? 5 : 12;
  const message = "Çok fazla deneme yapıldı. Lütfen daha sonra yeniden dene.";
  await enforceDistributedRateLimit({
    bucketKey: makeRateLimitKey("auth", action, "ip", ip),
    limit: ipLimit,
    windowMs,
    message,
  });
  await enforceDistributedRateLimit({
    bucketKey: makeRateLimitKey("auth", action, "username", usernameKey),
    limit: usernameLimit,
    windowMs,
    message,
  });
}
