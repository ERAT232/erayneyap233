import { ArrowRight, BookOpen, ChartNoAxesColumnIncreasing, Clock3, LockKeyhole, Target, Twitter } from "lucide-react";
import YksCountdown from "../components/YksCountdown";

type Props = { onNavigate: (view: "pomodoro" | "yks" | "status") => void };

const goals = [
  { subject: "Türkçe", target: 34, average: 28.4, total: 40 },
  { subject: "Sosyal", target: 16, average: 12.8, total: 20 },
  { subject: "Matematik", target: 30, average: 23.2, total: 40 },
  { subject: "Fen", target: 15, average: 10.6, total: 20 },
];

export default function HomePage({ onNavigate }: Props) {
  return (
    <section className="page-section">
      <div className="page-intro home-intro">
        <div>
          <p className="eyebrow">ODAK PANELİ / ÇALIŞMA MASASI</p>
          <h1>Bugünün odağı belli.</h1>
          <p>Bir çalışma oturumu seç, hedeflerini gözden geçir ve ritmini koru.</p>
        </div>
        <button className="button-primary intro-action" onClick={() => onNavigate("pomodoro")}>
          <Clock3 size={17} /> Pomodoro'yu aç <ArrowRight size={16} />
        </button>
      </div>

      <div className="dashboard-grid">
        <article className="paper-card countdown-card">
          <YksCountdown />
          <div className="card-footnote">Sınav tarihi yerel saatinize göre canlı sayılır.</div>
        </article>

        <article className="paper-card status-card">
          <div className="card-kicker"><span className="status-dot" /> ERAY NE DURUMDA</div>
          <h2>Canlı durum bağlı değil</h2>
          <p>Herkese açık bu demoda başka cihazlardaki çalışma veya mola durumu paylaşılmaz.</p>
          <button className="text-link" onClick={() => onNavigate("status")}>Örnek durum paneli <ArrowRight size={15} /></button>
        </article>

        <article className="paper-card goals-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">ÖRNEK TYT TAKİBİ</p>
              <h2><Target size={19} /> TYT Hedeflerim</h2>
            </div>
            <span className="tiny-label">NET</span>
          </div>
          <div className="goal-list">
            {goals.map((goal) => {
              const percent = Math.min(100, Math.round((goal.average / goal.target) * 100));
              return (
                <div className="goal-row" key={goal.subject}>
                  <div className="goal-meta">
                    <strong>{goal.subject}</strong>
                    <span>Hedef {goal.target}/{goal.total}</span>
                    <span>Ort. {goal.average.toFixed(1)}</span>
                  </div>
                  <div className="progress-track" aria-label={`${goal.subject}: örnek ortalama ${goal.average}, hedef ${goal.target}`}>
                    <span style={{ width: `${percent}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
          <button className="text-link" onClick={() => onNavigate("yks")}>YKS örneklerini gör <ArrowRight size={15} /></button>
        </article>

        <article className="paper-card focus-card">
          <div className="focus-icon"><Clock3 size={22} /></div>
          <p className="eyebrow">KISA BİR BAŞLANGIÇ</p>
          <h2>25 dakikalık odak turu</h2>
          <p>Tek bir küçük hedef seç ve ilk turunu başlat. Sayaç cihazında çalışır.</p>
          <button className="button-primary" onClick={() => onNavigate("pomodoro")}>Sayacı başlat <ArrowRight size={16} /></button>
        </article>

        <article className="paper-card locked-card">
          <div className="card-heading">
            <div>
              <p className="eyebrow">PAYLAŞIM ALANI</p>
              <h2><Twitter size={18} /> Twitter köşem</h2>
            </div>
            <LockKeyhole size={17} className="muted-icon" />
          </div>
          <div className="empty-state">
            <span className="empty-mark"><LockKeyhole size={18} /></span>
            <strong>Ortak bağlantılar gösterilmiyor</strong>
            <p>Bu demo gerçek tweet URL'lerini veya kişisel bağlantıları içermiyor.</p>
          </div>
          <div className="card-footnote"><BookOpen size={14} /> Sunucuya bağlı içerik kapalı</div>
        </article>

        <article className="paper-card note-card">
          <div className="card-kicker"><ChartNoAxesColumnIncreasing size={16} /> DEMO BİLGİSİ</div>
          <h2>Örnek veriler, gerçek hesap değil.</h2>
          <p>Ders, net ve çalışma süreleri yalnızca arayüzü göstermek için kullanılır. Gerçek kullanıcı geçmişi bu pakete eklenmez.</p>
          <div className="note-divider" />
          <p className="note-small"><Clock3 size={14} /> Pomodoro turu paylaşımlı bir veritabanına kaydedilmez.</p>
        </article>
      </div>
    </section>
  );
}
