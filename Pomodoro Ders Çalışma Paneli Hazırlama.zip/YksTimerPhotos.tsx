import { useCallback, useEffect, useRef, useState, type ChangeEvent } from "react";
import {
  CalendarDays,
  Camera,
  ChevronDown,
  ImagePlus,
  LoaderCircle,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useIstanbulTodayKey } from "@/hooks/useIstanbulTodayKey";

type TimerPhoto = {
  dayKey: string;
  url: string;
  uploadedAt: Date;
};

type YksTimerPhotosProps = {
  mode: "owner" | "public";
};

const JPEG_PREFIX = "data:image/jpeg;base64,";
const MAX_INPUT_BYTES = 12 * 1024 * 1024;
const MAX_OUTPUT_BYTES = 3 * 1024 * 1024;
const MAX_OUTPUT_DATA_URL_LENGTH =
  JPEG_PREFIX.length + 4 * Math.ceil(MAX_OUTPUT_BYTES / 3);
const MAX_IMAGE_EDGE = 1600;

function compressPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Lütfen bir fotoğraf dosyası seç."));
      return;
    }
    if (file.size > MAX_INPUT_BYTES) {
      reject(new Error("Seçilen dosya 12 MB'den küçük olmalı."));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Fotoğraf okunamadı."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () =>
        reject(
          new Error("Bu fotoğraf açılamadı. JPEG, PNG veya WebP deneyebilirsin.")
        );
      image.onload = () => {
        const width = image.naturalWidth;
        const height = image.naturalHeight;
        if (width < 1 || height < 1) {
          reject(new Error("Fotoğrafın boyutları okunamadı."));
          return;
        }

        const scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(width, height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(width * scale));
        canvas.height = Math.max(1, Math.round(height * scale));
        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("Fotoğraf işlenemedi."));
          return;
        }

        try {
          context.fillStyle = "#ffffff";
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          for (const quality of [0.84, 0.74, 0.64, 0.54, 0.44]) {
            const dataUrl = canvas.toDataURL("image/jpeg", quality);
            if (dataUrl.length <= MAX_OUTPUT_DATA_URL_LENGTH) {
              resolve(dataUrl);
              return;
            }
          }
          reject(
            new Error(
              "Sıkıştırılmış fotoğraf 3 MB sınırını aşıyor. Daha küçük bir fotoğraf seç."
            )
          );
        } catch {
          reject(new Error("Fotoğraf JPEG biçimine dönüştürülemedi."));
        }
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function formatPhotoDay(dayKey: string): string {
  const date = new Date(`${dayKey}T12:00:00.000Z`);
  return new Intl.DateTimeFormat("tr-TR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(date);
}

function PhotoLightbox({
  photo,
  onClose,
}: {
  photo: TimerPhoto | null;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!photo) return;
    const previousOverflow = document.body.style.overflow;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [photo, onClose]);

  if (!photo) return null;
  return (
    <div
      className="photo-lightbox-backdrop fixed inset-0 z-[100] flex items-center justify-center bg-[rgba(22,16,10,0.88)] p-4 backdrop-blur-sm sm:p-8"
      role="dialog"
      aria-modal="true"
      aria-label={`${formatPhotoDay(photo.dayKey)} kronometre fotoğrafı`}
      onClick={event => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <button
        type="button"
        autoFocus
        onClick={onClose}
        aria-label="Fotoğrafı kapat"
        className="absolute right-4 top-4 grid h-11 w-11 place-items-center rounded-full border border-white/30 bg-black/35 text-white transition hover:bg-black/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
      >
        <X className="h-6 w-6" aria-hidden="true" />
      </button>
      <figure className="flex max-h-[90vh] flex-col items-center gap-3">
        <img
          src={photo.url}
          alt={`Eray'ın ${formatPhotoDay(photo.dayKey)} kronometre fotoğrafı`}
          className="photo-lightbox-image max-h-[82vh] max-w-[92vw] rounded-md object-contain shadow-[0_24px_80px_rgba(0,0,0,0.45)]"
          decoding="async"
        />
        <figcaption className="rounded-full border border-white/20 bg-black/35 px-4 py-2 text-sm font-semibold capitalize text-white">
          {formatPhotoDay(photo.dayKey)}
        </figcaption>
      </figure>
    </div>
  );
}

function PhotoGrid({
  photos,
  onOpen,
}: {
  photos: TimerPhoto[];
  onOpen: (photo: TimerPhoto) => void;
}) {
  return (
    <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {photos.map(photo => (
        <li key={photo.dayKey} className="min-w-0">
          <button
            type="button"
            onClick={() => onOpen(photo)}
            aria-label={`${formatPhotoDay(photo.dayKey)} kronometre fotoğrafını büyüt`}
            className="group block w-full overflow-hidden rounded-xl border border-[#e2d5bb] bg-white/75 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md motion-reduce:transition-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sage-ink"
          >
            <img
              src={photo.url}
              alt={`Eray'ın ${formatPhotoDay(photo.dayKey)} kronometre fotoğrafı`}
              className="aspect-square w-full bg-[#27251f] object-contain transition-transform duration-300 group-hover:scale-[1.03] motion-reduce:transition-none"
              loading="lazy"
              decoding="async"
            />
            <span className="block truncate px-3 py-2 text-xs font-semibold capitalize text-ink-soft">
              {formatPhotoDay(photo.dayKey)}
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}

export default function YksTimerPhotos({ mode }: YksTimerPhotosProps) {
  const isOwner = mode === "owner";
  const todayKey = useIstanbulTodayKey();
  const [selectedDay, setSelectedDay] = useState(todayKey);
  const [expanded, setExpanded] = useState(false);
  const [preview, setPreview] = useState<TimerPhoto | null>(null);
  const [isPreparing, setIsPreparing] = useState(false);
  const closePreview = useCallback(() => setPreview(null), []);
  const inputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();
  const photosQuery = trpc.dailyTimerPhotos.list.useQuery(undefined, {
    refetchInterval: 60_000,
  });
  const photos = photosQuery.data ?? [];
  const selectedPhoto = photos.find(photo => photo.dayKey === selectedDay);
  const replacePhoto = trpc.dailyTimerPhotos.replace.useMutation({
    onSuccess: async () => {
      await utils.dailyTimerPhotos.list.invalidate();
      toast.success("Kronometre fotoğrafı güne eklendi.");
    },
  });

  const choosePhoto = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    if (!file) return;
    setIsPreparing(true);
    try {
      const imageData = await compressPhoto(file);
      await replacePhoto.mutateAsync({ dayKey: selectedDay, imageData });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Fotoğraf yüklenemedi."
      );
    } finally {
      setIsPreparing(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  if (!isOwner) {
    return (
      <>
        <section
          className="plate relative overflow-hidden rounded-md p-4 sm:p-5"
          aria-labelledby="public-timer-photos-title"
        >
          <span className="screw top-2 left-2" />
          <span className="screw top-2 right-2" />
          <header className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="smallcaps">GÜNLÜK İLERLEME · SALT OKUNUR</p>
              <h2
                id="public-timer-photos-title"
                className="mt-1 font-display text-2xl font-bold text-ink"
              >
                Eray&apos;ın kronometre fotoğrafları
              </h2>
              <p className="mt-1 text-sm text-ink-faint">
                Her görsel, Eray&apos;ın o gün paylaştığı çalışma süresi kaydıdır.
              </p>
            </div>
            <span className="rounded-full border border-[#bfd5b6] bg-[#e8f0e3] px-3 py-1.5 text-sm font-bold tabular-nums text-[#42613c]">
              {photos.length} gün
            </span>
          </header>

          {photosQuery.isLoading ? (
            <p className="rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-6 text-center text-sm text-ink-faint" role="status">
              Kronometre fotoğrafları yükleniyor…
            </p>
          ) : photosQuery.isError ? (
            <p className="rounded-xl border border-[#e7c4b5] bg-[#fff5f0] p-5 text-sm text-[#8d4a3c]" role="alert">
              Kronometre fotoğrafları şu anda yüklenemedi.
            </p>
          ) : photos.length ? (
            <PhotoGrid photos={photos} onOpen={setPreview} />
          ) : (
            <p className="rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-6 text-center text-sm text-ink-faint">
              Eray henüz kronometre fotoğrafı yüklemedi.
            </p>
          )}
        </section>
        <PhotoLightbox photo={preview} onClose={closePreview} />
      </>
    );
  }

  const busy = isPreparing || replacePhoto.isPending;

  return (
    <section className="space-y-4" aria-label="Kronometre fotoğrafları">
      <button
        type="button"
        aria-expanded={expanded}
        aria-controls="yks-timer-photos-content"
        onClick={() => setExpanded(value => !value)}
        className="group relative mx-auto flex aspect-square w-full max-w-[350px] flex-col items-stretch justify-between gap-4 overflow-hidden rounded-2xl border border-[#c9d6c4] bg-gradient-to-br from-[#e3eee2] via-[#fdf9ee] to-[#e8eef4] p-5 text-left shadow-[0_22px_48px_-28px_rgba(69,52,29,0.58)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_54px_-28px_rgba(69,52,29,0.65)] motion-reduce:transition-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-sage-ink sm:max-w-[380px] sm:rounded-[1.75rem] sm:p-7"
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-10 -top-16 h-64 w-64 rounded-full border border-white/55 bg-white/20 shadow-[0_0_0_18px_rgba(255,255,255,0.12),0_0_0_38px_rgba(255,255,255,0.08)] transition duration-500 group-hover:scale-110 motion-reduce:transition-none"
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute bottom-[-4.5rem] right-20 h-40 w-40 rounded-full bg-[#a8c99a]/25 blur-2xl"
        />
        <span className="relative z-10 flex flex-1 flex-col items-start gap-4">
          <span className="grid h-16 w-16 place-items-center rounded-2xl border border-white/70 bg-white/60 text-sage-ink shadow-[0_12px_26px_-16px_rgba(90,66,34,0.65)] transition duration-500 group-hover:rotate-[-6deg] group-hover:scale-110 motion-reduce:transition-none sm:h-[4.5rem] sm:w-[4.5rem]">
            <Camera className="h-8 w-8 sm:h-9 sm:w-9" strokeWidth={1.6} aria-hidden="true" />
          </span>
          <span className="min-w-0">
            <span className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-[#b8c8a9]/80 bg-white/50 px-3 py-1 text-[0.65rem] font-bold tracking-[0.18em] text-[#4d6a46]">
              GÜNLÜK ÇALIŞMA KAYDI
            </span>
            <span className="block font-display text-xl font-bold leading-tight text-[#302719] sm:text-2xl">
              Kronometre Fotoğrafları
            </span>
            <span className="mt-2 block text-sm leading-relaxed text-[#685c48]">
              Her gün çalıştığın süreyi fotoğrafla kaydet.
            </span>
            <span className="mt-3 inline-flex rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#4e6d49]">
              {photos.length} günün fotoğrafı
            </span>
          </span>
        </span>
        <span className="relative z-10 flex w-full items-center justify-between border-t border-[#71866a]/20 pt-3">
          <span className="text-xs font-bold tracking-wide text-[#526f4b]">
            {expanded ? "KAPAT" : "FOTOĞRAF YÜKLE / GEÇMİŞİ GÖR"}
          </span>
          <span className="grid h-11 w-11 place-items-center rounded-full border border-white/75 bg-white/60 text-[#526f4b] shadow-md transition duration-300 group-hover:scale-110 group-hover:bg-white motion-reduce:transition-none">
            <ChevronDown className={`h-5 w-5 transition-transform duration-500 motion-reduce:transition-none ${expanded ? "rotate-180" : ""}`} aria-hidden="true" />
          </span>
        </span>
      </button>

      <div
        id="yks-timer-photos-content"
        aria-hidden={!expanded}
        inert={!expanded}
        className={`grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,0.8,0.3,1)] motion-reduce:transition-none ${expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
      >
        <div className="min-h-0 overflow-hidden">
          {expanded ? (
            <section className="yks-panel-open plate relative overflow-hidden rounded-md p-4 sm:p-5" aria-labelledby="timer-photos-management-title">
              <span className="screw top-2 left-2" />
              <span className="screw top-2 right-2" />
              <header className="mb-4 flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="smallcaps">GÜN GÜN KRONOMETRE ARŞİVİ</p>
                  <h2 id="timer-photos-management-title" className="mt-1 font-display text-2xl font-bold text-ink sm:text-3xl">
                    Çalışma fotoğrafı ekle
                  </h2>
                  <p className="mt-1 text-sm text-ink-faint">Seçtiğin gün için tek fotoğraf saklanır; yeniden yüklersen o günün fotoğrafı güncellenir.</p>
                </div>
                <span className="rounded-full border border-[#bfd5b6] bg-[#e8f0e3] px-3 py-1.5 text-sm font-bold text-[#42613c]">
                  {photos.length} gün kayıtlı
                </span>
              </header>

              <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
                <div className="rounded-2xl border border-[#e2d5bb] bg-white/55 p-4">
                  <label htmlFor="timer-photo-day" className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink-soft">
                    <CalendarDays className="h-4 w-4 text-sage-ink" aria-hidden="true" /> Çalışma gününü seç
                  </label>
                  <input
                    id="timer-photo-day"
                    type="date"
                    value={selectedDay}
                    max={todayKey}
                    onChange={event => setSelectedDay(event.target.value)}
                    className="h-11 w-full rounded-lg border border-[#ddcda9] bg-white/90 px-3 text-sm text-ink outline-none focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/15"
                  />
                  <input
                    ref={inputRef}
                    type="file"
                    accept="image/*"
                    className="sr-only"
                    aria-label="Seçilen gün için kronometre fotoğrafı seç"
                    onChange={event => void choosePhoto(event)}
                  />
                  <button
                    type="button"
                    onClick={() => inputRef.current?.click()}
                    disabled={busy || !selectedDay}
                    className="mt-3 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#b45309] to-[#ce741a] px-4 text-sm font-bold text-[#fffaf0] shadow-[0_8px_16px_-9px_rgba(120,63,10,0.8)] transition hover:-translate-y-0.5 hover:brightness-105 motion-reduce:transition-none disabled:cursor-not-allowed disabled:opacity-55"
                  >
                    {busy ? <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" /> : selectedPhoto ? <ImagePlus className="h-4 w-4" aria-hidden="true" /> : <Upload className="h-4 w-4" aria-hidden="true" />}
                    {isPreparing ? "Fotoğraf hazırlanıyor…" : replacePhoto.isPending ? "Yükleniyor…" : selectedPhoto ? "Fotoğrafı değiştir" : "Fotoğraf yükle"}
                  </button>
                  <p className="mt-2 text-xs leading-relaxed text-ink-faint">En fazla 12 MB’lık görsel seçebilirsin; yüklemeden önce JPEG’e dönüştürülür ve küçültülür.</p>
                </div>

                <div className="min-w-0">
                  <h3 className="mb-2 text-sm font-semibold capitalize text-ink-soft">{formatPhotoDay(selectedDay)}</h3>
                  {photosQuery.isLoading ? (
                    <p className="rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-6 text-center text-sm text-ink-faint" role="status">Fotoğraf arşivi yükleniyor…</p>
                  ) : selectedPhoto ? (
                    <button type="button" onClick={() => setPreview(selectedPhoto)} aria-label={`${formatPhotoDay(selectedDay)} fotoğrafını büyüt`} className="block w-full max-w-sm overflow-hidden rounded-xl border border-[#e2d5bb] bg-white p-2 shadow-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sage-ink">
                      <img src={selectedPhoto.url} alt={`${formatPhotoDay(selectedDay)} kronometre fotoğrafı`} className="aspect-square w-full rounded-lg object-contain" decoding="async" />
                    </button>
                  ) : (
                    <div className="flex aspect-square w-full max-w-sm flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-6 text-center text-ink-faint">
                      <Camera className="h-9 w-9 text-sage-ink/70" aria-hidden="true" />
                      <p className="text-sm">Bu gün için henüz kronometre fotoğrafı yüklenmedi.</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-6 border-t border-[rgba(90,66,34,0.14)] pt-5">
                <h3 className="mb-3 font-display text-xl font-bold text-ink">Önceki günlerin fotoğrafları</h3>
                {photosQuery.isError ? (
                  <p className="text-sm text-[#8d4a3c]" role="alert">Fotoğraf arşivi yüklenemedi. Yeniden deneyebilirsin.</p>
                ) : photos.length ? (
                  <PhotoGrid photos={photos} onOpen={setPreview} />
                ) : (
                  <p className="rounded-xl border border-dashed border-[#d6c5a4] bg-white/45 p-5 text-center text-sm text-ink-faint">Henüz fotoğraf yok. İlk kronometre fotoğrafını seçtiğin güne ekle.</p>
                )}
              </div>
            </section>
          ) : null}
        </div>
      </div>
      <PhotoLightbox photo={preview} onClose={closePreview} />
    </section>
  );
}
