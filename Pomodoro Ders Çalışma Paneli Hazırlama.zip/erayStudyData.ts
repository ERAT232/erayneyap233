import { z } from "zod";

const epochMs = z.number().int().min(0).max(4_102_444_800_000);
const id = z.string().trim().min(1).max(120);
const shortText = z.string().trim().min(1).max(120);
const dayKey = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

export const publicErayDailyTaskSchema = z
  .object({
    id,
    title: shortText,
    completedOn: dayKey.nullable(),
  })
  .strict();
export type PublicErayDailyTask = z.infer<typeof publicErayDailyTaskSchema>;

const studySelectionSchema = z
  .object({
    subjectId: id,
    subjectName: shortText,
    topicId: id,
    topicName: shortText,
  })
  .strict();

const studyEntrySchema = studySelectionSchema
  .extend({
    id,
    source: z.enum(["pomodoro", "manual"]),
    sessionId: id.optional(),
    seconds: z.number().int().min(60).max(86_400),
    dayKey: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    startedAt: epochMs,
    endedAt: epochMs,
  })
  .strict();

const settingsSchema = z
  .object({
    focusMin: z.number().int().min(1).max(120),
    shortMin: z.number().int().min(1).max(120),
    longMin: z.number().int().min(1).max(120),
    longBreakInterval: z.number().int().min(2).max(8),
    autoStartNext: z.boolean(),
    soundEnabled: z.boolean(),
    notifyEnabled: z.boolean(),
    dailyGoal: z.number().int().min(1).max(24),
  })
  .strict();

const taskSchema = z
  .object({
    id,
    title: z.string().max(80),
    estimate: z.number().int().min(1).max(24),
    done: z.boolean(),
    completed: z.number().int().min(0).max(9_999),
    createdAt: epochMs,
  })
  .strict();

const timerSchema = z
  .object({
    phase: z.enum(["focus", "short", "long"]),
    running: z.boolean(),
    endAt: epochMs.nullable(),
    remainingSec: z.number().int().min(0).max(86_400),
    startedAt: epochMs.nullable(),
    cycle: z.number().int().min(0).max(999),
    studySelection: studySelectionSchema.nullable(),
  })
  .strict();

const sessionSchema = z
  .object({
    id,
    phase: z.enum(["focus", "short", "long"]),
    taskId: id.nullable(),
    taskTitle: z.string().max(80),
    startedAt: epochMs,
    endedAt: epochMs,
    plannedSec: z.number().int().min(0).max(86_400),
    actualSec: z.number().int().min(0).max(86_400),
    completed: z.boolean(),
  })
  .strict();

const dayTotalsSchema = z
  .object({
    pomodoros: z.number().int().min(0).max(9_999),
    focusSeconds: z.number().int().min(0).max(86_400),
  })
  .strict();

const subjectSchema = z
  .object({
    id,
    name: shortText,
    topics: z.array(z.object({ id, name: shortText }).strict()).max(120),
  })
  .strict();

const bookSchema = z
  .object({
    id,
    title: z.string().trim().min(1).max(100),
    cover: z
      .string()
      .max(600_000)
      .nullable()
      .refine(
        value =>
          value === null ||
          /^data:image\/jpeg;base64,[A-Za-z0-9+/]+=*$/.test(value),
        "Kitap kapağı JPEG olmalı."
      ),
    totalPages: z.number().int().min(1).max(100_000),
    solvedPages: z.number().int().min(0).max(100_000),
  })
  .strict()
  .refine(
    book => book.solvedPages <= book.totalPages,
    "Çözülen sayfa toplam sayfayı aşamaz."
  );

const programSchema = z
  .object({
    id,
    name: z.string().trim().min(1).max(120),
    requiredNet: z.number().min(0).max(120),
  })
  .strict();

function answersFor(max: number) {
  return z
    .object({
      correct: z.number().int().min(0).max(max),
      wrong: z.number().int().min(0).max(max),
    })
    .strict()
    .refine(
      answer => answer.correct + answer.wrong <= max,
      "Doğru ve yanlış toplamı soru sayısını aşamaz."
    );
}

const tytResultsSchema = z
  .object({
    turkce: answersFor(40),
    sosyal: answersFor(20),
    matematik: answersFor(40),
    fen: answersFor(20),
  })
  .strict();

const tytSchema = z
  .object({
    version: z.literal(1),
    goals: z
      .object({
        turkce: z.number().min(0).max(40).nullable(),
        sosyal: z.number().min(0).max(20).nullable(),
        matematik: z.number().min(0).max(40).nullable(),
        fen: z.number().min(0).max(20).nullable(),
      })
      .strict(),
    exams: z
      .array(
        z
          .object({
            id,
            name: z.string().trim().min(1).max(100),
            createdAt: z.string().min(1).max(40),
            results: tytResultsSchema,
          })
          .strict()
      )
      .max(200),
  })
  .strict();

/**
 * Only Eray's study workspace is serializable here. Private CHEAT messages,
 * credentials, notifications, daily notes and wheel spins have no fields in
 * this schema and therefore cannot enter the public endpoint through it.
 */
export const publicErayStudySnapshotSchema = z
  .object({
    version: z.literal(1),
    pomodoro: z
      .object({
        settings: settingsSchema,
        tasks: z.array(taskSchema).max(500),
        activeTaskId: id.nullable(),
        timer: timerSchema,
        sessions: z.array(sessionSchema).max(400),
        history: z.record(
          z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
          dayTotalsSchema
        ),
        studyEntries: z.array(studyEntrySchema).max(3_000),
      })
      .strict(),
    subjects: z.array(subjectSchema).max(60),
    books: z.array(bookSchema).max(25),
    programs: z.array(programSchema).max(100),
    dailyTasks: z.array(publicErayDailyTaskSchema).max(80).optional(),
    tyt: tytSchema,
  })
  .strict()
  .superRefine((snapshot, context) => {
    if (snapshot.books.some(book => book.solvedPages > book.totalPages)) {
      context.addIssue({
        code: "custom",
        message: "Çözülen sayfa toplam sayfayı aşamaz.",
        path: ["books"],
      });
    }
    if (JSON.stringify(snapshot).length > 6_000_000) {
      context.addIssue({
        code: "custom",
        message: "Paylaşılan çalışma verisi 6 MB sınırını aşamaz.",
      });
    }
  });

export type PublicErayStudySnapshot = z.infer<
  typeof publicErayStudySnapshotSchema
>;

export function isNonEmptyErayStudySnapshot(
  snapshot: PublicErayStudySnapshot
): boolean {
  return (
    snapshot.pomodoro.tasks.length > 0 ||
    snapshot.pomodoro.sessions.length > 0 ||
    snapshot.pomodoro.studyEntries.length > 0 ||
    Object.keys(snapshot.pomodoro.history).length > 0 ||
    snapshot.subjects.length > 0 ||
    snapshot.books.length > 0 ||
    snapshot.programs.length > 0 ||
    (snapshot.dailyTasks?.length ?? 0) > 0 ||
    snapshot.tyt.exams.length > 0 ||
    Object.values(snapshot.tyt.goals).some(value => value !== null)
  );
}
