import { useRef, useState, type ChangeEvent } from "react";
import { ImagePlus, LoaderCircle, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type HomePhotoManagerProps = {
  managerToken: string;
  onSessionExpired: () => void;
};

const MAX_INPUT_BYTES = 12 * 1024 * 1024;
const MAX_OUTPUT_BYTES = 3 * 1024 * 1024;
const MAX_OUTPUT_DATA_URL_LENGTH = "data:image/jpeg;base64,".length + 4 * Math.ceil(MAX_OUTPUT_BYTES / 3);
const MAX_IMAGE_EDGE = 1600;

/** Keep the full image, resize only when needed, and produce a server-validated JPEG. */
function compressPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Lütfen bir fotoğraf dosyası seç."));
      return;
    }
    if (file.size > MAX_INPUT_BYTES) {
      reject(new Error("Seçilen dosya 12 MB'den küçük olmalı."));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Fotoğraf okunamadı."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("Bu fotoğraf açılamadı. JPEG, PNG veya WebP dosyası deneyebilirsin."));
      image.onload = () => {
        const sourceWidth = image.naturalWidth;
        const sourceHeight = image.naturalHeight;
        if (sourceWidth < 1 || sourceHeight < 1) {
          reject(new Error("Fotoğrafın boyutları okunamadı."));
          return;
        }

        const scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(sourceWidth, sourceHeight));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(sourceWidth * scale));
        canvas.height = Math.max(1, Math.round(sourceHeight * scale));
        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("Fotoğraf işlenemedi."));
          return;
        }

        try {
          context.fillStyle = "#ffffff";
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          for (const quality of [0.84, 0.74, 0.64, 0.54, 0.44]) {
            const dataUrl = canvas.toDataURL("image/jpeg", quality);
            if (dataUrl.length <= MAX_OUTPUT_DATA_URL_LENGTH) {
              resolve(dataUrl);
              return;
            }
          }
          reject(new Error("Sıkıştırılmış fotoğraf 3 MB sınırını aşıyor. Daha küçük bir fotoğraf seç."));
        } catch {
          reject(new Error("Fotoğraf JPEG biçimine dönüştürülemedi."));
        }
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export default function HomePhotoManager({ managerToken, onSessionExpired }: HomePhotoManagerProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isPreparing, setIsPreparing] = useState(false);
  const utils = trpc.useUtils();
  const photo = trpc.homePhoto.current.useQuery(undefined, { enabled: Boolean(managerToken) });

  const replace = trpc.homePhoto.replace.useMutation({
    onSuccess: async () => {
      await utils.homePhoto.current.invalidate();
      toast.success("Ana sayfa fotoğrafı güncellendi.");
    },
    onError: error => {
      if (error.data?.code === "FORBIDDEN") onSessionExpired();
      toast.error(error.message || "Fotoğraf yüklenemedi.");
    },
  });

  const remove = trpc.homePhoto.remove.useMutation({
    onSuccess: async () => {
      await utils.homePhoto.current.invalidate();
      toast.success("Fotoğraf ana sayfadan kaldırıldı.");
    },
    onError: error => {
      if (error.data?.code === "FORBIDDEN") onSessionExpired();
      toast.error(error.message || "Fotoğraf kaldırılamadı.");
    },
  });

  const choosePhoto = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    if (!file) return;
    setIsPreparing(true);
    try {
      const imageData = await compressPhoto(file);
      replace.mutate({ managerToken, imageData });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Fotoğraf eklenemedi.");
    } finally {
      setIsPreparing(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const deletePhoto = () => {
    if (!photo.data?.url || !window.confirm("Fotoğraf ana sayfadan kaldırılsın mı?")) return;
    remove.mutate({ managerToken });
  };

  const busy = isPreparing || replace.isPending || remove.isPending;

  return (
    <section className="mt-5 rounded-md border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.88)] p-4 shadow-sm sm:p-5" aria-labelledby="home-photo-manager-title">
      <div className="mb-4 flex items-start gap-3">
        <ImagePlus className="mt-0.5 h-5 w-5 shrink-0 text-amber-ink" aria-hidden="true" />
        <div>
          <h2 id="home-photo-manager-title" className="font-display text-lg font-semibold text-ink">Ana sayfa fotoğrafı</h2>
          <p className="mt-1 text-sm leading-6 text-ink-faint">Ana ekranda tek bir fotoğraf görünür. Yeni fotoğraf yüklersen mevcut fotoğrafın yerini alır.</p>
        </div>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="sr-only"
        aria-label="Ana sayfa için fotoğraf seç"
        onChange={event => void choosePhoto(event)}
      />

      <div className="mb-4 flex min-h-36 items-center justify-center overflow-hidden rounded-sm border border-[rgba(90,66,34,0.2)] bg-white/60 p-2">
        {photo.isLoading ? (
          <p className="text-sm text-ink-faint" role="status">Fotoğraf bilgisi yükleniyor…</p>
        ) : photo.isError ? (
          <p className="text-sm text-destructive" role="alert">Mevcut fotoğraf bilgisi yüklenemedi.</p>
        ) : photo.data?.url ? (
          <img src={photo.data.url} alt="Mevcut ana sayfa fotoğrafı" className="block max-h-56 max-w-full object-contain" />
        ) : (
          <p className="text-sm text-ink-faint">Henüz fotoğraf yüklenmedi.</p>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          className="inline-flex h-10 items-center gap-2 rounded-sm bg-amber-ink px-4 text-sm font-semibold text-[#fffaf0] transition hover:bg-[#914206] disabled:cursor-not-allowed disabled:opacity-60"
        >
          {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          {isPreparing ? "Fotoğraf hazırlanıyor…" : replace.isPending ? "Yükleniyor…" : photo.data?.url ? "Fotoğrafı değiştir" : "Fotoğraf yükle"}
        </button>
        {photo.data?.url && (
          <button
            type="button"
            onClick={deletePhoto}
            disabled={busy}
            className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(145,31,23,0.35)] px-4 text-sm font-semibold text-destructive transition hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {remove.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            Fotoğrafı sil
          </button>
        )}
      </div>
      <p className="mt-3 text-xs text-ink-faint">En fazla 12 MB’lık görsel seçebilirsin; yüklemeden önce JPEG’e dönüştürülüp küçültülür.</p>
    </section>
  );
}
