import { BookOpen, GraduationCap, Target } from "lucide-react";
import YksCountdown from "../components/YksCountdown";

const subjects = [
  { name: "Türkçe", detail: "Paragraf · Dil bilgisi", progress: 68, color: "#b45309" },
  { name: "Matematik", detail: "Problemler · Fonksiyonlar", progress: 46, color: "#5b7a54" },
  { name: "Sosyal", detail: "Tarih · Coğrafya", progress: 59, color: "#4c6b8a" },
  { name: "Fen", detail: "Fizik · Kimya · Biyoloji", progress: 37, color: "#9b5d69" },
];

const books = [
  { title: "TYT Türkçe Soru Bankası", subject: "Türkçe", done: 172, total: 320 },
  { title: "Matematik Problemler", subject: "Matematik", done: 94, total: 240 },
  { title: "Fen Bilimleri Denemeleri", subject: "Fen", done: 38, total: 160 },
];

const exams = [
  { title: "Örnek TYT Denemesi 01", net: 74.5, subject: "Türkçe 29 · Sosyal 13 · Mat. 22 · Fen 10.5" },
  { title: "Örnek TYT Denemesi 02", net: 78.25, subject: "Türkçe 31 · Sosyal 12.5 · Mat. 23 · Fen 11.75" },
  { title: "Örnek TYT Denemesi 03", net: 81.0, subject: "Türkçe 32 · Sosyal 13 · Mat. 24 · Fen 12" },
];

export default function YksPage() {
  return (
    <section className="page-section">
      <div className="page-intro">
        <div>
          <p className="eyebrow">YKS 2027 / ÖRNEK ÇALIŞMA ALANI</p>
          <h1>Hazırlığını adım adım gör.</h1>
          <p>Bu bölümdeki ders, kitap ve deneme kayıtları yalnızca örnek arayüz verisidir.</p>
        </div>
        <span className="sample-badge">ÖRNEK VERİ</span>
      </div>

      <div className="yks-top-grid">
        <article className="paper-card countdown-card"><YksCountdown compact /></article>
        <article className="paper-card target-note">
          <div className="card-kicker"><Target size={16} /> HEDEF PROGRAMLAR</div>
          <h2>İlerlemeyi kendi temponla kur.</h2>
          <p>Hedef bölüm ve gereken net alanı bu statik demoda kayıt tutmaz; gerçek hesap özelliği değildir.</p>
          <div className="target-chip-row"><span>Örnek: Bilgisayar Mühendisliği</span><strong>92 net</strong></div>
        </article>
      </div>

      <div className="yks-content-grid">
        <article className="paper-card">
          <div className="card-heading">
            <div><p className="eyebrow">ÖRNEK KONU İLERLEMESİ</p><h2><GraduationCap size={19} /> Derslerim</h2></div>
            <span className="tiny-label">4 DERS</span>
          </div>
          <div className="subject-list">
            {subjects.map((subject) => (
              <div className="subject-card" key={subject.name}>
                <div className="subject-top"><strong>{subject.name}</strong><b>{subject.progress}%</b></div>
                <p>{subject.detail}</p>
                <div className="progress-track"><span style={{ width: `${subject.progress}%`, background: subject.color }} /></div>
              </div>
            ))}
          </div>
        </article>

        <article className="paper-card">
          <div className="card-heading">
            <div><p className="eyebrow">ÖRNEK SAYFA TAKİBİ</p><h2><BookOpen size={19} /> Kitap Takip</h2></div>
            <span className="tiny-label">3 KİTAP</span>
          </div>
          <div className="book-list">
            {books.map((book) => {
              const percent = Math.round((book.done / book.total) * 100);
              return (
                <div className="book-row" key={book.title}>
                  <div className="book-cover" aria-hidden="true"><BookOpen size={20} /></div>
                  <div className="book-info">
                    <span className="book-subject">{book.subject}</span>
                    <strong>{book.title}</strong>
                    <span>{book.done} / {book.total} sayfa · %{percent}</span>
                    <div className="progress-track"><span style={{ width: `${percent}%` }} /></div>
                  </div>
                </div>
              );
            })}
          </div>
        </article>
      </div>

      <article className="paper-card exam-card">
        <div className="card-heading">
          <div><p className="eyebrow">ÖRNEK SONUÇLAR</p><h2>Denemelerim</h2></div>
          <span className="tiny-label">NET ORTALAMASI · 77.9</span>
        </div>
        <div className="exam-list">
          {exams.map((exam) => (
            <div className="exam-row" key={exam.title}>
              <div className="exam-mark"><span style={{ height: `${Math.min(100, exam.net)}%` }} /></div>
              <div className="exam-info"><strong>{exam.title}</strong><span>{exam.subject}</span></div>
              <b className="exam-net">{exam.net.toFixed(exam.net % 1 ? 2 : 0)}</b>
            </div>
          ))}
        </div>
      </article>
    </section>
  );
}
