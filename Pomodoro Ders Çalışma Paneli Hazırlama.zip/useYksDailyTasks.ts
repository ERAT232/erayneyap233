import { useEffect, useState } from "react";
import { getIstanbulDayKey } from "@shared/studyTracking";
import {
  countCompletedDailyTasks,
  normalizeDailyTasksForDay,
} from "@shared/dailyTasks";
import { notifyErayStudyDataChanged } from "@/lib/erayStudyEvents";
import {
  getYksDailyTasksStorageKey,
  parseYksDailyTasks,
  readYksDailyTasks,
  YKS_DAILY_TASK_LIMIT,
  YKS_DAILY_TASK_TITLE_LIMIT,
} from "@/lib/yks/dailyTasksStorage";
import { useIstanbulTodayKey } from "@/hooks/useIstanbulTodayKey";
import type { PublicErayDailyTask } from "@shared/erayStudyData";

function makeId(): string {
  return typeof crypto !== "undefined" &&
    typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export function useYksDailyTasks(
  accountId: string | number | null | undefined
) {
  const storageKey =
    accountId === null || accountId === undefined
      ? null
      : getYksDailyTasksStorageKey(accountId);
  const todayKey = useIstanbulTodayKey();
  const [tasks, setTasks] = useState<PublicErayDailyTask[]>([]);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);

  useEffect(() => {
    if (!storageKey) {
      setTasks([]);
      setLoadedKey(null);
      return;
    }
    setTasks(
      normalizeDailyTasksForDay(readYksDailyTasks(storageKey), getIstanbulDayKey())
    );
    setLoadedKey(storageKey);
  }, [storageKey]);

  useEffect(() => {
    if (!storageKey || loadedKey !== storageKey) return;
    setTasks(current => normalizeDailyTasksForDay(current, todayKey));
  }, [loadedKey, storageKey, todayKey]);

  useEffect(() => {
    if (!storageKey || loadedKey !== storageKey) return;

    const handleStorage = (event: StorageEvent) => {
      if (event.key !== storageKey) return;
      let nextTasks: PublicErayDailyTask[] = [];
      try {
        nextTasks = event.newValue
          ? parseYksDailyTasks(JSON.parse(event.newValue))
          : [];
      } catch {
        nextTasks = [];
      }
      setTasks(normalizeDailyTasksForDay(nextTasks, todayKey));
    };

    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, [loadedKey, storageKey, todayKey]);

  useEffect(() => {
    if (!storageKey || loadedKey !== storageKey) return;
    try {
      const serialized = JSON.stringify(tasks);
      if (localStorage.getItem(storageKey) !== serialized) {
        localStorage.setItem(storageKey, serialized);
        notifyErayStudyDataChanged();
      }
    } catch {
      // Keep the in-memory checklist usable if browser storage is unavailable or full.
    }
  }, [loadedKey, storageKey, tasks]);

  const ready = Boolean(storageKey && loadedKey === storageKey);

  const addTask = (rawTitle: string): boolean => {
    const title = rawTitle.trim().slice(0, YKS_DAILY_TASK_TITLE_LIMIT);
    if (!ready || !title || tasks.length >= YKS_DAILY_TASK_LIMIT) return false;
    setTasks(current =>
      current.length >= YKS_DAILY_TASK_LIMIT
        ? current
        : [...current, { id: makeId(), title, completedOn: null }]
    );
    return true;
  };

  const removeTask = (taskId: string): void => {
    if (!ready) return;
    setTasks(current => {
      const next = current.filter(task => task.id !== taskId);
      return next.length === current.length ? current : next;
    });
  };

  const toggleTask = (taskId: string): void => {
    if (!ready) return;
    setTasks(current =>
      current.map(task =>
        task.id === taskId
          ? {
              ...task,
              completedOn: task.completedOn === todayKey ? null : todayKey,
            }
          : task
      )
    );
  };

  return {
    tasks,
    ready,
    todayKey,
    completedCount: countCompletedDailyTasks(tasks, todayKey),
    addTask,
    removeTask,
    toggleTask,
  };
}
