let ctx: AudioContext | null = null;

type AudioWindow = Window & { webkitAudioContext?: typeof AudioContext };

function ensureContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const Ctor = window.AudioContext ?? (window as AudioWindow).webkitAudioContext;
      if (!Ctor) return null;
      ctx = new Ctor();
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

/** Call from a user gesture so the browser lets the chime play later. */
export function primeAudio(): void {
  ensureContext();
}

function bell(audio: AudioContext, startAt: number, freq: number, dur: number, peak: number): void {
  const osc = audio.createOscillator();
  const gain = audio.createGain();
  const filter = audio.createBiquadFilter();

  osc.type = "triangle";
  osc.frequency.setValueAtTime(freq, startAt);

  filter.type = "lowpass";
  filter.frequency.setValueAtTime(2400, startAt);

  gain.gain.setValueAtTime(0.0001, startAt);
  gain.gain.exponentialRampToValueAtTime(peak, startAt + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, startAt + dur);

  osc.connect(filter);
  filter.connect(gain);
  gain.connect(audio.destination);

  osc.start(startAt);
  osc.stop(startAt + dur + 0.05);
}

/** Mechanical desk-bell motif: brighter when a work round is done. */
export function playChime(kind: "focusEnd" | "breakEnd"): void {
  const audio = ensureContext();
  if (!audio) return;
  const t0 = audio.currentTime + 0.02;
  const notes = kind === "focusEnd" ? [783.99, 1046.5, 1318.51] : [1046.5, 783.99];
  notes.forEach((freq, i) => {
    bell(audio, t0 + i * 0.17, freq, kind === "focusEnd" ? 0.9 : 0.7, kind === "focusEnd" ? 0.22 : 0.17);
  });
}

/** Short confirmation click used by the tab switches. */
export function playTick(): void {
  const audio = ensureContext();
  if (!audio) return;
  bell(audio, audio.currentTime + 0.01, 520, 0.09, 0.06);
}
