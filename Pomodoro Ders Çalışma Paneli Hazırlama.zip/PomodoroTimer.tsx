import { useEffect, useState } from "react";
import { Coffee, Pause, Play, RotateCcw, SkipForward, Timer } from "lucide-react";

type Phase = "focus" | "break";
type TimerState = {
  phase: Phase;
  secondsLeft: number;
  running: boolean;
  completed: number;
};

const FOCUS_SECONDS = 25 * 60;
const BREAK_SECONDS = 5 * 60;
const initialState: TimerState = {
  phase: "focus",
  secondsLeft: FOCUS_SECONDS,
  running: false,
  completed: 0,
};

function formatTime(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export default function PomodoroTimer() {
  const [timer, setTimer] = useState<TimerState>(initialState);
  const duration = timer.phase === "focus" ? FOCUS_SECONDS : BREAK_SECONDS;
  const progress = ((duration - timer.secondsLeft) / duration) * 360;

  useEffect(() => {
    if (!timer.running) return;
    const interval = window.setInterval(() => {
      setTimer((current) => {
        if (!current.running) return current;
        if (current.secondsLeft > 1) return { ...current, secondsLeft: current.secondsLeft - 1 };

        const finishedFocus = current.phase === "focus";
        const nextPhase: Phase = finishedFocus ? "break" : "focus";
        return {
          phase: nextPhase,
          secondsLeft: finishedFocus ? BREAK_SECONDS : FOCUS_SECONDS,
          running: false,
          completed: current.completed + (finishedFocus ? 1 : 0),
        };
      });
    }, 1_000);
    return () => window.clearInterval(interval);
  }, [timer.running]);

  const startOrPause = () => {
    setTimer((current) => ({ ...current, running: !current.running }));
  };

  const reset = () => {
    setTimer((current) => ({ ...initialState, completed: current.completed }));
  };

  const skipPhase = () => {
    setTimer((current) => {
      const nextPhase: Phase = current.phase === "focus" ? "break" : "focus";
      return {
        ...current,
        phase: nextPhase,
        secondsLeft: nextPhase === "focus" ? FOCUS_SECONDS : BREAK_SECONDS,
        running: false,
      };
    });
  };

  return (
    <section className="page-section pomodoro-page">
      <div className="page-intro">
        <div>
          <p className="eyebrow">ODAK OTURUMU</p>
          <h1>Şimdi tek bir işe odaklan.</h1>
          <p>25 dakika odaklan, ardından kısa bir nefes arası ver. Bu sayaç tarayıcıda çalışır; oturumlar başka kişilerle paylaşılmaz.</p>
        </div>
        <span className="sample-badge">YEREL DEMO</span>
      </div>

      <div className="paper-card timer-card">
        <div className="timer-topline">
          <span className={timer.phase === "focus" ? "phase-label focus-label" : "phase-label break-label"}>
            {timer.phase === "focus" ? <Timer size={16} /> : <Coffee size={16} />}
            {timer.phase === "focus" ? "Odak zamanı" : "Kısa mola"}
          </span>
          <span className="timer-state">{timer.running ? "Çalışıyor" : "Duraklatıldı"}</span>
        </div>

        <div className="timer-face" style={{ background: `conic-gradient(#b45309 ${progress}deg, #e6d6b5 ${progress}deg 360deg)` }}>
          <div className="timer-face-inner">
            <span className="timer-caption">KALAN SÜRE</span>
            <strong className="timer-digits" aria-live="off">{formatTime(timer.secondsLeft)}</strong>
            <span className="timer-subtitle">{timer.phase === "focus" ? "dikkatini koru" : "biraz dinlen"}</span>
          </div>
        </div>

        <div className="timer-actions">
          <button className="button-primary" onClick={startOrPause}>
            {timer.running ? <Pause size={17} /> : <Play size={17} />}
            {timer.running ? "Duraklat" : "Başlat"}
          </button>
          <button className="button-secondary" onClick={reset}>
            <RotateCcw size={16} /> Sıfırla
          </button>
          <button className="button-quiet" onClick={skipPhase}>
            <SkipForward size={16} /> Sonraki aşama
          </button>
        </div>

        <div className="timer-bottomline">
          <span>Bu oturumda tamamlanan odak turu</span>
          <strong>{timer.completed}</strong>
        </div>
      </div>

      <div className="local-note">
        <Coffee size={19} />
        <p><strong>Bu sayaç sunucusuz çalışır.</strong> Sayfayı yenilediğinde oturum sıfırlanır; hesap, veritabanı kaydı veya ortak çalışma durumu oluşturulmaz.</p>
      </div>
    </section>
  );
}
