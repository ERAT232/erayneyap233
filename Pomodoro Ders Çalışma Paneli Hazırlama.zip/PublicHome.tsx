import {
  Activity,
  BookOpen,
  Clock3,
  GraduationCap,
  MessageCircle,
  PanelsTopLeft,
  Target,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import HomeFeaturedPhoto from "@/components/HomeFeaturedPhoto";
import NewsTicker from "@/components/NewsTicker";
import TwitterCorner from "@/components/TwitterCorner";
import MemberLogoutButton from "@/components/MemberLogoutButton";
import YksCountdown from "@/components/YksCountdown";
import { trpc } from "@/lib/trpc";
import { includeManualStudyFocusHistory } from "@shared/studyTracking";
import {
  calculateTytAverages,
  getTytNetChartSegment,
  TYT_SUBJECTS,
} from "@shared/tyt";

function formatNet(value: number | null): string {
  return value === null
    ? "—"
    : value.toLocaleString("tr-TR", { maximumFractionDigits: 2 });
}

function formatMinutes(seconds: number): string {
  const minutes = Math.floor(Math.max(0, seconds) / 60);
  const hours = Math.floor(minutes / 60);
  return hours > 0 ? `${hours} sa ${minutes % 60} dk` : `${minutes} dk`;
}

export default function PublicHome() {
  const workspace = trpc.erayStudyData.view.useQuery(undefined, {
    refetchInterval: 60_000,
  });
  const liveStatus = trpc.erayStudyData.status.useQuery(undefined, {
    refetchInterval: 3_000,
    retry: false,
  });
  const snapshot = workspace.data?.snapshot;
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1_000);
    return () => window.clearInterval(timer);
  }, []);

  const pomodoro = snapshot?.pomodoro;
  const timer = liveStatus.data;
  const running = Boolean(
    timer &&
      timer.running &&
      typeof timer.endAt === "number" &&
      timer.endAt > now
  );
  const isFocus = running && timer?.phase === "focus";
  const status = !running
    ? "Eray şu an çalışmıyor"
    : isFocus
      ? "Eray şu an çalışıyor"
      : "Eray şu an molada";
  const statusClass = !running
    ? "border-[rgba(90,66,34,0.22)] bg-white/65 text-ink-soft"
    : isFocus
      ? "border-[#a7c7a8] bg-[#e6f1e5] text-[#456b4a]"
      : "border-[#bfd1e5] bg-[#e9f0f7] text-[#4c6b8a]";
  const remaining =
    running && timer && typeof timer.endAt === "number"
      ? Math.max(0, Math.ceil((timer.endAt - now) / 1_000))
      : (timer?.remainingSec ?? 0);
  const averages = calculateTytAverages(snapshot?.tyt.exams ?? []);
  const totalFocusSeconds = useMemo(() => {
    const history = includeManualStudyFocusHistory(
      pomodoro?.history ?? {},
      pomodoro?.studyEntries ?? []
    );
    return Object.values(history).reduce(
      (total, day) => total + day.focusSeconds,
      0
    );
  }, [pomodoro?.history, pomodoro?.studyEntries]);
  const completedTasks = pomodoro?.tasks.filter(task => task.done).length ?? 0;

  return (
    <div className="desk-glow paper-grain min-h-screen">
      <main className="mx-auto min-h-screen w-full max-w-6xl px-4 sm:px-6">
        <header className="flex flex-wrap items-start justify-between gap-5 py-5">
          <div className="flex min-w-0 flex-col items-start gap-3">
            <YksCountdown />
            <div
              role="status"
              aria-live="polite"
              className={`inline-flex min-h-9 items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold shadow-sm ${statusClass}`}
            >
              <span
                className={`h-2.5 w-2.5 rounded-full ${!running ? "bg-ink-faint" : isFocus ? "bg-[#5b7a54]" : "bg-[#4c6b8a]"}`}
                aria-hidden="true"
              />
              <span>{status}</span>
              {running && (
                <span className="rounded-full bg-white/70 px-2 py-0.5 font-mono tabular-nums">
                  {String(Math.floor(remaining / 60)).padStart(2, "0")}:
                  {String(remaining % 60).padStart(2, "0")}
                </span>
              )}
            </div>
          </div>
          <nav
            className="flex flex-wrap justify-end gap-2"
            aria-label="Ana gezinme"
          >
            <Link
              href="/eray-bugun"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.35)] bg-[rgba(253,248,236,0.85)] px-4 text-sm font-semibold text-ink-soft transition hover:border-amber-ink hover:text-amber-ink"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" /> Sohbet
            </Link>
            <Link
              href="/arayuz"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.35)] bg-[rgba(253,248,236,0.85)] px-4 text-sm font-semibold text-ink-soft transition hover:border-amber-ink hover:text-amber-ink"
            >
              <PanelsTopLeft className="h-4 w-4" aria-hidden="true" /> Arayüz
            </Link>
            <Link
              href="/eray-ne-durumda"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(91,122,84,0.45)] bg-[rgba(91,122,84,0.1)] px-4 text-sm font-semibold text-sage-ink transition hover:bg-[rgba(91,122,84,0.18)]"
            >
              <Activity className="h-4 w-4" aria-hidden="true" /> Eray Ne
              Durumda
            </Link>
            <MemberLogoutButton />
          </nav>
          <div className="ml-auto flex w-full max-w-[22rem] items-start justify-end sm:w-80">
            <HomeFeaturedPhoto />
          </div>
        </header>

        <section
          className="mb-5 grid gap-4 rounded-2xl border border-[#d7c8a7] bg-gradient-to-br from-[#fff9ea] via-[#fcf8ee] to-[#eaf0e4] p-5 shadow-[0_24px_55px_-38px_rgba(76,56,27,0.65)] sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:p-7"
          aria-labelledby="public-home-title"
        >
          <div>
            <p className="smallcaps text-[#6b644e]">ERAY'IN ÇALIŞMA MASASI</p>
            <h1
              id="public-home-title"
              className="mt-1 font-display text-3xl font-bold leading-tight text-ink sm:text-4xl"
            >
              Odak Paneli
            </h1>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-soft">
              Eray'ın çalışma ilerlemesini, YKS hazırlığını ve TYT hedeflerini
              buradan takip edebilirsin. Çalışma alanı salt okunurdur; sohbet ve
              Arayüz üyeler için açıktır.
            </p>
            <p className="mt-3 inline-flex items-center gap-2 rounded-full border border-[#c5d6bd] bg-white/65 px-3 py-1.5 text-xs font-semibold text-[#4e6d49]">
              <span className="h-2 w-2 rounded-full bg-[#5b7a54]" /> Çalışma
              verileri herkese açık · düzenleme yalnız Eray'da
            </p>
          </div>
          <div className="flex flex-wrap gap-2 sm:max-w-64 sm:justify-end">
            <div className="min-w-24 rounded-xl border border-white/80 bg-white/65 p-3 text-center">
              <BookOpen
                className="mx-auto h-5 w-5 text-[#5c7757]"
                aria-hidden="true"
              />
              <p className="mt-1 font-display text-xl font-bold tabular-nums text-ink">
                {workspace.isLoading ? "—" : (snapshot?.subjects.length ?? 0)}
              </p>
              <p className="text-[0.65rem] font-semibold text-ink-faint">
                Ders
              </p>
            </div>
            <div className="min-w-24 rounded-xl border border-white/80 bg-white/65 p-3 text-center">
              <GraduationCap
                className="mx-auto h-5 w-5 text-[#4c6b8a]"
                aria-hidden="true"
              />
              <p className="mt-1 font-display text-xl font-bold tabular-nums text-ink">
                {workspace.isLoading ? "—" : (snapshot?.books.length ?? 0)}
              </p>
              <p className="text-[0.65rem] font-semibold text-ink-faint">
                Kitap
              </p>
            </div>
            <div className="min-w-24 rounded-xl border border-white/80 bg-white/65 p-3 text-center">
              <Clock3
                className="mx-auto h-5 w-5 text-amber-ink"
                aria-hidden="true"
              />
              <p className="mt-1 font-display text-xl font-bold tabular-nums text-ink">
                {workspace.isLoading ? "—" : formatMinutes(totalFocusSeconds)}
              </p>
              <p className="text-[0.65rem] font-semibold text-ink-faint">
                Odak süresi
              </p>
            </div>
          </div>
        </section>

        <NewsTicker />

        {workspace.isError ? (
          <p
            className="mb-5 rounded-xl border border-[#e7c4b5] bg-[#fff5f0] px-4 py-3 text-sm text-[#8d4a3c]"
            role="alert"
          >
            Eray'ın çalışma verileri şu anda yüklenemedi. Biraz sonra yeniden
            dene.
          </p>
        ) : null}

        <div className="grid items-start gap-5 pb-8 lg:grid-cols-[minmax(0,1fr)_minmax(19rem,23rem)]">
          <section
            className="overflow-hidden rounded-2xl border border-[#d6c59f] bg-gradient-to-b from-[#fffdf7] via-[#fbf7ed] to-[#f3eddf] shadow-[0_24px_55px_-35px_rgba(76,56,27,0.65)]"
            aria-labelledby="public-tyt-title"
          >
            <header className="border-b border-[#ddcfb1] bg-gradient-to-r from-[#f5e7c8] via-[#faf3e3] to-[#e7efdf] px-5 py-5">
              <p className="smallcaps flex items-center gap-1.5 text-[#6e644f]">
                <Target className="h-3.5 w-3.5" aria-hidden="true" /> ERAY'IN
                TYT PLANI
              </p>
              <h2
                id="public-tyt-title"
                className="mt-1 font-display text-2xl font-bold text-ink"
              >
                Hedefler ve ortalama netler
              </h2>
              <p className="mt-1 text-xs leading-relaxed text-ink-faint">
                Hedefler, kaydedilen denemelerden hesaplanan ortalamalarla yan
                yana.
              </p>
            </header>
            <div className="space-y-3 px-4 py-4 sm:px-5">
              {TYT_SUBJECTS.map(subject => {
                const target = snapshot?.tyt.goals[subject.id] ?? null;
                const average = averages[subject.id];
                const targetBar = getTytNetChartSegment(
                  target,
                  subject.questionCount
                );
                const averageBar = getTytNetChartSegment(
                  average,
                  subject.questionCount
                );
                return (
                  <article
                    key={subject.id}
                    className="rounded-xl border border-[#e6dcc8] bg-white/70 px-3 py-3"
                  >
                    <div className="mb-2 flex items-center justify-between gap-3">
                      <h3 className="text-sm font-bold text-ink">
                        {subject.label}
                        <span className="ml-2 text-[0.65rem] font-normal text-ink-faint">
                          {subject.questionCount} soru
                        </span>
                      </h3>
                      <span className="text-right text-xs text-ink-soft">
                        Hedef{" "}
                        <strong className="tabular-nums">
                          {formatNet(target)}
                        </strong>
                        <span className="mx-1 text-ink-faint">·</span>Ort.{" "}
                        <strong className="tabular-nums">
                          {formatNet(average)}
                        </strong>
                      </span>
                    </div>
                    <div
                      className="relative h-8 overflow-hidden rounded-lg border border-[#e8e1d2] bg-[#f2eee4]"
                      aria-label={`${subject.label}: hedef ${formatNet(target)}, ortalama ${formatNet(average)}`}
                    >
                      <span
                        className="absolute inset-y-0 border-l border-dashed border-[#8f8268]"
                        style={{ left: `${targetBar.zeroPercent}%` }}
                        aria-hidden="true"
                      />
                      <span
                        className="absolute top-[4px] h-2.5 rounded-full bg-gradient-to-r from-[#eac36c] to-[#c38a2b]"
                        style={{
                          left: `${targetBar.startPercent}%`,
                          width: `${targetBar.sizePercent}%`,
                        }}
                        aria-hidden="true"
                      />
                      <span
                        className="absolute bottom-[4px] h-2.5 rounded-full bg-gradient-to-r from-[#a9c8b6] to-[#5e907d]"
                        style={{
                          left: `${averageBar.startPercent}%`,
                          width: `${averageBar.sizePercent}%`,
                        }}
                        aria-hidden="true"
                      />
                    </div>
                  </article>
                );
              })}
              <p className="text-xs text-ink-faint">
                {snapshot?.tyt.exams.length
                  ? `${snapshot.tyt.exams.length} denemenin ortalaması`
                  : "Henüz deneme kaydı yok."}{" "}
                · {completedTasks} tamamlanan Pomodoro görevi
              </p>
            </div>
          </section>
          <TwitterCorner />
        </div>

        {snapshot?.programs.length ? (
          <section
            className="mb-8 rounded-2xl border border-[#bad6d5] bg-gradient-to-br from-[#e6f0f1] via-[#f8fcfc] to-[#e9f2f1] p-5"
            aria-labelledby="programs-title"
          >
            <p className="smallcaps text-[#396466]">ERAY'IN HEDEFLERİ</p>
            <h2
              id="programs-title"
              className="mt-1 font-display text-xl font-bold text-ink"
            >
              Girmek istediği bölümler
            </h2>
            <ul className="mt-3 flex flex-wrap gap-2">
              {snapshot.programs.map(program => (
                <li
                  key={program.id}
                  className="rounded-full border border-white/80 bg-white/70 px-3 py-1.5 text-sm text-ink-soft"
                >
                  {program.name}{" "}
                  <strong className="ml-1 text-[#396466]">
                    · {formatNet(program.requiredNet)} net
                  </strong>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <footer className="border-t border-[rgba(90,66,34,0.18)] py-5 text-center text-xs leading-relaxed text-ink-faint">
          <p>
            {workspace.data?.updatedAt
              ? `Çalışma verisi son eşitleme: ${new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium", timeStyle: "short" }).format(workspace.data.updatedAt)}`
              : "Eray'ın paylaşılan çalışma alanı"}
          </p>
          <p className="mt-1">
            Hesap bilgileri ve CHEAT mesajları bu herkese açık sayfada
            gösterilmez.
          </p>
        </footer>
      </main>
    </div>
  );
}
