import { useEffect, useState } from "react";
import {
  getYksSubjectsStorageKey,
  readYksSubjects,
  type YksSubject,
} from "@/lib/yks/subjectsStorage";

export function useYksSubjects(accountId: string | number | null | undefined) {
  const storageKey = accountId === null || accountId === undefined
    ? null
    : getYksSubjectsStorageKey(accountId);
  const [subjects, setSubjects] = useState<YksSubject[]>([]);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);

  useEffect(() => {
    if (!storageKey) {
      setSubjects([]);
      setLoadedKey(null);
      return;
    }
    setSubjects(readYksSubjects(storageKey));
    setLoadedKey(storageKey);
  }, [storageKey]);

  return {
    subjects,
    ready: Boolean(storageKey && loadedKey === storageKey),
  };
}
