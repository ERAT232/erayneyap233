import { useMemo, useState, type FormEvent } from "react";
import { Activity, ArrowLeft, CalendarDays, Clock3, Pencil, Save, Trash2, X } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import YksBooks from "@/components/YksBooks";
import { useYksSubjects } from "@/hooks/useYksSubjects";
import { usePomodoro } from "@/hooks/usePomodoro";
import { getIstanbulDayKey, getRecentStudyDays, isStudyDayKey, summarizeStudyDay, type StudyEntry } from "@shared/studyTracking";

const STUDY_COLORS = ["#628b73", "#c68c55", "#6f8eb8", "#b77783", "#8d7aad", "#5d9ba0", "#a7a250", "#d2784f"];
const CHART_HEIGHT = 136;

type EditDraft = {
  id: string;
  subjectId: string;
  topicId: string;
  minutes: string;
  dayKey: string;
};

function subjectColor(id: string): string {
  let hash = 0;
  for (let index = 0; index < id.length; index += 1) hash = (hash * 31 + id.charCodeAt(index)) | 0;
  return STUDY_COLORS[Math.abs(hash) % STUDY_COLORS.length];
}

function formatDuration(seconds: number): string {
  const safeSeconds = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(safeSeconds / 3600);
  const minutes = Math.floor((safeSeconds % 3600) / 60);
  if (hours > 0) return `${hours} sa ${minutes} dk`;
  if (minutes > 0) return `${minutes} dk`;
  return safeSeconds > 0 ? `${safeSeconds} sn` : "0 dk";
}

function formatDay(dayKey: string, options: Intl.DateTimeFormatOptions): string {
  const date = new Date(`${dayKey}T12:00:00.000Z`);
  return new Intl.DateTimeFormat("tr-TR", { ...options, timeZone: "UTC" }).format(date);
}

function formatTime(epochMs: number): string {
  return new Intl.DateTimeFormat("tr-TR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Istanbul",
  }).format(new Date(epochMs));
}

function topicTotals(entries: StudyEntry[]) {
  const totals = new Map<string, { subjectId: string; subjectName: string; topicName: string; seconds: number; pomodoroSeconds: number; manualSeconds: number }>();
  entries.forEach(entry => {
    const key = `${entry.subjectId}\u0000${entry.topicId}`;
    const current = totals.get(key) ?? {
      subjectId: entry.subjectId,
      subjectName: entry.subjectName,
      topicName: entry.topicName,
      seconds: 0,
      pomodoroSeconds: 0,
      manualSeconds: 0,
    };
    current.seconds += entry.seconds;
    if (entry.source === "pomodoro") current.pomodoroSeconds += entry.seconds;
    else current.manualSeconds += entry.seconds;
    totals.set(key, current);
  });
  return [...totals.values()].sort((a, b) => b.seconds - a.seconds);
}

function editedTimestamp(dayKey: string): number {
  return new Date(`${dayKey}T12:00:00+03:00`).getTime();
}

export default function ErayStatusPage() {
  const auth = useAuth();
  const pomo = usePomodoro();
  const { subjects } = useYksSubjects(auth.user?.id);
  const today = getIstanbulDayKey();
  const [selectedDay, setSelectedDay] = useState(today);
  const [editing, setEditing] = useState<EditDraft | null>(null);
  const days = useMemo(() => getRecentStudyDays(pomo.studyEntries, today, 7), [pomo.studyEntries, today]);
  const summary = useMemo(() => summarizeStudyDay(pomo.studyEntries, selectedDay), [pomo.studyEntries, selectedDay]);
  const topics = useMemo(() => topicTotals(summary.entries), [summary.entries]);
  const maxChartSeconds = Math.max(3600, ...days.map(day => day.totalSeconds));
  const allChartSubjects = new Map<string, string>();
  days.forEach(day => day.subjects.forEach(subject => allChartSubjects.set(subject.id, subject.name)));
  const editingEntry = editing ? summary.entries.find(entry => entry.id === editing.id) ?? null : null;
  const editSubject = editing ? subjects.find(subject => subject.id === editing.subjectId) ?? null : null;
  const editTopic = editing ? editSubject?.topics.find(topic => topic.id === editing.topicId) ?? null : null;
  const editSubjectName = editSubject?.name ?? (editingEntry && editing && editingEntry.subjectId === editing.subjectId ? editingEntry.subjectName : "");
  const editTopicName = editTopic?.name ?? (editingEntry && editing && editingEntry.topicId === editing.topicId ? editingEntry.topicName : "");

  const beginEdit = (entry: StudyEntry) => {
    setEditing({
      id: entry.id,
      subjectId: entry.subjectId,
      topicId: entry.topicId,
      minutes: String(Math.max(1, Math.round(entry.seconds / 60))),
      dayKey: entry.dayKey,
    });
  };

  const saveEdit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editing || !editingEntry) return;
    const minutes = Number(editing.minutes);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      toast.error("Süre 1 ile 1.440 dakika arasında tam sayı olmalı.");
      return;
    }
    if (!isStudyDayKey(editing.dayKey) || !editSubjectName || !editTopicName) {
      toast.error("Tarih, ders ve konu alanlarını kontrol et.");
      return;
    }
    const seconds = minutes * 60;
    const endedAt = editedTimestamp(editing.dayKey);
    pomo.updateStudyEntry(editing.id, {
      subjectId: editing.subjectId,
      subjectName: editSubjectName,
      topicId: editing.topicId,
      topicName: editTopicName,
      seconds,
      dayKey: editing.dayKey,
      startedAt: endedAt - seconds * 1000,
      endedAt,
    });
    setEditing(null);
    toast.success("Çalışma kaydı güncellendi.");
  };

  const removeEntry = (entry: StudyEntry) => {
    pomo.deleteStudyEntry(entry.id);
    if (editing?.id === entry.id) setEditing(null);
    toast.success("Çalışma kaydı silindi.");
  };

  return (
    <main className="desk-glow paper-grain min-h-screen px-4 py-7 sm:px-6 sm:py-10">
      <div className="mx-auto w-full max-w-7xl">
        <header className="mb-7 flex flex-wrap items-center justify-between gap-4 border-b border-[rgba(90,66,34,0.2)] pb-5">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/75 bg-white/60 text-sage-ink shadow-sm">
              <Activity className="h-6 w-6" aria-hidden="true" />
            </span>
            <div>
              <p className="smallcaps">GÜNLÜK İLERLEME</p>
              <h1 className="font-display text-3xl font-bold text-ink sm:text-4xl">Eray Ne Durumda</h1>
            </div>
          </div>
          <nav className="flex flex-wrap gap-2" aria-label="Sayfa gezinme">
            <Link href="/" className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.8)] px-3.5 text-sm font-semibold text-ink-soft transition hover:border-amber-ink hover:text-amber-ink">
              <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Ana menü
            </Link>
            <Link href="/pomodoro" className="inline-flex h-10 items-center gap-2 rounded-sm bg-amber-ink px-3.5 text-sm font-semibold text-white transition hover:brightness-110">
              <Clock3 className="h-4 w-4" aria-hidden="true" /> Pomodoro
            </Link>
          </nav>
        </header>

        <div className="grid items-start gap-6 lg:grid-cols-[minmax(300px,380px)_minmax(0,1fr)]">
          <div>
            <YksBooks allowAdd={false} />
            <p className="mx-auto mt-3 max-w-[350px] text-center text-xs leading-relaxed text-ink-faint">
              Kitap kartına basarak aç; her kitapta sayfa ilerlemesi yüzdeyle görünür.
            </p>
          </div>

          <div className="space-y-5">
            <section className="plate relative overflow-hidden rounded-md p-4 sm:p-5" aria-labelledby="selected-day-title">
              <span className="screw top-2 left-2" />
              <span className="screw top-2 right-2" />
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="smallcaps">SEÇİLEN GÜN</p>
                  <h2 id="selected-day-title" className="mt-1 font-display text-2xl font-bold capitalize text-ink sm:text-3xl">
                    {formatDay(selectedDay, { weekday: "long", day: "numeric", month: "long" })}
                  </h2>
                </div>
                <label className="flex aspect-square w-28 shrink-0 flex-col items-center justify-center gap-1.5 rounded-xl border border-[rgba(90,66,34,0.24)] bg-gradient-to-br from-white/80 to-[#e9f0e5]/75 p-2 text-center text-xs font-semibold text-ink-soft shadow-sm">
                  <CalendarDays className="h-5 w-5 text-sage-ink" aria-hidden="true" />
                  <span className="text-[0.58rem] font-bold tracking-[0.1em]">GÜNÜ SEÇ</span>
                  <input
                    type="date"
                    aria-label="Çalışma gününü seç"
                    value={selectedDay}
                    onChange={event => { setSelectedDay(event.target.value); setEditing(null); }}
                    className="w-full min-w-0 bg-transparent text-center text-[0.58rem] font-semibold text-ink outline-none"
                  />
                </label>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                <div className="rounded-xl border border-white/75 bg-gradient-to-br from-[#e6f0e3] to-white/70 p-3 sm:col-span-2">
                  <p className="text-[0.65rem] font-bold tracking-[0.12em] text-[#52705a]">TOPLAM ÇALIŞMA</p>
                  <p className="mt-1 font-display text-2xl font-bold tabular-nums text-ink sm:text-3xl">{formatDuration(summary.totalSeconds)}</p>
                </div>
                <div className="rounded-xl border border-white/75 bg-white/55 p-3">
                  <p className="text-[0.64rem] font-semibold text-ink-faint">Pomodoro</p>
                  <p className="mt-1 font-display text-lg font-bold tabular-nums text-ink">{formatDuration(summary.pomodoroSeconds)}</p>
                </div>
                <div className="rounded-xl border border-white/75 bg-white/55 p-3">
                  <p className="text-[0.64rem] font-semibold text-ink-faint">Manuel</p>
                  <p className="mt-1 font-display text-lg font-bold tabular-nums text-ink">{formatDuration(summary.manualSeconds)}</p>
                </div>
              </div>
            </section>

            <section className="plate relative overflow-hidden rounded-md p-4 sm:p-5" aria-labelledby="weekly-study-title">
              <span className="screw top-2 left-2" />
              <span className="screw top-2 right-2" />
              <div className="flex flex-wrap items-end justify-between gap-2">
                <div>
                  <p className="smallcaps">GERÇEK KAYITLAR</p>
                  <h2 id="weekly-study-title" className="mt-1 font-display text-xl font-bold text-ink sm:text-2xl">Son 7 gün</h2>
                </div>
                <p className="text-xs text-ink-faint">Bir güne basıp ayrıntılarını gör.</p>
              </div>

              {days.every(day => day.totalSeconds === 0) ? (
                <div className="mt-4 rounded-xl border border-dashed border-[rgba(90,66,34,0.25)] bg-white/40 px-4 py-7 text-center">
                  <p className="font-display text-lg font-semibold text-ink">Henüz çalışma kaydı yok</p>
                  <p className="mt-1 text-sm text-ink-faint">Pomodoro’dan ders seçip başlat veya manuel süre ekle; grafik gerçek kayıtlarla oluşacak.</p>
                </div>
              ) : (
                <>
                  <p id="weekly-study-chart-description" className="sr-only">Son yedi günün seçilen derslere göre yığılmış çalışma süreleri. Bir günün grafiğine basarak o günün dökümünü aç.</p>
                  <div className="mt-5 grid grid-cols-[2.8rem_repeat(7,minmax(0,1fr))] items-end gap-1.5 sm:gap-2" aria-describedby="weekly-study-chart-description">
                  <div className="relative h-[136px] text-right text-[0.56rem] leading-none text-ink-faint">
                    <span className="absolute right-1 top-0">{formatDuration(maxChartSeconds)}</span>
                    <span className="absolute right-1 top-1/2 -translate-y-1/2">{formatDuration(maxChartSeconds / 2)}</span>
                    <span className="absolute right-1 bottom-0">0</span>
                  </div>
                  {days.map(day => (
                    <button
                      key={day.dayKey}
                      type="button"
                      aria-pressed={selectedDay === day.dayKey}
                      aria-label={`${formatDay(day.dayKey, { weekday: "long", day: "numeric", month: "long" })}: toplam ${formatDuration(day.totalSeconds)} çalışma. Derslere göre: ${day.subjects.length ? day.subjects.map(subject => `${subject.name} ${formatDuration(subject.seconds)}`).join(", ") : "kayıt yok"}.`}
                      title={`${formatDay(day.dayKey, { weekday: "long", day: "numeric", month: "long" })} · ${formatDuration(day.totalSeconds)}`}
                      onClick={() => { setSelectedDay(day.dayKey); setEditing(null); }}
                      className={`group min-w-0 rounded-lg p-1 transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sage-ink ${selectedDay === day.dayKey ? "bg-[rgba(91,122,84,0.12)] ring-1 ring-sage-ink/30" : "hover:bg-white/50"}`}
                    >
                      <span className="mb-1 block truncate text-center text-[0.57rem] font-semibold tabular-nums text-ink-soft sm:text-[0.65rem]">{day.totalSeconds ? formatDuration(day.totalSeconds) : "—"}</span>
                      <span className="relative block h-[136px] overflow-hidden rounded-md border border-[rgba(90,66,34,0.14)] bg-white/35">
                        <span className="pointer-events-none absolute inset-x-0 top-1/2 border-t border-dashed border-[rgba(90,66,34,0.16)]" />
                        <span className="pointer-events-none absolute inset-x-0 bottom-0 border-t border-[rgba(90,66,34,0.22)]" />
                          <span className="absolute inset-x-1 bottom-0 flex flex-col-reverse items-stretch">
                          {day.subjects.map(subject => (
                            <span
                              key={subject.id}
                              className="block rounded-[2px] opacity-90 transition-opacity group-hover:opacity-100"
                              title={`${subject.name}: ${formatDuration(subject.seconds)}`}
                              style={{ height: `${(subject.seconds / maxChartSeconds) * CHART_HEIGHT}px`, backgroundColor: subjectColor(subject.id) }}
                            />
                          ))}
                        </span>
                      </span>
                      <span className="mt-1.5 block truncate text-center text-[0.62rem] font-bold capitalize text-ink-soft">{day.label}</span>
                      <span className="block text-center text-[0.55rem] tabular-nums text-ink-faint">{formatDay(day.dayKey, { day: "numeric", month: "numeric" })}</span>
                    </button>
                  ))}
                  </div>
                </>
              )}

              {allChartSubjects.size > 0 && (
                <div className="mt-4 flex flex-wrap gap-x-3 gap-y-2 border-t border-[rgba(90,66,34,0.12)] pt-3">
                  {[...allChartSubjects.entries()].map(([id, name]) => (
                    <span key={id} className="inline-flex items-center gap-1.5 text-[0.68rem] text-ink-soft">
                      <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: subjectColor(id) }} />{name}
                    </span>
                  ))}
                </div>
              )}
            </section>

            <section className="plate relative overflow-hidden rounded-md p-4 sm:p-5" aria-labelledby="study-detail-title">
              <span className="screw top-2 left-2" />
              <span className="screw top-2 right-2" />
              <div className="flex flex-wrap items-end justify-between gap-2">
                <div>
                  <p className="smallcaps">DERS &amp; KONU DAĞILIMI</p>
                  <h2 id="study-detail-title" className="mt-1 font-display text-xl font-bold text-ink sm:text-2xl">Günün dökümü</h2>
                </div>
                <span className="rounded-full bg-[rgba(91,122,84,0.1)] px-3 py-1 text-xs font-semibold text-sage-ink">{summary.entries.length} kayıt</span>
              </div>

              {topics.length > 0 && (
                <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                  {topics.map(topic => (
                    <li key={`${topic.subjectId}-${topic.topicName}`} className="rounded-lg border border-white/80 bg-white/50 p-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-[0.65rem] font-bold tracking-wide text-ink-faint">{topic.subjectName}</p>
                          <p className="mt-0.5 truncate text-sm font-semibold text-ink">{topic.topicName}</p>
                        </div>
                        <p className="shrink-0 font-display text-sm font-bold tabular-nums text-sage-ink">{formatDuration(topic.seconds)}</p>
                      </div>
                      <p className="mt-1 text-[0.64rem] text-ink-faint">Pomodoro {formatDuration(topic.pomodoroSeconds)} · Manuel {formatDuration(topic.manualSeconds)}</p>
                    </li>
                  ))}
                </ul>
              )}

              {summary.entries.length === 0 ? (
                <div className="mt-4 rounded-xl border border-dashed border-[rgba(90,66,34,0.25)] bg-white/40 px-4 py-7 text-center">
                  <p className="font-display text-lg font-semibold text-ink">Bu gün için kayıt yok</p>
                  <p className="mt-1 text-sm text-ink-faint">Pomodoro’dan ders/konu seçerek odaklanabilir veya manuel çalışma süresi ekleyebilirsin.</p>
                  <Link href="/pomodoro" className="mt-3 inline-flex h-9 items-center rounded-sm bg-amber-ink px-3 text-xs font-semibold text-white transition hover:brightness-110">Pomodoro’ya git</Link>
                </div>
              ) : (
                <ul className="mt-4 space-y-2">
                  {summary.entries.map(entry => {
                    const isEditing = editing?.id === entry.id;
                    return (
                      <li key={entry.id} className="rounded-xl border border-white/80 bg-white/50 p-3 sm:p-4">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="flex min-w-0 items-start gap-3">
                            <span className="mt-1 h-3 w-3 shrink-0 rounded-full" style={{ backgroundColor: subjectColor(entry.subjectId) }} aria-hidden="true" />
                            <div className="min-w-0">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="rounded-full bg-[rgba(90,66,34,0.08)] px-2 py-0.5 text-[0.62rem] font-semibold text-ink-soft">{entry.source === "pomodoro" ? "Pomodoro" : "Manuel"}</span>
                                <span className="text-[0.66rem] tabular-nums text-ink-faint">{entry.source === "pomodoro" ? `Odak turu · ${formatTime(entry.endedAt)}` : "Manuel kayıt"}</span>
                              </div>
                              <p className="mt-1.5 break-words text-sm font-semibold text-ink">{entry.subjectName} <span className="font-normal text-ink-faint">·</span> {entry.topicName}</p>
                            </div>
                          </div>
                          <div className="flex shrink-0 items-center gap-2">
                            <span className="font-display text-lg font-bold tabular-nums text-sage-ink">{formatDuration(entry.seconds)}</span>
                            <button type="button" onClick={() => isEditing ? setEditing(null) : beginEdit(entry)} aria-label={isEditing ? "Düzenlemeyi kapat" : `${entry.subjectName} kaydını düzenle`} className="grid h-9 w-9 place-items-center rounded-lg border border-[rgba(90,66,34,0.16)] bg-white/70 text-ink-soft transition hover:text-amber-ink">
                              {isEditing ? <X className="h-4 w-4" aria-hidden="true" /> : <Pencil className="h-4 w-4" aria-hidden="true" />}
                            </button>
                            <button type="button" onClick={() => removeEntry(entry)} aria-label={`${entry.subjectName} çalışma kaydını sil`} className="grid h-9 w-9 place-items-center rounded-lg border border-[#ead8d3] bg-white/70 text-[#9b5147] transition hover:bg-[#fff1ed]">
                              <Trash2 className="h-4 w-4" aria-hidden="true" />
                            </button>
                          </div>
                        </div>

                        {isEditing && editing && (
                          <form onSubmit={saveEdit} className="mt-4 grid gap-3 rounded-lg border border-[rgba(91,122,84,0.22)] bg-[rgba(91,122,84,0.05)] p-3 sm:grid-cols-2">
                            <div>
                              <label htmlFor={`edit-study-subject-${entry.id}`} className="mb-1 block text-xs font-semibold text-ink-soft">Ders</label>
                              <select
                                id={`edit-study-subject-${entry.id}`}
                                value={editing.subjectId}
                                onChange={event => {
                                  const subject = subjects.find(item => item.id === event.target.value);
                                  setEditing(current => current ? { ...current, subjectId: event.target.value, topicId: subject?.topics[0]?.id ?? "" } : current);
                                }}
                                className="h-10 w-full rounded-sm border border-[rgba(90,66,34,0.25)] bg-white px-2 text-sm text-ink"
                              >
                                {!subjects.some(subject => subject.id === editing.subjectId) && <option value={editing.subjectId}>{entry.subjectName} · kayıtlı ders</option>}
                                <option value="">Ders seç</option>
                                {subjects.map(subject => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
                              </select>
                            </div>
                            <div>
                              <label htmlFor={`edit-study-topic-${entry.id}`} className="mb-1 block text-xs font-semibold text-ink-soft">Konu</label>
                              <select
                                id={`edit-study-topic-${entry.id}`}
                                value={editing.topicId}
                                onChange={event => setEditing(current => current ? { ...current, topicId: event.target.value } : current)}
                                className="h-10 w-full rounded-sm border border-[rgba(90,66,34,0.25)] bg-white px-2 text-sm text-ink"
                              >
                                {!editSubject?.topics.some(topic => topic.id === editing.topicId) && <option value={editing.topicId}>{entry.topicName} · kayıtlı konu</option>}
                                <option value="">Konu seç</option>
                                {editSubject?.topics.map(topic => <option key={topic.id} value={topic.id}>{topic.name}</option>)}
                              </select>
                            </div>
                            <div>
                              <label htmlFor={`edit-study-minutes-${entry.id}`} className="mb-1 block text-xs font-semibold text-ink-soft">Süre (dakika)</label>
                              <input id={`edit-study-minutes-${entry.id}`} type="number" min={1} max={1440} step={1} value={editing.minutes} onChange={event => setEditing(current => current ? { ...current, minutes: event.target.value } : current)} className="h-10 w-full rounded-sm border border-[rgba(90,66,34,0.25)] bg-white px-2 text-sm text-ink" />
                            </div>
                            <div>
                              <label htmlFor={`edit-study-day-${entry.id}`} className="mb-1 block text-xs font-semibold text-ink-soft">Çalışma günü</label>
                              <input id={`edit-study-day-${entry.id}`} type="date" value={editing.dayKey} onChange={event => setEditing(current => current ? { ...current, dayKey: event.target.value } : current)} className="h-10 w-full rounded-sm border border-[rgba(90,66,34,0.25)] bg-white px-2 text-sm text-ink" />
                            </div>
                            <button type="submit" disabled={!editSubjectName || !editTopicName || !editing.dayKey || !editing.minutes} className="inline-flex h-10 items-center justify-center gap-2 rounded-sm bg-sage-ink px-3 text-sm font-semibold text-white transition hover:brightness-110 disabled:opacity-50 sm:col-span-2">
                              <Save className="h-4 w-4" aria-hidden="true" /> Değişiklikleri kaydet
                            </button>
                          </form>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>
          </div>
        </div>
      </div>
    </main>
  );
}
