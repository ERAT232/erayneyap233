import { useEffect, useRef, useState } from "react";
import { Camera, UserRound } from "lucide-react";
import { toast } from "sonner";
import { getProfilePhotoStorageKey } from "@/lib/pomodoro/storage";
import { trpc } from "@/lib/trpc";

const MAX_INPUT_BYTES = 12 * 1024 * 1024;
const OUTPUT_SIZE = 512;

function loadPhoto(): string | null {
  try {
    return localStorage.getItem(getProfilePhotoStorageKey());
  } catch {
    return null;
  }
}

/** Resize and encode to a compact JPEG so localStorage quota stays predictable. */
function readAndCompress(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Lütfen bir resim dosyası seç."));
      return;
    }
    if (file.size > MAX_INPUT_BYTES) {
      reject(new Error("Fotoğraf 12 MB'den küçük olmalı."));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Fotoğraf okunamadı."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("Bu resim açılamadı."));
      image.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = OUTPUT_SIZE;
        canvas.height = OUTPUT_SIZE;
        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("Fotoğraf işlenemedi."));
          return;
        }
        const side = Math.min(image.naturalWidth, image.naturalHeight);
        const sx = (image.naturalWidth - side) / 2;
        const sy = (image.naturalHeight - side) / 2;
        context.drawImage(image, sx, sy, side, side, 0, 0, OUTPUT_SIZE, OUTPUT_SIZE);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export default function ProfileAvatar() {
  const inputRef = useRef<HTMLInputElement>(null);
  const lastSyncedPhoto = useRef<string | null>(null);
  const [photo, setPhoto] = useState<string | null>(loadPhoto);
  const authQuery = trpc.auth.me.useQuery();
  const isSignedIn = Boolean(authQuery.data?.id);
  const photoSyncKey = authQuery.data?.id && photo ? `${authQuery.data.id}:${photo}` : null;
  const chatIdentityQuery = trpc.chat.identity.useQuery(undefined, {
    enabled: isSignedIn,
    staleTime: 60_000,
  });
  const utils = trpc.useUtils();
  const syncChatPhoto = trpc.chat.setPhoto.useMutation({
    onSuccess: async () => {
      await utils.chat.identity.invalidate();
      await utils.chat.list.invalidate();
    },
    onError: () => {
      toast.error("CHEAT fotoğrafı eşitlenemedi", {
        description: "Profil fotoğrafın bu cihazda saklandı; sayfayı yenilediğinde CHEAT ile eşitleme yeniden denenir.",
      });
    },
  });

  useEffect(() => {
    if (!isSignedIn || !photo || !photoSyncKey || !chatIdentityQuery.isSuccess) return;
    if (chatIdentityQuery.data.profilePhoto === photo) {
      lastSyncedPhoto.current = photoSyncKey;
      return;
    }
    if (lastSyncedPhoto.current === photoSyncKey || syncChatPhoto.isPending) return;
    lastSyncedPhoto.current = photoSyncKey;
    syncChatPhoto.mutate({ photoData: photo });
  }, [isSignedIn, photo, photoSyncKey, chatIdentityQuery.data, chatIdentityQuery.isSuccess, syncChatPhoto.isPending]);

  const choosePhoto = async (file?: File) => {
    if (!file) return;
    try {
      const compressed = await readAndCompress(file);
      try {
        localStorage.setItem(getProfilePhotoStorageKey(), compressed);
      } catch {
        toast.error("Fotoğraf saklanamadı", {
          description: "Tarayıcı hafızasında yer kalmadı. Daha küçük bir resim seçmeyi dene.",
        });
        return;
      }
      setPhoto(compressed);
      toast.success("Profil fotoğrafı güncellendi");
    } catch (error) {
      toast.error("Fotoğraf eklenemedi", {
        description: error instanceof Error ? error.message : "Lütfen başka bir resim dene.",
      });
    } finally {
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="sr-only"
        aria-label="Profil fotoğrafı seç"
        onChange={event => void choosePhoto(event.target.files?.[0])}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        aria-label={photo ? "Profil fotoğrafını değiştir" : "Profil fotoğrafı yükle"}
        title={photo ? "Fotoğrafı değiştir" : "Fotoğraf yükle"}
        className="group relative grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-full border-2 border-[rgba(90,66,34,0.38)] bg-[rgba(253,248,236,0.92)] text-ink-soft shadow-[inset_0_1px_0_rgba(255,255,255,0.8),0_3px_8px_rgba(60,40,15,0.12)] transition hover:-translate-y-0.5 hover:border-amber-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-ink sm:h-[3.25rem] sm:w-[3.25rem]"
      >
        {photo ? (
          <img src={photo} alt="Profil fotoğrafı" className="h-full w-full rounded-full object-cover" />
        ) : (
          <UserRound className="h-6 w-6" strokeWidth={1.5} />
        )}
        <span className="absolute inset-0 grid place-items-center rounded-full bg-ink/55 text-white opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
          <Camera className="h-4 w-4" />
        </span>
      </button>
    </>
  );
}
