CREATE TABLE `homeTickerItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`content` varchar(280) NOT NULL,
		`createdAt` timestamp NOT NULL DEFAULT (now()),
		CONSTRAINT `homeTickerItems_id` PRIMARY KEY(`id`)
	);
--> statement-breakpoint
INSERT INTO `homeTickerItems` (`content`) VALUES
	('Her odak oturumu hedeflerine bir adım daha yaklaştırır.'),
	('Kısa bir mola ver, zihnini tazele ve yeniden başla.'),
	('YKS yolculuğunda düzen, küçük adımlarla kurulur.'),
	('Bugün ayırdığın 25 dakika bile ilerlemedir.');
