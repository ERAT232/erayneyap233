import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, KeyRound, Link2, LogOut, PanelsTopLeft, Plus } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { canonicalTweetUrl, extractTweetIdFromUrl } from "@shared/twitter";
import { useAuth } from "@/_core/hooks/useAuth";
import HomePhotoManager from "@/components/HomePhotoManager";
import HomeTickerManager from "@/components/HomeTickerManager";
import TweetEmbedList from "@/components/TweetEmbedList";
import MemberLogoutButton from "@/components/MemberLogoutButton";
import { trpc } from "@/lib/trpc";

function legacyFavoriteKey(accountId: number) {
  return `odak-paneli/v1/accounts/${encodeURIComponent(String(accountId))}/favoriteTweets`;
}

function readLegacyTweetIds(accountId: number): string[] {
  try {
    const saved = localStorage.getItem(legacyFavoriteKey(accountId));
    const parsed: unknown = saved ? JSON.parse(saved) : [];
    if (!Array.isArray(parsed)) return [];
    return [...new Set(parsed
      .map(value => value && typeof value === "object" ? (value as { tweetId?: unknown }).tweetId : null)
      .filter((tweetId): tweetId is string => typeof tweetId === "string" && /^\d{5,25}$/.test(tweetId)))].slice(0, 20);
  } catch {
    return [];
  }
}

export default function Arayuz() {
  const auth = useAuth();
  const accountId = auth.user?.id ?? null;
  const [password, setPassword] = useState("");
  const [managerToken, setManagerToken] = useState<string | null>(null);
  const [tweetUrl, setTweetUrl] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const [legacyTweetIds, setLegacyTweetIds] = useState<string[]>([]);
  const [legacyOwnerId, setLegacyOwnerId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  useEffect(() => {
    setLegacyOwnerId(null);
    setLegacyTweetIds([]);
    if (accountId === null) return;
    setLegacyTweetIds(readLegacyTweetIds(accountId));
    setLegacyOwnerId(accountId);
  }, [accountId]);

  const items = trpc.twitterCorner.list.useQuery(undefined, { enabled: Boolean(managerToken) });
  const unlock = trpc.twitterCorner.unlock.useMutation({
    onSuccess: result => {
      setManagerToken(result.token);
      setPassword("");
      setFormError(null);
    },
    onError: error => setFormError(error.message),
  });
  const add = trpc.twitterCorner.add.useMutation({
    onSuccess: () => {
      setTweetUrl("");
      setFormError(null);
      toast.success("Tweet Twitter köşesine eklendi.");
      void utils.twitterCorner.list.invalidate();
    },
    onError: error => {
      if (error.data?.code === "FORBIDDEN") setManagerToken(null);
      setFormError(error.message);
    },
  });
  const remove = trpc.twitterCorner.remove.useMutation({
    onSuccess: () => {
      toast.success("Tweet Twitter köşesinden kaldırıldı.");
      void utils.twitterCorner.list.invalidate();
    },
    onError: error => {
      if (error.data?.code === "FORBIDDEN") setManagerToken(null);
      setFormError(error.message);
    },
  });
  const importLegacy = trpc.twitterCorner.importLegacy.useMutation({
    onSuccess: result => {
      if (accountId !== null) window.localStorage.removeItem(legacyFavoriteKey(accountId));
      setLegacyTweetIds([]);
      toast.success(result.imported ? `${result.imported} eski tweet ortak Twitter köşesine aktarıldı.` : "Eski tweetler zaten ortak Twitter köşesinde.");
      void utils.twitterCorner.list.invalidate();
    },
    onError: error => {
      if (error.data?.code === "FORBIDDEN") setManagerToken(null);
      setFormError(error.message);
    },
  });

  const submitPassword = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    unlock.mutate({ password });
  };

  const addTweet = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    if (!managerToken) {
      setFormError("Yönetim erişimi süresi doldu. Parolayla yeniden giriş yap.");
      return;
    }
    if (!extractTweetIdFromUrl(tweetUrl)) {
      setFormError("HTTPS X/Twitter gönderi bağlantısı gir.");
      return;
    }
    add.mutate({ managerToken, url: tweetUrl.trim() });
  };

  const removeTweet = (id: number) => {
    if (!managerToken) {
      setManagerToken(null);
      setFormError("Yönetim erişimi süresi doldu. Parolayla yeniden giriş yap.");
      return;
    }
    remove.mutate({ managerToken, id });
  };

  return (
    <div className="desk-glow paper-grain min-h-screen">
      <main className="mx-auto min-h-screen w-full max-w-5xl px-4 pb-12 sm:px-6">
        <header className="flex items-center justify-between gap-4 py-5">
          <div className="flex items-center gap-3 text-ink">
            <PanelsTopLeft className="h-5 w-5 text-amber-ink" aria-hidden="true" />
            <h1 className="font-display text-2xl font-bold">Arayüz</h1>
          </div>
          <div className="flex flex-wrap items-center justify-end gap-2">
            <Link href="/" className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.85)] px-3 text-sm font-semibold text-ink-soft transition hover:border-amber-ink hover:text-amber-ink">
              <ArrowLeft className="h-4 w-4" /> Ana sayfa
            </Link>
            <MemberLogoutButton />
          </div>
        </header>

        <section className="max-w-2xl rounded-md border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.84)] p-5 shadow-sm" aria-labelledby="twitter-manager-title">
          <div className="mb-5 flex items-center gap-2">
            <Link2 className="h-5 w-5 text-amber-ink" aria-hidden="true" />
            <h2 id="twitter-manager-title" className="font-display text-xl font-bold text-ink">Twitter köşesi yönetimi</h2>
          </div>
          {!managerToken ? (
            <form className="space-y-3" onSubmit={submitPassword}>
              <p className="text-sm leading-6 text-ink-soft">Twitter köşesini düzenlemek için yönetim parolasını gir. İçerik ekleme yalnızca bu sayfadan yapılır.</p>
              <label className="block text-sm font-medium text-ink" htmlFor="twitter-manager-password">Arayüz parolası</label>
              <div className="flex flex-wrap gap-2">
                <input
                  id="twitter-manager-password"
                  type="password"
                  autoComplete="off"
                  value={password}
                  onChange={event => { setPassword(event.target.value); setFormError(null); }}
                  className="h-10 min-w-0 flex-1 rounded-sm border border-[rgba(90,66,34,0.28)] bg-white/80 px-3 text-sm text-ink outline-none focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/15"
                  required
                />
                <button type="submit" disabled={unlock.isPending || !password} className="inline-flex h-10 items-center gap-2 rounded-sm bg-amber-ink px-4 text-sm font-semibold text-[#fffaf0] transition hover:bg-[#914206] disabled:cursor-not-allowed disabled:opacity-55">
                  <KeyRound className="h-4 w-4" />
                  {unlock.isPending ? "Kontrol ediliyor…" : "Arayüze gir"}
                </button>
              </div>
              {formError && <p className="text-sm text-destructive" role="alert">{formError}</p>}
            </form>
          ) : (
            <div className="space-y-5">
              <form className="space-y-2" onSubmit={addTweet}>
                <label className="block text-sm font-medium text-ink" htmlFor="twitter-manager-url">X/Twitter gönderi bağlantısı</label>
                <div className="flex flex-wrap gap-2">
                  <input
                    id="twitter-manager-url"
                    type="url"
                    inputMode="url"
                    autoComplete="url"
                    placeholder="https://x.com/.../status/..."
                    value={tweetUrl}
                    onChange={event => { setTweetUrl(event.target.value); setFormError(null); }}
                    className="h-10 min-w-0 flex-1 rounded-sm border border-[rgba(90,66,34,0.28)] bg-white/80 px-3 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/15"
                  />
                  <button type="submit" disabled={add.isPending || !tweetUrl.trim()} className="inline-flex h-10 items-center gap-2 rounded-sm bg-amber-ink px-4 text-sm font-semibold text-[#fffaf0] transition hover:bg-[#914206] disabled:cursor-not-allowed disabled:opacity-55">
                    <Plus className="h-4 w-4" />
                    {add.isPending ? "Ekleniyor…" : "Twitter köşesine ekle"}
                  </button>
                </div>
                <p className="text-xs text-ink-faint">Yalnızca HTTPS X/Twitter gönderi bağlantıları kabul edilir. Video veya dosya yükleme yoktur.</p>
              </form>
              {formError && <p className="text-sm text-destructive" role="alert">{formError}</p>}
              <div className="border-t border-[rgba(90,66,34,0.18)] pt-4">
                <h3 className="mb-2 text-sm font-semibold text-ink">Ana sayfada görünen bağlantılar</h3>
                {items.isLoading ? (
                  <p className="py-4 text-sm text-ink-faint" role="status">Tweetler yükleniyor…</p>
                ) : items.isError ? (
                  <p className="py-4 text-sm text-destructive" role="alert">Tweet listesi yüklenemedi.</p>
                ) : (
                  <TweetEmbedList items={items.data ?? []} onRemove={removeTweet} emptyMessage="Henüz tweet eklenmedi." />
                )}
              </div>
              {managerToken && accountId !== null && legacyOwnerId === accountId && legacyTweetIds.length > 0 && (
                <div className="rounded-sm border border-[rgba(90,66,34,0.22)] bg-white/55 p-3">
                  <p className="text-sm text-ink-soft">Bu hesapta önceki sürümden {legacyTweetIds.length} tweet bağlantısı bulundu.</p>
                  <button
                    type="button"
                    disabled={importLegacy.isPending}
                    onClick={() => importLegacy.mutate({ managerToken, urls: legacyTweetIds.map(canonicalTweetUrl) })}
                    className="mt-2 inline-flex h-9 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.28)] px-3 text-sm font-semibold text-ink-soft transition hover:border-amber-ink hover:text-amber-ink disabled:opacity-55"
                  >
                    <Plus className="h-4 w-4" />
                    {importLegacy.isPending ? "Aktarılıyor…" : "Eski tweetleri ortak köşeye aktar"}
                  </button>
                </div>
              )}
              <button
                type="button"
                onClick={() => { setManagerToken(null); setTweetUrl(""); setFormError(null); }}
                className="inline-flex h-9 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.28)] px-3 text-sm text-ink-soft transition hover:bg-amber-ink/10"
              >
                <LogOut className="h-4 w-4" /> Yönetimden çık
              </button>
            </div>
          )}
        </section>
        {managerToken && (
          <HomeTickerManager
            managerToken={managerToken}
            onSessionExpired={() => {
              setManagerToken(null);
              setFormError("Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.");
            }}
          />
        )}
        {managerToken && (
          <HomePhotoManager
            managerToken={managerToken}
            onSessionExpired={() => {
              setManagerToken(null);
              setFormError("Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.");
            }}
          />
        )}
      </main>
    </div>
  );
}
