import {
  publicErayDailyTaskSchema,
  type PublicErayDailyTask,
} from "@shared/erayStudyData";

export const YKS_DAILY_TASK_STORAGE_PREFIX =
  "odak-paneli/yks-daily-tasks/v1/accounts/";
export const YKS_DAILY_TASK_LIMIT = 80;
export const YKS_DAILY_TASK_TITLE_LIMIT = 120;

export function getYksDailyTasksStorageKey(accountId: string | number): string {
  return `${YKS_DAILY_TASK_STORAGE_PREFIX}${encodeURIComponent(String(accountId))}`;
}

export function parseYksDailyTasks(value: unknown): PublicErayDailyTask[] {
  if (!Array.isArray(value)) return [];

  const ids = new Set<string>();
  return value.slice(0, YKS_DAILY_TASK_LIMIT).flatMap(item => {
    const parsed = publicErayDailyTaskSchema.safeParse(item);
    if (!parsed.success || ids.has(parsed.data.id)) return [];
    ids.add(parsed.data.id);
    return [parsed.data];
  });
}

export function readYksDailyTasks(key: string): PublicErayDailyTask[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    return parseYksDailyTasks(value);
  } catch {
    return [];
  }
}
