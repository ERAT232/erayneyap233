import { Target, TrendingUp } from "lucide-react";
import { useTytData } from "@/hooks/useTytData";
import { getTytNetChartSegment, TYT_SUBJECTS, type TytSubjectId } from "@shared/tyt";

function formatNet(value: number | null): string {
  return value === null ? "—" : value.toLocaleString("tr-TR", { maximumFractionDigits: 2 });
}

export default function HomeTytGoals() {
  const { data, ready, averages, updateGoal } = useTytData();

  const changeGoal = (subjectId: TytSubjectId, value: string) => {
    if (value === "") {
      updateGoal(subjectId, null);
      return;
    }
    const numericValue = Number(value);
    if (Number.isFinite(numericValue)) updateGoal(subjectId, numericValue);
  };

  return (
    <section className="w-full max-w-[23rem] overflow-hidden rounded-2xl border border-[#d6c59f] bg-gradient-to-b from-[#fffdf7] via-[#fbf7ed] to-[#f3eddf] shadow-[0_24px_55px_-35px_rgba(76,56,27,0.65)]" aria-labelledby="tyt-goals-title">
      <header className="border-b border-[#ddcfb1] bg-gradient-to-r from-[#f5e7c8] via-[#faf3e3] to-[#e7efdf] px-5 py-5">
        <p className="smallcaps flex items-center gap-1.5 text-[#6e644f]"><Target className="h-3.5 w-3.5" aria-hidden="true" /> KİŞİSEL TYT PLANI</p>
        <h2 id="tyt-goals-title" className="mt-1 font-display text-2xl font-bold text-ink">TYT Hedeflerim</h2>
        <p className="mt-1 text-xs leading-relaxed text-ink-faint">Her derste hedefini deneme ortalamanla karşılaştır.</p>
        <div className="mt-3 flex flex-wrap gap-2 text-[0.68rem] font-semibold">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-white/80 bg-white/70 px-2.5 py-1 text-[#956416]"><span className="h-2 w-2 rounded-full bg-[#d59b37]" /> Hedefin</span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-white/80 bg-white/70 px-2.5 py-1 text-[#507466]"><span className="h-2 w-2 rounded-full bg-[#6e9c8c]" /> Deneme ortalaması</span>
        </div>
      </header>

      <div className="px-4 pb-5 pt-4 sm:px-5">
        <div className="space-y-3" role="img" aria-label="Derslere göre hedef netleri ve tüm denemelerden hesaplanan ortalama TYT netleri; çubuk uzunlukları dersin soru sayısına oranlıdır">
          {TYT_SUBJECTS.map(subject => {
            const target = data.goals[subject.id];
            const average = averages[subject.id];
            const targetBar = getTytNetChartSegment(target, subject.questionCount);
            const averageBar = getTytNetChartSegment(average, subject.questionCount);
            return (
              <div key={subject.id} className="rounded-xl border border-[#e6dcc8] bg-white/70 px-3 py-2.5">
                <div className="mb-2 flex items-baseline justify-between gap-2">
                  <span className="text-sm font-bold text-ink">{subject.label}</span>
                  <span className="text-[0.64rem] text-ink-faint">−{subject.questionCount / 4} — {subject.questionCount} net</span>
                </div>
                <div className="relative h-9 overflow-hidden rounded-lg border border-[#e8e1d2] bg-[#f2eee4]" aria-label={`${subject.label} hedef ${formatNet(target)}, deneme ortalaması ${formatNet(average)}`}>
                  <div className="absolute inset-y-0 border-l border-dashed border-[#8f8268]" style={{ left: `${targetBar.zeroPercent}%` }} title="0 net" />
                  <div
                    title={`Hedef: ${formatNet(target)} net`}
                    className="absolute top-[5px] h-2.5 rounded-full bg-gradient-to-r from-[#eac36c] to-[#c38a2b] transition-[left,width] duration-500"
                    style={{ left: `${targetBar.startPercent}%`, width: `${targetBar.sizePercent}%` }}
                  />
                  <div
                    title={`Deneme ortalaması: ${formatNet(average)} net`}
                    className="absolute bottom-[5px] h-2.5 rounded-full bg-gradient-to-r from-[#a9c8b6] to-[#5e907d] transition-[left,width] duration-500"
                    style={{ left: `${averageBar.startPercent}%`, width: `${averageBar.sizePercent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 space-y-2">
          {TYT_SUBJECTS.map(subject => (
            <div key={subject.id} className="grid grid-cols-[minmax(0,1fr)_5.25rem_5.25rem] items-center gap-2 rounded-xl border border-[#e6dcc8] bg-white/65 px-3 py-2">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-ink">{subject.label}</p>
                <p className="text-[0.64rem] text-ink-faint">{subject.questionCount} soru</p>
              </div>
              <label className="min-w-0 text-center">
                <span className="block text-[0.59rem] font-semibold uppercase tracking-wide text-[#956416]">Hedef net</span>
                <input
                  type="number"
                  min={0}
                  max={subject.questionCount}
                  step={0.25}
                  value={data.goals[subject.id] ?? ""}
                  onChange={event => changeGoal(subject.id, event.target.value)}
                  disabled={!ready}
                  aria-label={`${subject.label} hedef neti`}
                  placeholder="—"
                  className="mt-0.5 h-8 w-full rounded-md border border-[#e5d5b3] bg-[#fffaf0] px-1.5 text-center text-sm font-bold tabular-nums text-ink outline-none focus:border-[#cc9130] focus:ring-2 focus:ring-[#cc9130]/15 disabled:opacity-50"
                />
              </label>
              <div className="min-w-0 text-center">
                <span className="block truncate text-[0.59rem] font-semibold uppercase tracking-wide text-[#507466]">Ort. net</span>
                <span className="mt-0.5 flex h-8 items-center justify-center gap-1 rounded-md bg-[#eaf2ed] text-sm font-bold tabular-nums text-[#466c5d]">
                  <TrendingUp className="h-3 w-3" aria-hidden="true" />{formatNet(averages[subject.id])}
                </span>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-3 text-[0.67rem] leading-relaxed text-ink-faint" role="status">
          {data.exams.length === 0
            ? "YKS Mod'a deneme eklediğinde ders ortalamaların burada görünür."
            : `Ortalama, kaydettiğin ${data.exams.length} denemenin tamamından hesaplanır.`}
        </p>
      </div>
    </section>
  );
}
