import type { StudySelection } from "@shared/studyTracking";

export type Phase = "focus" | "short" | "long";

export interface Settings {
  focusMin: number;
  shortMin: number;
  longMin: number;
  longBreakInterval: number;
  autoStartNext: boolean;
  soundEnabled: boolean;
  notifyEnabled: boolean;
  dailyGoal: number;
}

export interface Task {
  id: string;
  title: string;
  estimate: number;
  done: boolean;
  completed: number;
  createdAt: number;
}

export interface SessionRecord {
  id: string;
  phase: Phase;
  taskId: string | null;
  taskTitle: string;
  startedAt: number;
  endedAt: number;
  plannedSec: number;
  actualSec: number;
  completed: boolean;
}

export interface DayTotals {
  pomodoros: number;
  focusSeconds: number;
}

export interface TimerState {
  phase: Phase;
  running: boolean;
  /** Epoch ms the current running phase ends at. Null while paused/idle. */
  endAt: number | null;
  /** Seconds left while paused/idle, or the duration captured at start. */
  remainingSec: number;
  /** Epoch ms the current phase began, used for honest session records. */
  startedAt: number | null;
  /** Consecutive completed focus rounds since the last long break. */
  cycle: number;
  /** The YKS lesson/topic used for the current or next focus round. */
  studySelection: StudySelection | null;
}

export const DEFAULT_SETTINGS: Settings = {
  focusMin: 25,
  shortMin: 5,
  longMin: 15,
  longBreakInterval: 4,
  autoStartNext: true,
  soundEnabled: true,
  notifyEnabled: false,
  dailyGoal: 8,
};

export const DEFAULT_TIMER: TimerState = {
  phase: "focus",
  running: false,
  endAt: null,
  remainingSec: DEFAULT_SETTINGS.focusMin * 60,
  startedAt: null,
  cycle: 0,
  studySelection: null,
};

interface PhaseMeta {
  label: string;
  shortLabel: string;
  /** Ink accent used by the dial, tabs and badges. */
  accent: string;
  soft: string;
  note: string;
}

export const PHASE_META: Record<Phase, PhaseMeta> = {
  focus: {
    label: "Odak",
    shortLabel: "Odak",
    accent: "#B45309",
    soft: "rgba(180, 83, 9, 0.12)",
    note: "Şimdi yalnızca bu ders.",
  },
  short: {
    label: "Kısa Mola",
    shortLabel: "Kısa",
    accent: "#5B7A54",
    soft: "rgba(91, 122, 84, 0.14)",
    note: "Kalk, su iç, gözlerini dinlendir.",
  },
  long: {
    label: "Uzun Mola",
    shortLabel: "Uzun",
    accent: "#4C6B8A",
    soft: "rgba(76, 107, 138, 0.14)",
    note: "Set bitti. Bugünlük yeter, uzat.",
  },
};

export function phaseLabel(phase: Phase): string {
  return PHASE_META[phase].label;
}

export function durationOf(phase: Phase, settings: Settings): number {
  const minutes =
    phase === "focus" ? settings.focusMin : phase === "short" ? settings.shortMin : settings.longMin;
  return Math.max(60, Math.round(minutes * 60));
}

export const LIMITS = {
  minutes: { min: 1, max: 120 },
  interval: { min: 2, max: 8 },
  goal: { min: 1, max: 24 },
  estimate: { min: 1, max: 24 },
} as const;

export function clampInt(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}

export function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
