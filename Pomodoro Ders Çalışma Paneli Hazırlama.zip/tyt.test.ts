import { describe, expect, it } from "vitest";
import {
  calculateTytAverages,
  calculateTytExamNets,
  calculateTytExamTotal,
  getTytNetChartSegment,
  isValidTytResults,
  parseTytStudyData,
  TYT_SUBJECTS,
  type TytExam,
  type TytExamResults,
} from "../../shared/tyt";

const fullResults: TytExamResults = {
  turkce: { correct: 30, wrong: 4 },
  sosyal: { correct: 14, wrong: 4 },
  matematik: { correct: 24, wrong: 8 },
  fen: { correct: 12, wrong: 4 },
};

function exam(id: string, results: TytExamResults): TytExam {
  return { id, name: `Deneme ${id}`, createdAt: "2026-11-15T12:00:00.000Z", results };
}

describe("TYT results and averages", () => {
  it("uses the fixed Turkish, social, math, and science question counts", () => {
    expect(TYT_SUBJECTS.map(subject => [subject.id, subject.questionCount])).toEqual([
      ["turkce", 40], ["sosyal", 20], ["matematik", 40], ["fen", 20],
    ]);
  });

  it("calculates each net as correct minus one quarter of wrong, with blank answers having no effect", () => {
    expect(calculateTytExamNets(fullResults)).toEqual({ turkce: 29, sosyal: 13, matematik: 22, fen: 11 });
    expect(calculateTytExamTotal(fullResults)).toBe(75);
    expect(calculateTytExamNets({
      turkce: { correct: 10, wrong: 0 },
      sosyal: { correct: 0, wrong: 0 },
      matematik: { correct: 0, wrong: 0 },
      fen: { correct: 0, wrong: 0 },
    }).turkce).toBe(10);
  });

  it("places negative and positive net values on opposite sides of zero in charts", () => {
    expect(getTytNetChartSegment(-5, 20)).toEqual({ startPercent: 0, sizePercent: 20, zeroPercent: 20, isNegative: true });
    expect(getTytNetChartSegment(20, 40)).toEqual({ startPercent: 20, sizePercent: 40, zeroPercent: 20, isNegative: false });
    expect(getTytNetChartSegment(null, 40)).toEqual({ startPercent: 20, sizePercent: 0, zeroPercent: 20, isNegative: false });
  });

  it("rejects fractional counts, negative values, and counts above each subject's question limit", () => {
    expect(isValidTytResults(fullResults)).toBe(true);
    expect(isValidTytResults({ ...fullResults, turkce: { correct: 40, wrong: 1 } })).toBe(false);
    expect(isValidTytResults({ ...fullResults, fen: { correct: 2.5, wrong: 0 } })).toBe(false);
    expect(isValidTytResults({ ...fullResults, sosyal: { correct: -1, wrong: 0 } })).toBe(false);
  });

  it("calculates a separate average for every subject across all saved exams", () => {
    const second: TytExamResults = {
      turkce: { correct: 20, wrong: 0 },
      sosyal: { correct: 10, wrong: 0 },
      matematik: { correct: 20, wrong: 0 },
      fen: { correct: 10, wrong: 0 },
    };
    expect(calculateTytAverages([exam("1", fullResults), exam("2", second)])).toEqual({
      turkce: 24.5,
      sosyal: 11.5,
      matematik: 21,
      fen: 10.5,
    });
    expect(calculateTytAverages([])).toEqual({ turkce: null, sosyal: null, matematik: null, fen: null });
  });

  it("loads valid goals and exams while ignoring corrupted or impossible saved results", () => {
    const data = parseTytStudyData(JSON.stringify({
      goals: { turkce: 32.5, sosyal: 17, matematik: 41, fen: -1 },
      exams: [
        exam("valid", fullResults),
        { ...exam("invalid", fullResults), results: { ...fullResults, fen: { correct: 25, wrong: 0 } } },
      ],
    }));
    expect(data.goals).toEqual({ turkce: 32.5, sosyal: 17, matematik: null, fen: null });
    expect(data.exams.map(item => item.id)).toEqual(["valid"]);
    expect(parseTytStudyData("not json").exams).toEqual([]);
  });
});
