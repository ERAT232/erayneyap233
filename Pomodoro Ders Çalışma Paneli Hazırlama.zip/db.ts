import {
  and,
  asc,
  count,
  desc,
  eq,
  gt,
  inArray,
  isNotNull,
  isNull,
  like,
  lt,
  lte,
  ne,
  or,
  sql,
} from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { alias } from "drizzle-orm/mysql-core";
import { nanoid } from "nanoid";
import {
  InsertUser,
  accountSessions,
  chatConversations,
  chatMessages,
  dailyTimerPhotos,
  dailyHomeNotes,
  dailyWheelSpins,
  homeFeaturedPhoto,
  homeTickerItems,
  homeTwitterItems,
  publicErayStudyWorkspaces,
  publicProfiles,
  rateLimitBuckets,
  userNotifications,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
let rateLimitOperationCount = 0;

// Lazily create the Drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(
  user: Omit<InsertUser, "chatUserId"> & { chatUserId?: string }
): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  try {
    const values: InsertUser = {
      openId: user.openId,
      chatUserId: user.chatUserId ?? nanoid(12),
    };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0)
      updateSet.lastSignedIn = new Date();

    await db
      .insert(users)
      .values(values)
      .onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result[0] ?? undefined;
}

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);
  return result[0] ?? undefined;
}

export async function createPasswordUser(input: {
  openId: string;
  username: string;
  passwordHash: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(users).values({
    openId: input.openId,
    chatUserId: nanoid(12),
    username: input.username,
    passwordHash: input.passwordHash,
    name: input.username,
    email: null,
    loginMethod: "password",
    role: "user",
    lastSignedIn: new Date(),
  });
  return getUserByOpenId(input.openId);
}

export async function updateUserLastSignedIn(
  userId: number,
  signedInAt = new Date()
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .update(users)
    .set({ lastSignedIn: signedInAt })
    .where(eq(users.id, userId));
}

export async function createAccountSession(input: {
  userId: number;
  tokenHash: string;
  expiresAt: Date;
}): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .delete(accountSessions)
    .where(lt(accountSessions.expiresAt, new Date()));
  await db.insert(accountSessions).values(input);
}

export async function getUserByAccountSession(tokenHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select()
    .from(accountSessions)
    .innerJoin(users, eq(accountSessions.userId, users.id))
    .where(
      and(
        eq(accountSessions.tokenHash, tokenHash),
        gt(accountSessions.expiresAt, new Date())
      )
    )
    .limit(1);
  return rows[0]?.users ?? null;
}

export async function deleteAccountSession(tokenHash: string): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(accountSessions)
    .where(eq(accountSessions.tokenHash, tokenHash));
}

export async function getChatIdentity(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select({
      id: users.id,
      chatUserId: users.chatUserId,
      username: users.username,
      profilePhoto: users.chatPhotoData,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  return rows[0] ?? null;
}

export async function startDirectConversation(
  userId: number,
  targetChatUserId: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const targetRows = await db
    .select({
      id: users.id,
      chatUserId: users.chatUserId,
      username: users.username,
      profilePhoto: users.chatPhotoData,
    })
    .from(users)
    .where(
      and(
        eq(users.chatUserId, targetChatUserId),
        eq(users.loginMethod, "password")
      )
    )
    .limit(1);
  const target = targetRows[0];
  if (!target?.username || target.id === userId) return null;

  const memberOneId = Math.min(userId, target.id);
  const memberTwoId = Math.max(userId, target.id);
  await db
    .insert(chatConversations)
    .values({ memberOneId, memberTwoId })
    .onDuplicateKeyUpdate({
      set: {
        updatedAt: new Date(),
        memberOneHiddenAt: sql`IF(${chatConversations.memberOneId} = ${userId}, NULL, ${chatConversations.memberOneHiddenAt})`,
        memberTwoHiddenAt: sql`IF(${chatConversations.memberTwoId} = ${userId}, NULL, ${chatConversations.memberTwoHiddenAt})`,
      },
    });
  const conversationRows = await db
    .select({ id: chatConversations.id })
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.memberOneId, memberOneId),
        eq(chatConversations.memberTwoId, memberTwoId)
      )
    )
    .limit(1);
  if (!conversationRows[0]) throw new Error("Could not create conversation");
  return { id: conversationRows[0].id, peer: target };
}

export async function listDirectConversations(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const peerUser = alias(users, `chatPeer${userId}`);
  const conversations = await db
    .select({
      id: chatConversations.id,
      memberOneId: chatConversations.memberOneId,
      memberTwoId: chatConversations.memberTwoId,
      memberOneLastReadMessageId: chatConversations.memberOneLastReadMessageId,
      memberTwoLastReadMessageId: chatConversations.memberTwoLastReadMessageId,
      memberOneLastSeenAt: chatConversations.memberOneLastSeenAt,
      memberTwoLastSeenAt: chatConversations.memberTwoLastSeenAt,
      peerId: peerUser.id,
      peerChatUserId: peerUser.chatUserId,
      peerUsername: peerUser.username,
      peerPhoto: peerUser.chatPhotoData,
    })
    .from(chatConversations)
    .innerJoin(
      peerUser,
      sql`${peerUser.id} = IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberTwoId}, ${chatConversations.memberOneId})`
    )
    .where(
      and(
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
      )
    )
    .orderBy(desc(chatConversations.updatedAt));

  if (conversations.length === 0) return [];
  const latestMessages = await db
    .select({
      id: chatMessages.id,
      conversationId: chatMessages.conversationId,
      senderId: chatMessages.senderId,
      username: users.username,
      message: chatMessages.message,
      hasImage: isNotNull(chatMessages.imageData),
      deletedAt: chatMessages.deletedAt,
      createdAt: chatMessages.createdAt,
    })
    .from(chatMessages)
    .innerJoin(users, eq(chatMessages.senderId, users.id))
    .where(
      inArray(
        chatMessages.conversationId,
        conversations.map(row => row.id)
      )
    )
    .orderBy(desc(chatMessages.id));
  const lastByConversation = new Map<number, (typeof latestMessages)[number]>();
  for (const message of latestMessages) {
    if (!lastByConversation.has(message.conversationId))
      lastByConversation.set(message.conversationId, message);
  }

  return conversations.flatMap(row => {
    if (!row.peerUsername) return [];
    const isMemberOne = row.memberOneId === userId;
    return [
      {
        id: row.id,
        peer: {
          chatUserId: row.peerChatUserId,
          username: row.peerUsername,
          profilePhoto: row.peerPhoto,
        },
        peerLastReadMessageId: isMemberOne
          ? row.memberTwoLastReadMessageId
          : row.memberOneLastReadMessageId,
        peerLastSeenAt: isMemberOne
          ? row.memberTwoLastSeenAt
          : row.memberOneLastSeenAt,
        lastMessage: lastByConversation.get(row.id) ?? null,
      },
    ];
  });
}

export async function getDirectConversation(
  userId: number,
  conversationId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select()
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
      )
    )
    .limit(1);
  const conversation = rows[0];
  if (!conversation) return null;

  const people = await db
    .select({
      id: users.id,
      chatUserId: users.chatUserId,
      username: users.username,
      profilePhoto: users.chatPhotoData,
    })
    .from(users)
    .where(
      inArray(users.id, [conversation.memberOneId, conversation.memberTwoId])
    );
  const me = people.find(person => person.id === userId);
  const peer = people.find(person => person.id !== userId);
  if (!me?.username || !peer?.username) return null;

  const messageRows = await db
    .select({
      id: chatMessages.id,
      senderId: chatMessages.senderId,
      username: users.username,
      message: chatMessages.message,
      hasImage: isNotNull(chatMessages.imageData),
      deletedAt: chatMessages.deletedAt,
      createdAt: chatMessages.createdAt,
    })
    .from(chatMessages)
    .innerJoin(users, eq(chatMessages.senderId, users.id))
    .where(eq(chatMessages.conversationId, conversationId))
    .orderBy(desc(chatMessages.id))
    .limit(50);
  const isMemberOne = conversation.memberOneId === userId;
  return {
    id: conversation.id,
    me,
    peer: {
      ...peer,
      lastReadMessageId: isMemberOne
        ? conversation.memberTwoLastReadMessageId
        : conversation.memberOneLastReadMessageId,
      lastSeenAt: isMemberOne
        ? conversation.memberTwoLastSeenAt
        : conversation.memberOneLastSeenAt,
    },
    messages: messageRows
      .reverse()
      .flatMap(row =>
        row.username ? [{ ...row, username: row.username }] : []
      ),
  };
}

/** Image bytes are loaded on demand, separate from the 3-second message polling query. */
export async function getDirectMessageImage(
  userId: number,
  conversationId: number,
  messageId: number
): Promise<string | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select({ imageData: chatMessages.imageData })
    .from(chatMessages)
    .innerJoin(
      chatConversations,
      eq(chatConversations.id, chatMessages.conversationId)
    )
    .where(
      and(
        eq(chatMessages.id, messageId),
        eq(chatMessages.conversationId, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`,
        isNull(chatMessages.deletedAt),
        isNotNull(chatMessages.imageData)
      )
    )
    .limit(1);
  return rows[0]?.imageData ?? null;
}

/** Sender-only soft delete; clear attachment content and leave a shared tombstone. */
export async function deleteDirectMessage(
  userId: number,
  conversationId: number,
  messageId: number
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const memberConversation = db
    .select({ id: chatConversations.id })
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
      )
    );
  const result = await db
    .update(chatMessages)
    .set({
      message: "Bu mesaj silindi.",
      imageData: null,
      deletedAt: new Date(),
    })
    .where(
      and(
        eq(chatMessages.id, messageId),
        eq(chatMessages.conversationId, conversationId),
        eq(chatMessages.senderId, userId),
        isNull(chatMessages.deletedAt),
        inArray(chatMessages.conversationId, memberConversation)
      )
    );
  return (
    (result[0] as { affectedRows?: number } | undefined)?.affectedRows === 1
  );
}

export async function hideDirectConversation(
  userId: number,
  conversationId: number
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const membership = await db
    .select({ id: chatConversations.id })
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        )
      )
    )
    .limit(1);
  if (!membership[0]) return false;
  const now = new Date();
  await db
    .update(chatConversations)
    .set({
      memberOneHiddenAt: sql`IF(${chatConversations.memberOneId} = ${userId}, ${now}, ${chatConversations.memberOneHiddenAt})`,
      memberTwoHiddenAt: sql`IF(${chatConversations.memberTwoId} = ${userId}, ${now}, ${chatConversations.memberTwoHiddenAt})`,
    })
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        )
      )
    );
  await db
    .update(userNotifications)
    .set({ readAt: now })
    .where(
      and(
        eq(userNotifications.userId, userId),
        eq(userNotifications.kind, "direct_message"),
        eq(userNotifications.referenceId, conversationId),
        isNull(userNotifications.readAt)
      )
    );
  return true;
}

export async function markDirectConversationEntered(
  userId: number,
  conversationId: number,
  enteredAt = new Date()
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const membership = await db
    .select({ id: chatConversations.id })
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
      )
    )
    .limit(1);
  if (!membership[0]) return false;
  await db
    .update(chatConversations)
    .set({
      memberOneLastSeenAt: sql`IF(${chatConversations.memberOneId} = ${userId}, ${enteredAt}, ${chatConversations.memberOneLastSeenAt})`,
      memberTwoLastSeenAt: sql`IF(${chatConversations.memberTwoId} = ${userId}, ${enteredAt}, ${chatConversations.memberTwoLastSeenAt})`,
    })
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
      )
    );
  return true;
}

export async function markDirectConversationRead(
  userId: number,
  conversationId: number,
  messageId: number
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select()
    .from(chatConversations)
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
      )
    )
    .limit(1);
  const conversation = rows[0];
  if (!conversation) return false;
  const latestRows = await db
    .select({ id: chatMessages.id })
    .from(chatMessages)
    .where(eq(chatMessages.conversationId, conversationId))
    .orderBy(desc(chatMessages.id))
    .limit(1);
  if (!latestRows[0]) return true;
  const boundedReadId = Math.min(messageId, latestRows[0].id);
  await db
    .update(chatConversations)
    .set({
      memberOneLastReadMessageId: sql`IF(${chatConversations.memberOneId} = ${userId}, GREATEST(COALESCE(${chatConversations.memberOneLastReadMessageId}, 0), ${boundedReadId}), ${chatConversations.memberOneLastReadMessageId})`,
      memberTwoLastReadMessageId: sql`IF(${chatConversations.memberTwoId} = ${userId}, GREATEST(COALESCE(${chatConversations.memberTwoLastReadMessageId}, 0), ${boundedReadId}), ${chatConversations.memberTwoLastReadMessageId})`,
    })
    .where(
      and(
        eq(chatConversations.id, conversationId),
        or(
          eq(chatConversations.memberOneId, userId),
          eq(chatConversations.memberTwoId, userId)
        ),
        sql`IF(${chatConversations.memberOneId} = ${userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
      )
    );
  await db
    .update(userNotifications)
    .set({ readAt: new Date() })
    .where(
      and(
        eq(userNotifications.userId, userId),
        eq(userNotifications.kind, "direct_message"),
        eq(userNotifications.referenceId, conversationId),
        lte(userNotifications.relatedMessageId, boundedReadId),
        isNull(userNotifications.readAt)
      )
    );
  return true;
}

export async function sendDirectMessage(input: {
  userId: number;
  conversationId: number;
  message: string;
  imageData?: string;
}): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async tx => {
    const membership = await tx
      .select({
        id: chatConversations.id,
        memberOneId: chatConversations.memberOneId,
        memberTwoId: chatConversations.memberTwoId,
      })
      .from(chatConversations)
      .where(
        and(
          eq(chatConversations.id, input.conversationId),
          or(
            eq(chatConversations.memberOneId, input.userId),
            eq(chatConversations.memberTwoId, input.userId)
          ),
          sql`IF(${chatConversations.memberOneId} = ${input.userId}, ${chatConversations.memberOneHiddenAt}, ${chatConversations.memberTwoHiddenAt}) IS NULL`
        )
      )
      .for("update")
      .limit(1);
    if (!membership[0]) return false;
    const recipientId =
      membership[0].memberOneId === input.userId
        ? membership[0].memberTwoId
        : membership[0].memberOneId;
    await tx.insert(chatMessages).values({
      conversationId: input.conversationId,
      senderId: input.userId,
      message: input.message,
      imageData: input.imageData ?? null,
    });
    const insertedMessageRows = await tx
      .select({ id: chatMessages.id })
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, input.conversationId))
      .orderBy(desc(chatMessages.id))
      .limit(1);
    const relatedMessageId = insertedMessageRows[0]?.id;
    if (!relatedMessageId)
      throw new Error("The sent chat message could not be resolved.");
    await tx
      .update(chatConversations)
      .set({
        updatedAt: new Date(),
        memberOneHiddenAt: sql`IF(${chatConversations.memberOneId} = ${recipientId}, NULL, ${chatConversations.memberOneHiddenAt})`,
        memberTwoHiddenAt: sql`IF(${chatConversations.memberTwoId} = ${recipientId}, NULL, ${chatConversations.memberTwoHiddenAt})`,
      })
      .where(
        and(
          eq(chatConversations.id, input.conversationId),
          or(
            eq(chatConversations.memberOneId, input.userId),
            eq(chatConversations.memberTwoId, input.userId)
          )
        )
      );
    const senderRows = await tx
      .select({ username: users.username })
      .from(users)
      .where(eq(users.id, input.userId))
      .limit(1);
    await tx.insert(userNotifications).values({
      userId: recipientId,
      kind: "direct_message",
      actorLabel: (senderRows[0]?.username ?? "Bir üye").slice(0, 80),
      referenceId: input.conversationId,
      relatedMessageId,
    });
    return true;
  });
}

export async function updateMemberChatProfilePhoto(
  userId: number,
  photoData: string | null
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .update(users)
    .set({ chatPhotoData: photoData })
    .where(eq(users.id, userId));
}

export async function bumpRateLimitBucket(input: {
  bucketKey: string;
  windowMs: number;
  now?: Date;
}): Promise<{ count: number; resetAt: Date }> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = input.now ?? new Date();
  const resetAt = new Date(now.getTime() + input.windowMs);

  rateLimitOperationCount += 1;
  if (rateLimitOperationCount >= 1_000) {
    rateLimitOperationCount = 0;
    const expiredBefore = new Date(now.getTime() - 24 * 60 * 60 * 1_000);
    await db
      .delete(rateLimitBuckets)
      .where(lt(rateLimitBuckets.resetAt, expiredBefore));
  }

  await db
    .insert(rateLimitBuckets)
    .values({ bucketKey: input.bucketKey, hits: 1, resetAt })
    .onDuplicateKeyUpdate({
      set: {
        hits: sql`IF(${rateLimitBuckets.resetAt} <= ${now}, 1, ${rateLimitBuckets.hits} + 1)`,
        resetAt: sql`IF(${rateLimitBuckets.resetAt} <= ${now}, ${resetAt}, ${rateLimitBuckets.resetAt})`,
      },
    });
  const rows = await db
    .select({ count: rateLimitBuckets.hits, resetAt: rateLimitBuckets.resetAt })
    .from(rateLimitBuckets)
    .where(eq(rateLimitBuckets.bucketKey, input.bucketKey))
    .limit(1);
  if (!rows[0]) throw new Error("Could not read rate-limit bucket");
  return rows[0];
}

/** Increment a fine-grained per-user bucket and return the active rolling-window total. */
export async function bumpSlidingRateLimitBucket(input: {
  bucketPrefix: string;
  windowMs: number;
  bucketMs?: number;
  now?: Date;
}): Promise<{ count: number; resetAt: Date }> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = input.now ?? new Date();
  const bucketMs = Math.max(
    1,
    Math.min(1_000, Math.trunc(input.bucketMs ?? 100))
  );
  const bucketIndex = Math.floor(now.getTime() / bucketMs);
  const bucketKey = `${input.bucketPrefix}:${bucketIndex}`;
  if (bucketKey.length > 64)
    throw new Error("Sliding rate-limit bucket key is too long");
  // Retain each time slice slightly beyond the requested window so bucket rounding
  // can never make the limiter more permissive than a true rolling window.
  const resetAt = new Date((bucketIndex + 1) * bucketMs + input.windowMs);

  rateLimitOperationCount += 1;
  if (rateLimitOperationCount >= 1_000) {
    rateLimitOperationCount = 0;
    const expiredBefore = new Date(now.getTime() - 24 * 60 * 60 * 1_000);
    await db
      .delete(rateLimitBuckets)
      .where(lt(rateLimitBuckets.resetAt, expiredBefore));
  }

  const userBuckets = like(
    rateLimitBuckets.bucketKey,
    `${input.bucketPrefix}:%`
  );
  await db
    .delete(rateLimitBuckets)
    .where(and(userBuckets, lt(rateLimitBuckets.resetAt, now)));
  await db
    .insert(rateLimitBuckets)
    .values({ bucketKey, hits: 1, resetAt })
    .onDuplicateKeyUpdate({
      set: {
        hits: sql`${rateLimitBuckets.hits} + 1`,
        resetAt,
      },
    });

  const rows = await db
    .select({ count: sql<number>`COALESCE(SUM(${rateLimitBuckets.hits}), 0)` })
    .from(rateLimitBuckets)
    .where(and(userBuckets, gt(rateLimitBuckets.resetAt, now)));
  return { count: Number(rows[0]?.count ?? 0), resetAt };
}

export async function getPublicProfileByOwner(ownerOpenId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db
    .select()
    .from(publicProfiles)
    .where(eq(publicProfiles.ownerOpenId, ownerOpenId))
    .limit(1);
  return result[0] ?? null;
}

export async function getPublicProfileByShareId(shareId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db
    .select()
    .from(publicProfiles)
    .where(eq(publicProfiles.shareId, shareId))
    .limit(1);
  return result[0] ?? null;
}

export async function upsertPublicProfile(input: {
  ownerOpenId: string;
  shareId: string;
  profilePhoto: string | null;
  sessionsJson: string;
  daysJson: string;
  isPublic: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db
    .insert(publicProfiles)
    .values({ ...input, updatedAt: now })
    .onDuplicateKeyUpdate({
      set: {
        profilePhoto: input.profilePhoto,
        sessionsJson: input.sessionsJson,
        daysJson: input.daysJson,
        isPublic: input.isPublic,
        updatedAt: now,
      },
    });
  return getPublicProfileByOwner(input.ownerOpenId);
}

export async function getPublicErayStudyWorkspace() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select({
      snapshotJson: publicErayStudyWorkspaces.snapshotJson,
      updatedAt: publicErayStudyWorkspaces.updatedAt,
    })
    .from(publicErayStudyWorkspaces)
    .where(eq(publicErayStudyWorkspaces.id, 1))
    .limit(1);
  return rows[0] ?? null;
}

export async function getPublicErayStudyStatus() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select({
      phase: publicErayStudyWorkspaces.pomodoroPhase,
      running: publicErayStudyWorkspaces.pomodoroRunning,
      endAt: publicErayStudyWorkspaces.pomodoroEndAt,
      remainingSec: publicErayStudyWorkspaces.pomodoroRemainingSec,
      updatedAt: publicErayStudyWorkspaces.updatedAt,
    })
    .from(publicErayStudyWorkspaces)
    .where(eq(publicErayStudyWorkspaces.id, 1))
    .limit(1);
  return rows[0] ?? null;
}

export async function updatePublicErayStudyStatus(
  ownerUserId: number,
  status: {
    phase: "focus" | "short" | "long";
    running: boolean;
    endAt: number | null;
    remainingSec: number;
  }
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .update(publicErayStudyWorkspaces)
    .set({
      pomodoroPhase: status.phase,
      pomodoroRunning: status.running,
      pomodoroEndAt: status.endAt,
      pomodoroRemainingSec: status.remainingSec,
      updatedAt: new Date(),
    })
    .where(
      and(
        eq(publicErayStudyWorkspaces.id, 1),
        eq(publicErayStudyWorkspaces.ownerUserId, ownerUserId)
      )
    );
}

/** Upsert the one Eray-owned public snapshot; this function intentionally has no delete path. */
export async function upsertPublicErayStudyWorkspace(input: {
  ownerUserId: number;
  snapshotJson: string;
  pomodoro: {
    phase: "focus" | "short" | "long";
    running: boolean;
    endAt: number | null;
    remainingSec: number;
  };
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  const values = {
    id: 1,
    ownerUserId: input.ownerUserId,
    snapshotJson: input.snapshotJson,
    pomodoroPhase: input.pomodoro.phase,
    pomodoroRunning: input.pomodoro.running,
    pomodoroEndAt: input.pomodoro.endAt,
    pomodoroRemainingSec: input.pomodoro.remainingSec,
    updatedAt: now,
  };
  await db
    .insert(publicErayStudyWorkspaces)
    .values(values)
    .onDuplicateKeyUpdate({
      set: {
        ownerUserId: input.ownerUserId,
        snapshotJson: input.snapshotJson,
        pomodoroPhase: input.pomodoro.phase,
        pomodoroRunning: input.pomodoro.running,
        pomodoroEndAt: input.pomodoro.endAt,
        pomodoroRemainingSec: input.pomodoro.remainingSec,
        updatedAt: now,
      },
    });
  return getPublicErayStudyWorkspace();
}

export async function listHomeTwitterItems() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db
    .select({
      id: homeTwitterItems.id,
      tweetId: homeTwitterItems.tweetId,
      createdAt: homeTwitterItems.createdAt,
    })
    .from(homeTwitterItems)
    .orderBy(desc(homeTwitterItems.createdAt), desc(homeTwitterItems.id));
}

export async function addHomeTwitterItem(
  tweetId: string,
  createdBy: number,
  notifyMembers = false
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async tx => {
    await tx.insert(homeTwitterItems).values({ tweetId, createdBy });
    const rows = await tx
      .select({
        id: homeTwitterItems.id,
        tweetId: homeTwitterItems.tweetId,
        createdAt: homeTwitterItems.createdAt,
      })
      .from(homeTwitterItems)
      .where(eq(homeTwitterItems.tweetId, tweetId))
      .limit(1);
    const item = rows[0] ?? null;
    if (item && notifyMembers) {
      const [recipients, actorRows] = await Promise.all([
        tx.select({ id: users.id }).from(users).where(ne(users.id, createdBy)),
        tx
          .select({ username: users.username })
          .from(users)
          .where(eq(users.id, createdBy))
          .limit(1),
      ]);
      if (recipients.length > 0) {
        const actorLabel = (actorRows[0]?.username ?? "Bir üye").slice(0, 80);
        await tx.insert(userNotifications).values(
          recipients.map(recipient => ({
            userId: recipient.id,
            kind: "twitter_link" as const,
            actorLabel,
            referenceId: item.id,
          }))
        );
      }
    }
    return item;
  });
}

export async function deleteHomeTwitterItem(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select({ id: homeTwitterItems.id })
    .from(homeTwitterItems)
    .where(eq(homeTwitterItems.id, id))
    .limit(1);
  if (!existing[0]) return false;
  await db.delete(homeTwitterItems).where(eq(homeTwitterItems.id, id));
  return true;
}

export async function listHomeTickerItems() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db
    .select({
      id: homeTickerItems.id,
      content: homeTickerItems.content,
      createdAt: homeTickerItems.createdAt,
    })
    .from(homeTickerItems)
    .orderBy(asc(homeTickerItems.id));
}

export async function addHomeTickerItem(content: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(homeTickerItems).values({ content });
}

export async function updateHomeTickerItem(
  id: number,
  content: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select({ id: homeTickerItems.id })
    .from(homeTickerItems)
    .where(eq(homeTickerItems.id, id))
    .limit(1);
  if (!existing[0]) return false;
  await db
    .update(homeTickerItems)
    .set({ content })
    .where(eq(homeTickerItems.id, id));
  return true;
}

export async function deleteHomeTickerItem(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select({ id: homeTickerItems.id })
    .from(homeTickerItems)
    .where(eq(homeTickerItems.id, id))
    .limit(1);
  if (!existing[0]) return false;
  await db.delete(homeTickerItems).where(eq(homeTickerItems.id, id));
  return true;
}

export async function getHomeFeaturedPhoto() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select({
      id: homeFeaturedPhoto.id,
      storageKey: homeFeaturedPhoto.storageKey,
      updatedBy: homeFeaturedPhoto.updatedBy,
      updatedAt: homeFeaturedPhoto.updatedAt,
    })
    .from(homeFeaturedPhoto)
    .where(eq(homeFeaturedPhoto.id, 1))
    .limit(1);
  return rows[0] ?? null;
}

export async function setHomeFeaturedPhoto(
  storageKey: string,
  updatedBy: number
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db
    .insert(homeFeaturedPhoto)
    .values({ id: 1, storageKey, updatedBy, updatedAt: now })
    .onDuplicateKeyUpdate({
      set: { storageKey, updatedBy, updatedAt: now },
    });
}

export async function deleteHomeFeaturedPhoto(): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select({ id: homeFeaturedPhoto.id })
    .from(homeFeaturedPhoto)
    .where(eq(homeFeaturedPhoto.id, 1))
    .limit(1);
  if (!existing[0]) return false;
  await db.delete(homeFeaturedPhoto).where(eq(homeFeaturedPhoto.id, 1));
  return true;
}

export async function listDailyTimerPhotos() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db
    .select({
      dayKey: dailyTimerPhotos.dayKey,
      storageKey: dailyTimerPhotos.storageKey,
      uploadedAt: dailyTimerPhotos.updatedAt,
    })
    .from(dailyTimerPhotos)
    .orderBy(desc(dailyTimerPhotos.dayKey));
}

export async function upsertDailyTimerPhoto(input: {
  dayKey: string;
  storageKey: string;
  uploadedBy: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db
    .insert(dailyTimerPhotos)
    .values({ ...input, updatedAt: now })
    .onDuplicateKeyUpdate({
      set: {
        storageKey: input.storageKey,
        uploadedBy: input.uploadedBy,
        updatedAt: now,
      },
    });
  return { dayKey: input.dayKey, storageKey: input.storageKey, uploadedAt: now };
}

let lastDailyHomeNoteCleanupDay = "";

export async function listDailyHomeNotes(noteDay: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  if (lastDailyHomeNoteCleanupDay !== noteDay) {
    await db.delete(dailyHomeNotes).where(lt(dailyHomeNotes.noteDay, noteDay));
    lastDailyHomeNoteCleanupDay = noteDay;
  }
  return db
    .select({
      id: dailyHomeNotes.id,
      noteDay: dailyHomeNotes.noteDay,
      userId: dailyHomeNotes.userId,
      content: dailyHomeNotes.content,
      authorUsername: users.username,
      createdAt: dailyHomeNotes.createdAt,
      updatedAt: dailyHomeNotes.updatedAt,
    })
    .from(dailyHomeNotes)
    .innerJoin(users, eq(dailyHomeNotes.userId, users.id))
    .where(eq(dailyHomeNotes.noteDay, noteDay))
    .orderBy(desc(dailyHomeNotes.updatedAt), desc(dailyHomeNotes.id));
}

export async function upsertDailyHomeNote(
  noteDay: string,
  userId: number,
  content: string
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const now = new Date();
  await db
    .insert(dailyHomeNotes)
    .values({ noteDay, userId, content, createdAt: now, updatedAt: now })
    .onDuplicateKeyUpdate({
      set: { content, updatedAt: now },
    });
}

export async function deleteDailyHomeNote(
  id: number,
  userId: number,
  noteDay: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const condition = and(
    eq(dailyHomeNotes.id, id),
    eq(dailyHomeNotes.userId, userId),
    eq(dailyHomeNotes.noteDay, noteDay)
  );
  const existing = await db
    .select({ id: dailyHomeNotes.id })
    .from(dailyHomeNotes)
    .where(condition)
    .limit(1);
  if (!existing[0]) return false;
  await db.delete(dailyHomeNotes).where(condition);
  return true;
}

export async function listUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const items = await db
    .select({
      id: userNotifications.id,
      kind: userNotifications.kind,
      actorLabel: userNotifications.actorLabel,
      referenceId: userNotifications.referenceId,
      readAt: userNotifications.readAt,
      createdAt: userNotifications.createdAt,
    })
    .from(userNotifications)
    .where(eq(userNotifications.userId, userId))
    .orderBy(desc(userNotifications.createdAt), desc(userNotifications.id))
    .limit(50);
  const unreadRows = await db
    .select({ value: count() })
    .from(userNotifications)
    .where(
      and(
        eq(userNotifications.userId, userId),
        isNull(userNotifications.readAt)
      )
    );
  return {
    items: items.map(({ readAt, ...item }) => ({
      ...item,
      isRead: readAt !== null,
    })),
    unreadCount: Number(unreadRows[0]?.value ?? 0),
  };
}

export async function markUserNotificationRead(
  userId: number,
  id: number
): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const condition = and(
    eq(userNotifications.userId, userId),
    eq(userNotifications.id, id)
  );
  const existing = await db
    .select({ id: userNotifications.id })
    .from(userNotifications)
    .where(condition)
    .limit(1);
  if (!existing[0]) return false;
  await db
    .update(userNotifications)
    .set({ readAt: new Date() })
    .where(condition);
  return true;
}

export async function getDailyWheelSpin(
  userId: number,
  dayKey: string
): Promise<number | null> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db
    .select({ percentage: dailyWheelSpins.percentage })
    .from(dailyWheelSpins)
    .where(
      and(
        eq(dailyWheelSpins.userId, userId),
        eq(dailyWheelSpins.dayKey, dayKey)
      )
    )
    .limit(1);
  return rows[0]?.percentage ?? null;
}

export async function createDailyWheelSpin(
  userId: number,
  dayKey: string,
  percentage: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  try {
    await db.insert(dailyWheelSpins).values({ userId, dayKey, percentage });
    return { percentage, alreadySpun: false } as const;
  } catch (error) {
    const code =
      error && typeof error === "object" && "code" in error
        ? (error as { code?: unknown }).code
        : undefined;
    if (code !== "ER_DUP_ENTRY") throw error;
    const existing = await db
      .select({ percentage: dailyWheelSpins.percentage })
      .from(dailyWheelSpins)
      .where(
        and(
          eq(dailyWheelSpins.userId, userId),
          eq(dailyWheelSpins.dayKey, dayKey)
        )
      )
      .limit(1);
    if (!existing[0]) throw error;
    return { percentage: existing[0].percentage, alreadySpun: true } as const;
  }
}
