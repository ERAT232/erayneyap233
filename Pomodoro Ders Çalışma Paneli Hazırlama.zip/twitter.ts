const ALLOWED_TWEET_HOSTS = new Set(["x.com", "www.x.com", "twitter.com", "www.twitter.com"]);

/** Accept only direct HTTPS X/Twitter status URLs and return the numeric post ID. */
export function extractTweetIdFromUrl(value: string): string | null {
  try {
    const url = new URL(value.trim());
    if (
      url.protocol !== "https:"
      || !ALLOWED_TWEET_HOSTS.has(url.hostname.toLowerCase())
      || url.username.length > 0
      || url.password.length > 0
      || url.port.length > 0
    ) return null;
    return url.pathname.match(/^\/[^/]+\/status\/(\d{5,25})(?:\/|$)/)?.[1] ?? null;
  } catch {
    return null;
  }
}

export function canonicalTweetUrl(tweetId: string): string {
  if (!/^\d{5,25}$/.test(tweetId)) throw new Error("Invalid tweet ID");
  return `https://x.com/i/status/${tweetId}`;
}
