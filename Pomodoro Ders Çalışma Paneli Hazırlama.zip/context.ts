import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { hashSessionToken, readAccountSessionToken } from "./accountAuth";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: User | null = null;
  const requestPath = opts.req.originalUrl || opts.req.path;

  // Machine callbacks keep their separate platform authentication contract; it is not an app login.
  if (requestPath.startsWith("/api/scheduled/")) {
    try {
      user = await sdk.authenticateRequest(opts.req);
    } catch {
      user = null;
    }
  } else {
    const token = readAccountSessionToken(opts.req);
    if (token) {
      try {
        user = await db.getUserByAccountSession(hashSessionToken(token));
      } catch (error) {
        console.error("[Auth] Account session lookup failed");
        user = null;
      }
    }
  }

  return { req: opts.req, res: opts.res, user };
}
