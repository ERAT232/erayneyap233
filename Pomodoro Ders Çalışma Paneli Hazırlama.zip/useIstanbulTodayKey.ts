import { useEffect, useState } from "react";
import { getIstanbulDayKey } from "@shared/studyTracking";

export function useIstanbulTodayKey(): string {
  const [todayKey, setTodayKey] = useState(() => getIstanbulDayKey());

  useEffect(() => {
    const refresh = () => {
      const nextKey = getIstanbulDayKey();
      setTodayKey(current => (current === nextKey ? current : nextKey));
    };

    refresh();
    const interval = window.setInterval(refresh, 30_000);
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);

    return () => {
      window.clearInterval(interval);
      window.removeEventListener("focus", refresh);
      document.removeEventListener("visibilitychange", refresh);
    };
  }, []);

  return todayKey;
}
