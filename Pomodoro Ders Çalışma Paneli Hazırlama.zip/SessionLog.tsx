import { formatMinutes, formatTime } from "@/lib/pomodoro/format";
import { PHASE_META, type SessionRecord } from "@/lib/pomodoro/types";
import { cn } from "@/lib/utils";

interface SessionLogProps {
  sessions: SessionRecord[];
}

export default function SessionLog({ sessions }: SessionLogProps) {
  return (
    <section className="plate rounded-md px-5 py-4">
      <header className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-lg font-bold text-ink">Son Oturumlar</h2>
        <span className="smallcaps">{sessions.length > 0 ? `${sessions.length} kayıt` : ""}</span>
      </header>

      {sessions.length === 0 ? (
        <p className="mt-3 border-t border-dashed border-[rgba(160,138,104,0.4)] pt-3 text-sm text-ink-faint italic">
          Henüz tur yok. İlk pomodoronu bitirince buraya düşecek.
        </p>
      ) : (
        <ul className="mt-2 divide-y divide-[rgba(160,138,104,0.25)]">
          {sessions.map(s => (
            <li key={s.id} className="flex items-center gap-3 py-2 text-sm">
              <span className="w-11 shrink-0 font-display text-[0.8rem] text-ink-faint">{formatTime(s.endedAt)}</span>

              <span
                className="h-2 w-2 shrink-0 rounded-full"
                style={{ backgroundColor: s.completed ? PHASE_META.focus.accent : "rgba(160,138,104,0.5)" }}
                aria-hidden="true"
              />

              <span
                className={cn(
                  "min-w-0 flex-1 truncate",
                  s.completed ? "text-ink" : "text-ink-faint italic",
                )}
              >
                {s.taskTitle}
              </span>

              <span className="shrink-0 tabular-nums text-ink-soft">{formatMinutes(s.actualSec)}</span>

              {!s.completed && (
                <span className="shrink-0 rounded-full border border-[rgba(160,138,104,0.5)] px-1.5 text-[0.6rem] tracking-wide text-ink-faint uppercase">
                  yarıda
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
