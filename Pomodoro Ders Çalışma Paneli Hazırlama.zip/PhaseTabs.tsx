import { PHASE_META, type Phase } from "@/lib/pomodoro/types";
import { cn } from "@/lib/utils";

const ORDER: Phase[] = ["focus", "short", "long"];

interface PhaseTabsProps {
  phase: Phase;
  focusMin: number;
  shortMin: number;
  longMin: number;
  onSelect: (phase: Phase) => void;
}

export default function PhaseTabs({ phase, focusMin, shortMin, longMin, onSelect }: PhaseTabsProps) {
  const minutes: Record<Phase, number> = { focus: focusMin, short: shortMin, long: longMin };

  return (
    <div className="flex items-end justify-center gap-1.5" role="tablist" aria-label="Aşama seçimi">
      {ORDER.map(item => {
        const meta = PHASE_META[item];
        const active = item === phase;
        return (
          <button
            key={item}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onSelect(item)}
            className={cn(
              "relative rounded-t-md border border-b-0 px-3 py-1.5 text-[0.7rem] font-semibold tracking-[0.14em] uppercase transition-all sm:px-4",
              active
                ? "-mb-px translate-y-[3px] shadow-[0_-4px_10px_-8px_rgba(60,40,15,0.8)]"
                : "border-[rgba(90,66,34,0.22)] bg-[rgba(233,215,179,0.5)] text-ink-faint hover:bg-[rgba(233,215,179,0.85)] hover:text-ink-soft",
            )}
            style={
              active
                ? { borderColor: meta.accent, color: meta.accent, backgroundColor: "#FDF8EC" }
                : undefined
            }
          >
            {meta.shortLabel}
            <span className="ml-1.5 font-normal opacity-70 normal-case">{minutes[item]} dk</span>
          </button>
        );
      })}
    </div>
  );
}
