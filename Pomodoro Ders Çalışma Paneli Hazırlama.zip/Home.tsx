import { Activity, GraduationCap, MessageCircle, PanelsTopLeft, Timer } from "lucide-react";
import { Link } from "wouter";
import HomeDailyNotes from "@/components/HomeDailyNotes";
import HomeDailyWheel from "@/components/HomeDailyWheel";
import HomeNotifications from "@/components/HomeNotifications";
import HomeFeaturedPhoto from "@/components/HomeFeaturedPhoto";
import NewsTicker from "@/components/NewsTicker";
import TwitterCorner from "@/components/TwitterCorner";
import YksCountdown from "@/components/YksCountdown";
import HomeTytGoals from "@/components/HomeTytGoals";
import { usePomodoroStatus } from "@/hooks/usePomodoro";

export default function Home() {
  const { phase, running } = usePomodoroStatus();
  const isBreak = running && phase !== "focus";
  const statusLabel = !running
    ? "Eray şu an çalışmıyor"
    : phase === "focus"
      ? "Eray şu an çalışıyor"
      : "Eray şu an molada";
  const statusTone = !running
    ? "border-[rgba(90,66,34,0.2)] bg-white/50 text-ink-soft"
    : phase === "focus"
      ? "border-[rgba(91,122,84,0.32)] bg-[rgba(91,122,84,0.1)] text-sage-ink"
      : "border-[rgba(76,107,138,0.32)] bg-[rgba(76,107,138,0.1)] text-dusty-ink";
  const statusDot = !running ? "bg-ink-faint" : phase === "focus" ? "bg-sage-ink" : "bg-dusty-ink";

  return (
    <div className="desk-glow paper-grain min-h-screen">
      <main className="mx-auto min-h-screen w-full max-w-6xl px-4 sm:px-6">
        <header className="flex flex-wrap items-start justify-between gap-5 py-5">
          <div className="flex min-w-0 flex-col items-start gap-2">
            <YksCountdown />
            <div
              role="status"
              aria-live="polite"
              aria-atomic="true"
              className={`inline-flex min-h-9 items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold shadow-sm ${statusTone}`}
            >
              <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${statusDot}`} aria-hidden="true" />
              <span className={isBreak ? "motion-safe:animate-pulse" : ""}>{statusLabel}</span>
            </div>
          </div>
          <nav className="flex flex-wrap justify-end gap-2" aria-label="Ana gezinme">
            <Link
              href="/eray-bugun"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.35)] bg-[rgba(253,248,236,0.85)] px-4 text-sm font-semibold text-ink-soft transition hover:-translate-y-0.5 hover:border-amber-ink hover:text-amber-ink active:translate-y-0"
            >
              <MessageCircle className="h-4 w-4" />
              Sohbet
            </Link>
            <Link
              href="/arayuz"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.35)] bg-[rgba(253,248,236,0.85)] px-4 text-sm font-semibold text-ink-soft transition hover:-translate-y-0.5 hover:border-amber-ink hover:text-amber-ink active:translate-y-0"
            >
              <PanelsTopLeft className="h-4 w-4" />
              Arayüz
            </Link>
            <Link
              href="/pomodoro"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.35)] bg-amber-ink px-4 text-sm font-semibold text-[#fffaf0] shadow-sm transition hover:-translate-y-0.5 hover:bg-[#914206] active:translate-y-0"
            >
              <Timer className="h-4 w-4" />
              Pomodoro
            </Link>
            <Link
              href="/yks-mod"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(91,122,84,0.45)] bg-[rgba(91,122,84,0.1)] px-4 text-sm font-semibold text-sage-ink transition hover:-translate-y-0.5 hover:bg-[rgba(91,122,84,0.18)] active:translate-y-0"
            >
              <GraduationCap className="h-4 w-4" />
              YKS Mod
            </Link>
            <Link
              href="/eray-ne-durumda"
              className="inline-flex h-10 items-center gap-2 rounded-sm border border-[rgba(91,122,84,0.45)] bg-[rgba(91,122,84,0.1)] px-4 text-sm font-semibold text-sage-ink transition hover:-translate-y-0.5 hover:bg-[rgba(91,122,84,0.18)] active:translate-y-0"
            >
              <Activity className="h-4 w-4" />
              Eray Ne Durumda
            </Link>
          </nav>
          <div className="ml-auto flex w-full max-w-[22rem] flex-col items-end gap-3 sm:w-80">
            <HomeFeaturedPhoto />
            <HomeNotifications />
          </div>
        </header>
        <NewsTicker />
        <div className="mb-3 flex items-center justify-start gap-2">
          <HomeDailyNotes />
          <HomeDailyWheel />
        </div>
        <div className="grid items-start gap-5 pb-10 md:grid-cols-[minmax(18rem,23rem)_minmax(0,1fr)]">
          <HomeTytGoals />
          <section className="flex justify-start" aria-label="Twitter köşesi">
            <TwitterCorner />
          </section>
        </div>
      </main>
    </div>
  );
}
