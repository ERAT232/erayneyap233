import { useEffect, useState } from "react";
import { BookOpen, ChevronRight, Clock3, GraduationCap, Home, LockKeyhole, MessageCircle, Timer } from "lucide-react";
import HomePage from "./pages/HomePage";
import StatusPage from "./pages/StatusPage";
import YksPage from "./pages/YksPage";
import PomodoroTimer from "./components/PomodoroTimer";

type View = "home" | "pomodoro" | "yks" | "status";

const views: View[] = ["home", "pomodoro", "yks", "status"];

function readViewFromHash(): View {
  const value = window.location.hash.replace(/^#\/?/, "");
  return views.includes(value as View) ? (value as View) : "home";
}

export default function StaticDemo() {
  const [view, setView] = useState<View>(() => readViewFromHash());

  useEffect(() => {
    const syncView = () => setView(readViewFromHash());
    window.addEventListener("hashchange", syncView);
    if (!window.location.hash) window.location.hash = "#home";
    return () => window.removeEventListener("hashchange", syncView);
  }, []);

  const navigate = (next: View) => {
    window.location.hash = `#${next}`;
  };

  return (
    <div className="demo-shell">
      <header className="site-header">
        <a className="brand" href="#home" aria-label="Odak Paneli ana sayfa">
          <span className="brand-mark" aria-hidden="true">O</span>
          <span className="brand-copy">
            <strong>Odak Paneli</strong>
            <small>kişisel çalışma masası</small>
          </span>
        </a>

        <nav className="main-nav" aria-label="Demo sayfaları">
          <button className={view === "home" ? "nav-button active" : "nav-button"} onClick={() => navigate("home")}>
            <Home size={16} /> Ana Sayfa
          </button>
          <button className={view === "pomodoro" ? "nav-button active" : "nav-button"} onClick={() => navigate("pomodoro")}>
            <Timer size={16} /> Pomodoro
          </button>
          <button className={view === "yks" ? "nav-button active" : "nav-button"} onClick={() => navigate("yks")}>
            <GraduationCap size={17} /> YKS Mod
          </button>
          <button className={view === "status" ? "nav-button active" : "nav-button"} onClick={() => navigate("status")}>
            <BookOpen size={16} /> Eray Ne Durumda
          </button>
          <button className="nav-button nav-disabled" disabled title="CHEAT sohbeti için sunucu ve hesap gerekir.">
            <MessageCircle size={16} /> CHEAT <span className="disabled-tag">kapalı</span>
          </button>
        </nav>

        <div className="header-status">
          <span className="public-dot" />
          <span>Herkese açık demo</span>
        </div>
      </header>

      <main className="main-content">
        <aside className="public-notice" aria-label="Statik demo bilgisi">
          <span className="notice-icon"><LockKeyhole size={18} /></span>
          <p>
            <strong>Statik demo · herkese açık.</strong> Giriş, CHEAT sohbeti ve ortak veritabanı kayıtları bu sürümde çalışmaz.
            Görünen ders, kitap, hedef ve çalışma bilgileri örnektir. Pomodoro sayacı yalnızca bu tarayıcıda çalışır.
          </p>
          <span className="sample-badge">ÖRNEK VERİ</span>
        </aside>

        {view === "home" && <HomePage onNavigate={navigate} />}
        {view === "pomodoro" && <PomodoroTimer />}
        {view === "yks" && <YksPage />}
        {view === "status" && <StatusPage />}
      </main>

      <footer className="site-footer">
        <span><Clock3 size={14} /> Odak Paneli · GitHub Pages statik demo</span>
        <span>Hesap, sunucu veya veritabanı bağlantısı yoktur.</span>
        <button onClick={() => navigate("home")} className="footer-home">Ana sayfaya dön <ChevronRight size={14} /></button>
      </footer>
    </div>
  );
}
