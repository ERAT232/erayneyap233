import { describe, expect, it } from "vitest";
import {
  DAILY_WHEEL_HIGH_WEIGHT,
  DAILY_WHEEL_OPTIONS,
  DAILY_WHEEL_TOTAL_WEIGHT,
  DAILY_WHEEL_TWENTY_WEIGHT,
  pickDailyWheelPercentage,
} from "../../shared/dailyWheel";

describe("weighted daily wheel", () => {
  it("offers all ten percentages and gives 50%+ results most of the weight", () => {
    expect(DAILY_WHEEL_OPTIONS.map(option => option.percentage)).toEqual([10, 20, 30, 40, 50, 60, 70, 80, 90, 100]);
    expect(DAILY_WHEEL_TOTAL_WEIGHT).toBe(100);
    expect(DAILY_WHEEL_HIGH_WEIGHT).toBe(85);
    expect(DAILY_WHEEL_TWENTY_WEIGHT).toBe(2);
  });

  it("maps every secure random roll to the exact configured weight", () => {
    const distribution = new Map(DAILY_WHEEL_OPTIONS.map(option => [option.percentage, 0]));
    for (let roll = 0; roll < DAILY_WHEEL_TOTAL_WEIGHT; roll += 1) {
      const percentage = pickDailyWheelPercentage(roll);
      distribution.set(percentage, (distribution.get(percentage) ?? 0) + 1);
    }

    for (const option of DAILY_WHEEL_OPTIONS) {
      expect(distribution.get(option.percentage)).toBe(option.weight);
    }
  });

  it("rejects rolls outside the zero-based secure random range", () => {
    for (const invalidRoll of [-1, 100, 1.5, Number.NaN]) {
      expect(() => pickDailyWheelPercentage(invalidRoll)).toThrow(RangeError);
    }
  });
});
