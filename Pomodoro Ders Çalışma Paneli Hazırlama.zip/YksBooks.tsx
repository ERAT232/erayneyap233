import {
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
} from "react";
import {
  BookMarked,
  BookOpen,
  ChevronDown,
  ImagePlus,
  Plus,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { notifyErayStudyDataChanged } from "@/lib/erayStudyEvents";

type YksBook = {
  id: string;
  title: string;
  cover: string | null;
  totalPages: number;
  solvedPages: number;
};

const STORAGE_PREFIX = "odak-paneli/yks-books/v1/accounts/";
const BOOK_LIMIT = 25;
const TITLE_LIMIT = 100;
const MAX_PAGES = 100_000;
const MAX_IMAGE_BYTES = 12 * 1024 * 1024;
const COVER_MAX_WIDTH = 288;
const COVER_MAX_HEIGHT = 416;

function makeId(): string {
  return typeof crypto !== "undefined" &&
    typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function readBooks(key: string): YksBook[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (book): book is YksBook =>
          Boolean(book) &&
          typeof book.id === "string" &&
          typeof book.title === "string" &&
          typeof book.totalPages === "number" &&
          typeof book.solvedPages === "number"
      )
      .slice(0, BOOK_LIMIT)
      .map(book => {
        const totalPages = Math.max(
          1,
          Math.min(MAX_PAGES, Math.floor(book.totalPages))
        );
        return {
          id: book.id,
          title: book.title.slice(0, TITLE_LIMIT),
          cover:
            typeof book.cover === "string" &&
            book.cover.startsWith("data:image/jpeg;base64,")
              ? book.cover
              : null,
          totalPages,
          solvedPages: Math.max(
            0,
            Math.min(totalPages, Math.floor(book.solvedPages))
          ),
        };
      });
  } catch {
    return [];
  }
}

/** Keep the full cover visible while making a compact JPEG suitable for account-local storage. */
function compressCover(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Lütfen bir resim dosyası seç."));
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      reject(new Error("Kapak görseli 12 MB'den küçük olmalı."));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Kapak görseli okunamadı."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("Bu görsel açılamadı."));
      image.onload = () => {
        const scale = Math.min(
          COVER_MAX_WIDTH / image.naturalWidth,
          COVER_MAX_HEIGHT / image.naturalHeight,
          1
        );
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("Kapak görseli işlenemedi."));
          return;
        }
        context.fillStyle = "#fffdf8";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.74));
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

type YksBooksProps = { allowAdd?: boolean };

export default function YksBooks({ allowAdd = true }: YksBooksProps) {
  const auth = useAuth();
  const accountId = auth.user?.id;
  const storageKey =
    accountId === undefined
      ? null
      : `${STORAGE_PREFIX}${encodeURIComponent(String(accountId))}`;
  const coverInputRef = useRef<HTMLInputElement>(null);
  const [books, setBooks] = useState<YksBook[]>([]);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [title, setTitle] = useState("");
  const [totalPages, setTotalPages] = useState("");
  const [solvedPages, setSolvedPages] = useState("0");
  const [cover, setCover] = useState<string | null>(null);
  const [compressing, setCompressing] = useState(false);

  useEffect(() => {
    if (!storageKey) {
      setBooks([]);
      setLoadedKey(null);
      return;
    }
    setBooks(readBooks(storageKey));
    setLoadedKey(storageKey);
  }, [storageKey]);

  useEffect(() => {
    if (!storageKey || loadedKey !== storageKey) return;
    try {
      const serialized = JSON.stringify(books);
      if (localStorage.getItem(storageKey) !== serialized) {
        localStorage.setItem(storageKey, serialized);
        notifyErayStudyDataChanged();
      }
    } catch {
      toast.error("Kitaplar saklanamadı", {
        description:
          "Tarayıcı hafızasında yer kalmamış olabilir. Bazı kapak görsellerini kaldırıp tekrar dene.",
      });
    }
  }, [books, loadedKey, storageKey]);

  const onCoverChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setCompressing(true);
    try {
      const compressedCover = await compressCover(file);
      setCover(compressedCover);
    } catch (error) {
      toast.error("Kapak görseli eklenemedi", {
        description:
          error instanceof Error
            ? error.message
            : "Lütfen başka bir resim dene.",
      });
    } finally {
      setCompressing(false);
      event.target.value = "";
    }
  };

  const addBook = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleanTitle = title.trim();
    const parsedTotalPages = Number(totalPages);
    const parsedSolvedPages = Number(solvedPages);
    if (!cleanTitle) {
      toast.error("Kitap adını yaz.");
      return;
    }
    if (
      !Number.isInteger(parsedTotalPages) ||
      parsedTotalPages < 1 ||
      parsedTotalPages > MAX_PAGES
    ) {
      toast.error("Toplam sayfa sayısı 1 ile 100.000 arasında olmalı.");
      return;
    }
    if (
      !Number.isInteger(parsedSolvedPages) ||
      parsedSolvedPages < 0 ||
      parsedSolvedPages > parsedTotalPages
    ) {
      toast.error("Çözülen sayfa, 0 ile toplam sayfa arasında olmalı.");
      return;
    }
    if (!storageKey || loadedKey !== storageKey) return;
    if (books.length >= BOOK_LIMIT) {
      toast.error(`En fazla ${BOOK_LIMIT} kitap ekleyebilirsin.`);
      return;
    }

    setBooks(current => [
      ...current,
      {
        id: makeId(),
        title: cleanTitle.slice(0, TITLE_LIMIT),
        cover,
        totalPages: parsedTotalPages,
        solvedPages: parsedSolvedPages,
      },
    ]);
    setTitle("");
    setTotalPages("");
    setSolvedPages("0");
    setCover(null);
    if (coverInputRef.current) coverInputRef.current.value = "";
    toast.success("Kitap takibe eklendi");
  };

  const updateSolvedPages = (bookId: string, value: string) => {
    const numericValue = Number(value);
    if (!Number.isFinite(numericValue)) return;
    setBooks(current =>
      current.map(book =>
        book.id === bookId
          ? {
              ...book,
              solvedPages: Math.max(
                0,
                Math.min(book.totalPages, Math.floor(numericValue))
              ),
            }
          : book
      )
    );
  };

  const removeBook = (bookId: string) => {
    setBooks(current => current.filter(book => book.id !== bookId));
  };

  const pagesSolved = books.reduce(
    (total, book) => total + book.solvedPages,
    0
  );
  const totalTrackedPages = books.reduce(
    (total, book) => total + book.totalPages,
    0
  );
  const ready = Boolean(storageKey && loadedKey === storageKey);

  return (
    <section className="space-y-4" aria-labelledby="yks-books-title">
      <button
        type="button"
        aria-expanded={expanded}
        aria-controls="yks-books-content"
        onClick={() => setExpanded(value => !value)}
        className="group relative mx-auto flex aspect-square w-full max-w-[350px] flex-col items-stretch justify-between gap-4 overflow-hidden rounded-2xl border border-[#b9c9dd] bg-gradient-to-br from-[#e2edf9] via-[#f8faff] to-[#e4efe9] p-5 text-left shadow-[0_22px_48px_-28px_rgba(45,63,86,0.55)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_54px_-28px_rgba(45,63,86,0.65)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-sage-ink sm:max-w-[380px] sm:rounded-[1.75rem] sm:p-7"
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-10 -top-16 h-64 w-64 rounded-full border border-white/55 bg-white/20 shadow-[0_0_0_18px_rgba(255,255,255,0.12),0_0_0_38px_rgba(255,255,255,0.08)] transition duration-500 group-hover:scale-110"
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute bottom-[-4.5rem] right-36 h-40 w-40 rounded-full bg-[#95b5d8]/25 blur-2xl"
        />

        <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start gap-3">
          <span className="relative grid h-16 w-16 shrink-0 place-items-center rounded-2xl border border-white/75 bg-white/65 text-[#4d7096] shadow-[0_12px_26px_-16px_rgba(50,70,96,0.65)] transition duration-500 group-hover:rotate-[5deg] group-hover:scale-110 sm:h-[4.5rem] sm:w-[4.5rem]">
            <BookMarked
              className="h-8 w-8 sm:h-9 sm:w-9"
              strokeWidth={1.6}
              aria-hidden="true"
            />
            {allowAdd && (
              <span className="absolute -right-2 -top-2 grid h-8 w-8 place-items-center rounded-full border-2 border-[#f5f9fc] bg-[#bd8060] text-white shadow-md">
                <ImagePlus className="h-4 w-4" aria-hidden="true" />
              </span>
            )}
          </span>
          <span className="min-w-0">
            <span className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-[#b8c9dd]/80 bg-white/55 px-3 py-1 text-[0.65rem] font-bold tracking-[0.18em] text-[#4f6f8b]">
              OKUMA &amp; SORU BANKASI
            </span>
            <span
              id="yks-books-title"
              className="block font-display text-3xl font-bold leading-tight text-[#263747] sm:text-4xl"
            >
              Kitap Takip
            </span>
            <span className="mt-2 block text-sm leading-relaxed text-[#536a7d]">
              Kapakları, sayfa sayılarını ve çözdüğün yeri takip et.
            </span>
            <span className="mt-3 flex flex-wrap gap-2">
              <span className="rounded-full border border-white/80 bg-white/70 px-3 py-1 text-xs font-semibold text-[#465d70]">
                {books.length} kitap
              </span>
              <span className="rounded-full border border-white/80 bg-white/70 px-3 py-1 text-xs font-semibold text-[#4f6f62]">
                {pagesSolved.toLocaleString("tr-TR")} /{" "}
                {totalTrackedPages.toLocaleString("tr-TR")} sayfa
              </span>
            </span>
          </span>
        </span>

        <span className="relative z-10 flex w-full items-center justify-between border-t border-[#607d97]/15 pt-3">
          <span className="text-xs font-bold tracking-wide text-[#4f6f8b]">
            {expanded ? "KAPAT" : "KİTAPLARI AÇ"}
          </span>
          <span className="grid h-11 w-11 place-items-center rounded-full border border-white/80 bg-white/65 text-[#4f6f8b] shadow-md transition duration-300 group-hover:scale-110 group-hover:bg-white">
            <ChevronDown
              className={`h-5 w-5 transition-transform duration-500 ${expanded ? "rotate-180" : ""}`}
              aria-hidden="true"
            />
          </span>
        </span>
      </button>

      <div
        id="yks-books-content"
        aria-hidden={!expanded}
        inert={!expanded}
        className={`grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,0.8,0.3,1)] ${expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
      >
        <div className="min-h-0 overflow-hidden">
          {expanded && (
            <div className="yks-panel-open rounded-2xl border border-white/70 bg-white/35 p-2 shadow-[0_28px_60px_-38px_rgba(45,63,86,0.58)] sm:rounded-[1.75rem] sm:p-4">
              <div className="rounded-xl border border-white/80 bg-[#f7faf8]/95 p-4 sm:rounded-2xl sm:p-6">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
                  <div>
                    <p className="smallcaps">SAYFA SAYFA İLERLE</p>
                    <h2 className="mt-1 font-display text-2xl font-bold text-ink sm:text-3xl">
                      Kitaplığım
                    </h2>
                  </div>
                  <span className="rounded-full bg-[#e7eef6] px-3 py-1.5 text-xs font-semibold text-[#4d6c8a]">
                    {pagesSolved.toLocaleString("tr-TR")} /{" "}
                    {totalTrackedPages.toLocaleString("tr-TR")} sayfa tamamlandı
                  </span>
                </div>

                {allowAdd && (
                  <form
                    onSubmit={addBook}
                    className="mb-5 space-y-3 rounded-xl border border-[#cbd8e4] bg-gradient-to-br from-[#edf4fa] to-[#fbf9f2] p-3 sm:rounded-2xl sm:p-4"
                    aria-label="Kitap ekle"
                  >
                    <div>
                      <label
                        htmlFor="yks-book-title"
                        className="mb-1.5 block text-xs font-semibold text-[#4d6071]"
                      >
                        Kitap adı
                      </label>
                      <input
                        id="yks-book-title"
                        value={title}
                        onChange={event => setTitle(event.target.value)}
                        maxLength={TITLE_LIMIT}
                        placeholder="Örn. AYT Matematik Soru Bankası"
                        disabled={!ready || books.length >= BOOK_LIMIT}
                        className="h-11 w-full rounded-lg border border-[#c6d4e0] bg-white/90 px-3 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-sage-ink focus:ring-2 focus:ring-sage-ink/15 disabled:opacity-60"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label
                          htmlFor="yks-book-total-pages"
                          className="mb-1.5 block text-xs font-semibold text-[#4d6071]"
                        >
                          Toplam sayfa
                        </label>
                        <input
                          id="yks-book-total-pages"
                          type="number"
                          min={1}
                          max={MAX_PAGES}
                          step={1}
                          value={totalPages}
                          onChange={event => setTotalPages(event.target.value)}
                          placeholder="320"
                          disabled={!ready || books.length >= BOOK_LIMIT}
                          className="h-11 w-full rounded-lg border border-[#c6d4e0] bg-white/90 px-3 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-sage-ink focus:ring-2 focus:ring-sage-ink/15 disabled:opacity-60"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="yks-book-solved-pages"
                          className="mb-1.5 block text-xs font-semibold text-[#4d6071]"
                        >
                          Çözülen son sayfa
                        </label>
                        <input
                          id="yks-book-solved-pages"
                          type="number"
                          min={0}
                          max={totalPages || MAX_PAGES}
                          step={1}
                          value={solvedPages}
                          onChange={event => setSolvedPages(event.target.value)}
                          placeholder="0"
                          disabled={!ready || books.length >= BOOK_LIMIT}
                          className="h-11 w-full rounded-lg border border-[#c6d4e0] bg-white/90 px-3 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-sage-ink focus:ring-2 focus:ring-sage-ink/15 disabled:opacity-60"
                        />
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <input
                        ref={coverInputRef}
                        id="yks-book-cover"
                        type="file"
                        accept="image/*"
                        onChange={event => void onCoverChange(event)}
                        disabled={
                          !ready || books.length >= BOOK_LIMIT || compressing
                        }
                        className="sr-only"
                      />
                      <label
                        htmlFor="yks-book-cover"
                        className={`inline-flex h-10 cursor-pointer items-center gap-2 rounded-lg border border-[#bacbd9] bg-white/75 px-3 text-sm font-semibold text-[#4d6c8a] transition hover:bg-white ${!ready || books.length >= BOOK_LIMIT || compressing ? "pointer-events-none opacity-50" : ""}`}
                      >
                        {compressing ? (
                          <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#4d6c8a]/30 border-t-[#4d6c8a]" />
                        ) : (
                          <Upload className="h-4 w-4" aria-hidden="true" />
                        )}
                        {compressing
                          ? "Görsel hazırlanıyor…"
                          : cover
                            ? "Kapağı değiştir"
                            : "Kapak görseli ekle"}
                      </label>
                      {cover && (
                        <img
                          src={cover}
                          alt="Seçilen kitap kapağı önizlemesi"
                          className="h-14 w-10 rounded-md border border-white object-contain shadow-sm"
                        />
                      )}
                      <button
                        type="submit"
                        disabled={
                          !ready ||
                          !title.trim() ||
                          !totalPages ||
                          compressing ||
                          books.length >= BOOK_LIMIT
                        }
                        className="ml-auto inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#4d7096] to-[#5e8b7e] px-4 text-sm font-bold text-white shadow-[0_8px_16px_-9px_rgba(45,63,86,0.75)] transition hover:-translate-y-0.5 hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <Plus className="h-4 w-4" aria-hidden="true" /> Kitap
                        ekle
                      </button>
                    </div>
                    <p className="text-[0.7rem] leading-relaxed text-[#6a7a87]">
                      Kitap kapağı seçmek isteğe bağlıdır. Görsel, tarayıcıda
                      saklanmaya uygun küçük bir önizleme boyutuna getirilir.
                    </p>
                  </form>
                )}

                {!ready ? (
                  <p className="px-2 py-5 text-sm text-ink-faint" role="status">
                    Kitapların yükleniyor…
                  </p>
                ) : books.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-[#bdcbd8] bg-white/70 px-4 py-8 text-center">
                    <span className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-[#e7eef6] text-[#4d7096]">
                      <BookOpen className="h-6 w-6" aria-hidden="true" />
                    </span>
                    <p className="font-display text-lg font-semibold text-ink">
                      {allowAdd
                        ? "İlk kitabını ekle"
                        : "Henüz takip edilen kitap yok"}
                    </p>
                    <p className="mt-1 text-sm text-ink-faint">
                      {allowAdd
                        ? "Toplam sayfa sayısını ve çözdüğün son sayfayı belirle."
                        : "Kitap eklemek için YKS Mod’daki Kitap Takip alanını kullan."}
                    </p>
                  </div>
                ) : (
                  <ul className="grid grid-cols-1 gap-4 2xl:grid-cols-2">
                    {books.map(book => {
                      const progress = Math.round(
                        (book.solvedPages / book.totalPages) * 100
                      );
                      return (
                        <li
                          key={book.id}
                          className="group relative overflow-hidden rounded-2xl border border-[#d0dce4] bg-gradient-to-br from-[#fff] via-[#f6faf8] to-[#edf3f8] p-3 shadow-[0_18px_28px_-24px_rgba(45,63,86,0.65)] transition duration-300 hover:-translate-y-0.5 hover:shadow-[0_23px_34px_-24px_rgba(45,63,86,0.72)] sm:p-4"
                        >
                          <div className="flex gap-3 sm:gap-4">
                            <div className="grid h-28 w-[4.5rem] shrink-0 place-items-center overflow-hidden rounded-lg border border-[#d8e1e8] bg-gradient-to-b from-[#eaf1f7] to-[#f8f4e9] shadow-sm sm:h-36 sm:w-24">
                              {book.cover ? (
                                <img
                                  src={book.cover}
                                  alt={`${book.title} kitap kapağı`}
                                  loading="lazy"
                                  className="h-full w-full object-contain"
                                />
                              ) : (
                                <BookOpen
                                  className="h-8 w-8 text-[#7890a4]"
                                  aria-hidden="true"
                                />
                              )}
                            </div>
                            <div className="min-w-0 flex-1 py-1">
                              <div className="flex items-start justify-between gap-2">
                                <div className="min-w-0">
                                  <p className="text-[0.62rem] font-bold tracking-[0.15em] text-[#6b8191]">
                                    ÇALIŞMA KİTABI
                                  </p>
                                  <h3 className="mt-1 break-words font-display text-lg font-bold leading-tight text-ink">
                                    {book.title}
                                  </h3>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => removeBook(book.id)}
                                  aria-label={`${book.title} kitabını sil`}
                                  title="Kitabı sil"
                                  className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-[#e1e9ee] bg-white/75 text-[#9a5144] transition hover:bg-white hover:text-[#a33524]"
                                >
                                  <Trash2
                                    className="h-4 w-4"
                                    aria-hidden="true"
                                  />
                                </button>
                              </div>

                              <div className="mt-3 flex items-center justify-between gap-2 text-xs text-[#5d7181]">
                                <span>İlerleme</span>
                                <span className="font-bold text-[#4e7569]">
                                  {progress}%
                                </span>
                              </div>
                              <div
                                className="mt-1.5 h-2 overflow-hidden rounded-full bg-[#dfe8e8]"
                                role="progressbar"
                                aria-label={`${book.title} sayfa ilerlemesi`}
                                aria-valuemin={0}
                                aria-valuemax={book.totalPages}
                                aria-valuenow={book.solvedPages}
                              >
                                <div
                                  className="h-full rounded-full bg-gradient-to-r from-[#6e9c91] to-[#8eab72] transition-[width] duration-300"
                                  style={{ width: `${progress}%` }}
                                />
                              </div>

                              <div className="mt-2 flex items-end justify-between gap-2">
                                <div className="min-w-0">
                                  <label
                                    htmlFor={`yks-solved-${book.id}`}
                                    className="block text-[0.68rem] font-semibold text-[#5d7181]"
                                  >
                                    Çözülen son sayfa
                                  </label>
                                  <input
                                    id={`yks-solved-${book.id}`}
                                    type="number"
                                    min={0}
                                    max={book.totalPages}
                                    step={1}
                                    value={book.solvedPages}
                                    onChange={event =>
                                      updateSolvedPages(
                                        book.id,
                                        event.target.value
                                      )
                                    }
                                    className="mt-1 h-9 w-24 rounded-lg border border-[#cbd8e1] bg-white/90 px-2 text-sm font-semibold text-ink outline-none focus:border-sage-ink focus:ring-2 focus:ring-sage-ink/15"
                                  />
                                </div>
                                <p className="pb-2 text-right text-xs text-[#5d7181]">
                                  / {book.totalPages.toLocaleString("tr-TR")}{" "}
                                  sayfa
                                </p>
                              </div>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
