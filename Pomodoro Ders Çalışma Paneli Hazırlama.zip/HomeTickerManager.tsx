import { useState, type FormEvent } from "react";
import { Plus, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type HomeTickerManagerProps = {
  managerToken: string;
  onSessionExpired: () => void;
};

export default function HomeTickerManager({ managerToken, onSessionExpired }: HomeTickerManagerProps) {
  const [newText, setNewText] = useState("");
  const [drafts, setDrafts] = useState<Record<number, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const utils = trpc.useUtils();
  const items = trpc.homeTicker.list.useQuery();

  const showMutationError = (message: string, code?: string) => {
    if (code === "FORBIDDEN") onSessionExpired();
    setFormError(message);
  };

  const add = trpc.homeTicker.add.useMutation({
    onSuccess: () => {
      setNewText("");
      setFormError(null);
      toast.success("Yazı ana sayfaya eklendi.");
      void utils.homeTicker.list.invalidate();
    },
    onError: error => showMutationError(error.message, error.data?.code),
  });
  const update = trpc.homeTicker.update.useMutation({
    onSuccess: () => {
      setDrafts({});
      setFormError(null);
      toast.success("Yazı güncellendi.");
      void utils.homeTicker.list.invalidate();
    },
    onError: error => showMutationError(error.message, error.data?.code),
  });
  const remove = trpc.homeTicker.remove.useMutation({
    onSuccess: () => {
      setFormError(null);
      toast.success("Yazı kaldırıldı.");
      void utils.homeTicker.list.invalidate();
    },
    onError: error => showMutationError(error.message, error.data?.code),
  });

  const addText = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    add.mutate({ managerToken, content: newText });
  };

  const removeText = (id: number) => {
    if (!window.confirm("Bu kayan yazıyı silmek istediğine emin misin?")) return;
    setFormError(null);
    remove.mutate({ managerToken, id });
  };

  return (
    <section
      className="mt-5 max-w-2xl rounded-md border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.84)] p-5 shadow-sm"
      aria-labelledby="home-ticker-manager-title"
    >
      <h2 id="home-ticker-manager-title" className="font-display text-xl font-bold text-ink">Ana sayfada akan yazılar</h2>
      <p className="mt-2 text-sm leading-6 text-ink-soft">Burada eklediğin veya düzenlediğin metinler ana sayfadaki kayan alanda görünür.</p>

      <form className="mt-4 space-y-2" onSubmit={addText}>
        <label className="block text-sm font-medium text-ink" htmlFor="home-ticker-new-text">Yeni yazı</label>
        <div className="flex flex-wrap gap-2">
          <textarea
            id="home-ticker-new-text"
            value={newText}
            onChange={event => { setNewText(event.target.value); setFormError(null); }}
            maxLength={280}
            rows={2}
            placeholder="Ana sayfada akmasını istediğin yazıyı gir"
            className="min-h-10 min-w-0 flex-1 resize-y rounded-sm border border-[rgba(90,66,34,0.28)] bg-white/80 px-3 py-2 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/15"
          />
          <button
            type="submit"
            disabled={add.isPending || !newText.trim()}
            className="inline-flex h-10 items-center gap-2 rounded-sm bg-amber-ink px-4 text-sm font-semibold text-[#fffaf0] transition hover:bg-[#914206] disabled:cursor-not-allowed disabled:opacity-55"
          >
            <Plus className="h-4 w-4" />
            {add.isPending ? "Ekleniyor…" : "Ekle"}
          </button>
        </div>
        <p className="text-right text-xs text-ink-faint">{newText.length}/280</p>
      </form>

      {formError && <p className="mt-3 text-sm text-destructive" role="alert">{formError}</p>}

      <div className="mt-5 border-t border-[rgba(90,66,34,0.18)] pt-4">
        <h3 className="mb-3 text-sm font-semibold text-ink">Kayıtlı yazılar</h3>
        {items.isLoading ? (
          <p className="py-3 text-sm text-ink-faint" role="status">Yazılar yükleniyor…</p>
        ) : items.isError ? (
          <p className="py-3 text-sm text-destructive" role="alert">Yazılar yüklenemedi.</p>
        ) : (items.data?.length ?? 0) === 0 ? (
          <p className="py-3 text-sm text-ink-faint">Henüz kayan yazı eklenmedi.</p>
        ) : (
          <ul className="space-y-3">
            {(items.data ?? []).map(item => {
              const value = drafts[item.id] ?? item.content;
              const changed = value.trim() !== item.content;
              return (
                <li key={item.id} className="rounded-sm border border-[rgba(90,66,34,0.18)] bg-white/55 p-3">
                  <label className="sr-only" htmlFor={`home-ticker-${item.id}`}>Kayan yazı metni</label>
                  <textarea
                    id={`home-ticker-${item.id}`}
                    value={value}
                    onChange={event => setDrafts(current => ({ ...current, [item.id]: event.target.value }))}
                    maxLength={280}
                    rows={2}
                    className="min-h-10 w-full resize-y rounded-sm border border-[rgba(90,66,34,0.2)] bg-white/85 px-3 py-2 text-sm text-ink outline-none focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/15"
                  />
                  <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-ink-faint">{value.length}/280</span>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => update.mutate({ managerToken, id: item.id, content: value })}
                        disabled={!changed || !value.trim() || update.isPending}
                        className="inline-flex h-9 items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.28)] px-3 text-sm font-semibold text-ink-soft transition hover:border-amber-ink hover:text-amber-ink disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <Save className="h-4 w-4" /> Kaydet
                      </button>
                      <button
                        type="button"
                        onClick={() => removeText(item.id)}
                        disabled={remove.isPending}
                        className="inline-flex h-9 items-center gap-2 rounded-sm border border-red-900/20 px-3 text-sm font-semibold text-red-900/75 transition hover:border-red-900/50 hover:bg-red-900/5 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <Trash2 className="h-4 w-4" /> Sil
                      </button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}
