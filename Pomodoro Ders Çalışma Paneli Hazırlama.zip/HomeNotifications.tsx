import { Bell, LoaderCircle, MessageCircle, Twitter } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

function formatTime(value: Date | string) {
  return new Intl.DateTimeFormat("tr-TR", { hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

export default function HomeNotifications() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const notifications = trpc.notifications.list.useQuery(undefined, {
    refetchInterval: 15_000,
    refetchOnWindowFocus: true,
  });
  const markRead = trpc.notifications.markRead.useMutation({
    onSuccess: async () => utils.notifications.list.invalidate(),
    onError: error => toast.error("Bildirim açılamadı", { description: error.message }),
  });
  const items = notifications.data?.items ?? [];
  const unreadCount = notifications.data?.unreadCount ?? 0;

  const openNotification = async (id: number, kind: "direct_message" | "twitter_link", referenceId: number) => {
    try {
      await markRead.mutateAsync({ id });
    } catch {
      return;
    }

    if (kind === "direct_message") {
      setLocation(`/eray-bugun?conversation=${referenceId}`);
      return;
    }

    const tweet = document.getElementById(`twitter-item-${referenceId}`);
    const target = tweet ?? document.getElementById("twitter-corner");
    if (!target) return;

    const behavior = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
    target.scrollIntoView({ behavior, block: tweet ? "center" : "start" });
    if (tweet) {
      tweet.classList.remove("twitter-notification-target");
      void tweet.offsetWidth;
      tweet.classList.add("twitter-notification-target");
      window.setTimeout(() => tweet.classList.remove("twitter-notification-target"), 2_600);
    }
  };

  return (
    <section className="w-full overflow-hidden rounded-md border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.88)] shadow-sm" aria-labelledby="home-notifications-title">
      <header className="flex items-center justify-between gap-2 border-b border-[rgba(90,66,34,0.18)] bg-[rgba(233,215,179,0.28)] px-3 py-2.5">
        <div className="flex min-w-0 items-center gap-2">
          <Bell className="h-4 w-4 shrink-0 text-amber-ink" aria-hidden="true" />
          <h2 id="home-notifications-title" className="font-display text-sm font-bold text-ink">Bildirimler</h2>
        </div>
        {unreadCount > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#ad4c32] px-1.5 text-[10px] font-bold tabular-nums text-white" aria-label={`${unreadCount} okunmamış bildirim`}>{unreadCount > 99 ? "99+" : unreadCount}</span>}
      </header>

      {notifications.isLoading ? (
        <p className="flex items-center justify-center gap-2 px-3 py-4 text-xs text-ink-faint" role="status"><LoaderCircle className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> Bildirimler yükleniyor…</p>
      ) : notifications.isError ? (
        <p className="px-3 py-4 text-xs text-destructive" role="alert">Bildirimler şu anda yüklenemedi.</p>
      ) : items.length === 0 ? (
        <p className="px-3 py-4 text-xs text-ink-faint">Yeni bir bildirim yok.</p>
      ) : (
        <ul className="max-h-64 divide-y divide-[rgba(90,66,34,0.12)] overflow-y-auto" aria-label="Son bildirimler">
          {items.map(item => {
            const isMessage = item.kind === "direct_message";
            const Icon = isMessage ? MessageCircle : Twitter;
            const description = isMessage
              ? `${item.actorLabel} sana yeni bir mesaj gönderdi.`
              : "Twitter köşesine yeni bir bağlantı eklendi.";
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => void openNotification(item.id, item.kind, item.referenceId)}
                  disabled={markRead.isPending}
                  className={`flex w-full items-start gap-2.5 px-3 py-2.5 text-left transition hover:bg-white/75 focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-amber-ink disabled:cursor-wait ${item.isRead ? "bg-transparent" : "bg-white/55"}`}
                  aria-label={`${item.isRead ? "Okunmuş" : "Okunmamış"} bildirim: ${description}`}
                >
                  <span className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full ${isMessage ? "bg-[#f1d8c1] text-[#855333]" : "bg-[#dce8ef] text-[#486779]"}`}>
                    <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block break-words text-xs leading-4 text-ink">{description}</span>
                    <time className="mt-1 block text-[10px] text-ink-faint" dateTime={new Date(item.createdAt).toISOString()}>{formatTime(item.createdAt)}</time>
                  </span>
                  {!item.isRead && <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-[#ad4c32]" aria-hidden="true" />}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
