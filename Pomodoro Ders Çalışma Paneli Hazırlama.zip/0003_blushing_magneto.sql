CREATE TABLE `memberChatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`message` varchar(500) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `memberChatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `memberChatMessages` ADD CONSTRAINT `memberChatMessages_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;