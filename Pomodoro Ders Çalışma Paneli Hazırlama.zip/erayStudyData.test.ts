import { describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";
import type { User } from "../drizzle/schema";
import type { PublicErayStudySnapshot } from "@shared/erayStudyData";
import type { TrpcContext } from "./_core/context";

const dbMocks = vi.hoisted(() => ({
  getPublicErayStudyWorkspace: vi.fn(),
  getPublicErayStudyStatus: vi.fn(),
  upsertPublicErayStudyWorkspace: vi.fn(),
  updatePublicErayStudyStatus: vi.fn(),
  getPublicProfileByOwner: vi.fn(),
  upsertPublicProfile: vi.fn(),
}));

vi.mock("./db", () => dbMocks);

import * as db from "./db";
import { appRouter } from "./routers";
import { publicErayStudySnapshotSchema } from "@shared/erayStudyData";

function makeUser(username: string): User {
  const now = new Date();
  return {
    id: username === "eray" ? 41 : 42,
    openId: `test-${username}`,
    chatUserId: `chat-${username}`,
    username,
    passwordHash: "test-hash",
    name: username,
    email: null,
    loginMethod: "password",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
    chatPhotoData: null,
    lastChatSeenAt: null,
    chatLastReadMessageId: null,
  };
}

function makeContext(user: User | null = null): TrpcContext {
  const req = {
    protocol: "https",
    method: "POST",
    originalUrl: "/api/trpc/erayStudyData.sync",
    ip: "198.51.100.72",
    socket: { remoteAddress: "198.51.100.72" },
    headers: {},
  } as unknown as TrpcContext["req"];
  const res = {
    cookie: vi.fn(),
    clearCookie: vi.fn(),
  } as unknown as TrpcContext["res"];
  return { req, res, user };
}

const snapshot: PublicErayStudySnapshot = {
  version: 1,
  pomodoro: {
    settings: {
      focusMin: 25,
      shortMin: 5,
      longMin: 15,
      longBreakInterval: 4,
      autoStartNext: false,
      soundEnabled: true,
      notifyEnabled: true,
      dailyGoal: 8,
    },
    tasks: [],
    activeTaskId: null,
    timer: {
      phase: "focus",
      running: false,
      endAt: null,
      remainingSec: 1_500,
      startedAt: null,
      cycle: 0,
      studySelection: null,
    },
    sessions: [],
    history: {},
    studyEntries: [],
  },
  subjects: [],
  books: [],
  programs: [],
  dailyTasks: [],
  tyt: {
    version: 1,
    goals: { turkce: null, sosyal: null, matematik: null, fen: null },
    exams: [],
  },
};

describe("public Eray study workspace access", () => {
  it("rejects a member's attempt to publish study data at the server boundary", async () => {
    vi.mocked(db.upsertPublicErayStudyWorkspace).mockClear();
    const caller = appRouter.createCaller(makeContext(makeUser("ilayda")));
    const error = await caller.erayStudyData
      .sync({ snapshot })
      .catch(value => value);

    expect(error).toBeInstanceOf(TRPCError);
    expect((error as TRPCError).code).toBe("FORBIDDEN");
    expect(db.upsertPublicErayStudyWorkspace).not.toHaveBeenCalled();
  });

  it("allows only the authenticated canonical eray account to publish, using the session user id", async () => {
    const updatedAt = new Date("2026-11-16T12:00:00.000Z");
    vi.mocked(db.upsertPublicErayStudyWorkspace).mockResolvedValue({
      snapshotJson: JSON.stringify(snapshot),
      updatedAt,
    } as Awaited<ReturnType<typeof db.upsertPublicErayStudyWorkspace>>);

    const result = await appRouter
      .createCaller(makeContext(makeUser("eray")))
      .erayStudyData.sync({ snapshot });

    expect(result.updatedAt).toEqual(updatedAt);
    expect(db.upsertPublicErayStudyWorkspace).toHaveBeenCalledWith({
      ownerUserId: 41,
      snapshotJson: JSON.stringify(snapshot),
      pomodoro: snapshot.pomodoro.timer,
    });
  });

  it("allows Eray to update only the compact live timer status and rejects members", async () => {
    vi.mocked(db.updatePublicErayStudyStatus).mockResolvedValue(undefined);
    const status = {
      phase: "focus" as const,
      running: true,
      endAt: 1_800_000_000_000,
      remainingSec: 1_200,
    };
    const erayResult = await appRouter
      .createCaller(makeContext(makeUser("eray")))
      .erayStudyData.statusSync(status);

    expect(erayResult).toEqual({ success: true });
    expect(db.updatePublicErayStudyStatus).toHaveBeenCalledWith(41, status);

    vi.mocked(db.updatePublicErayStudyStatus).mockClear();
    const error = await appRouter
      .createCaller(makeContext(makeUser("member")))
      .erayStudyData.statusSync(status)
      .catch(value => value);

    expect(error).toBeInstanceOf(TRPCError);
    expect((error as TRPCError).code).toBe("FORBIDDEN");
    expect(db.updatePublicErayStudyStatus).not.toHaveBeenCalled();
  });

  it("serves the sanitized study snapshot publicly but does not expose owner identity or private account fields", async () => {
    const updatedAt = new Date("2026-11-16T12:00:00.000Z");
    vi.mocked(db.getPublicErayStudyWorkspace).mockResolvedValue({
      snapshotJson: JSON.stringify(snapshot),
      updatedAt,
    } as Awaited<ReturnType<typeof db.getPublicErayStudyWorkspace>>);

    const result = await appRouter
      .createCaller(makeContext())
      .erayStudyData.view();

    expect(result).toEqual({ snapshot, updatedAt });
    expect(result).not.toHaveProperty("ownerUserId");
    expect(result).not.toHaveProperty("passwordHash");
  });

  it("rejects private chat/account fields from the public snapshot schema", () => {
    const invalid = {
      ...snapshot,
      chatMessages: [{ message: "private" }],
      passwordHash: "secret",
    };
    expect(publicErayStudySnapshotSchema.safeParse(invalid).success).toBe(
      false
    );
  });

  it("accepts legacy snapshots without daily tasks and validates public daily tasks", () => {
    const { dailyTasks: _dailyTasks, ...legacySnapshot } = snapshot;
    expect(
      publicErayStudySnapshotSchema.parse(legacySnapshot).dailyTasks
    ).toBeUndefined();

    const task = {
      id: "math-review",
      title: "Matematik tekrar",
      completedOn: "2026-11-17",
    };
    expect(
      publicErayStudySnapshotSchema.parse({ ...snapshot, dailyTasks: [task] })
        .dailyTasks
    ).toEqual([task]);
    expect(
      publicErayStudySnapshotSchema.safeParse({
        ...snapshot,
        dailyTasks: [{ ...task, completedOn: "yarın" }],
      }).success
    ).toBe(false);
  });

  it("keeps saved tasks when an older open client syncs without the new field", async () => {
    const existingTasks = [
      { id: "daily-math", title: "Matematik tekrar", completedOn: null },
    ];
    const existingSnapshot = { ...snapshot, dailyTasks: existingTasks };
    const { dailyTasks: _dailyTasks, ...legacySnapshot } = snapshot;
    const updatedAt = new Date("2026-11-17T12:00:00.000Z");
    vi.mocked(db.getPublicErayStudyWorkspace).mockResolvedValue({
      snapshotJson: JSON.stringify(existingSnapshot),
      updatedAt,
    } as Awaited<ReturnType<typeof db.getPublicErayStudyWorkspace>>);
    vi.mocked(db.upsertPublicErayStudyWorkspace).mockResolvedValue({
      snapshotJson: JSON.stringify({
        ...legacySnapshot,
        dailyTasks: existingTasks,
      }),
      updatedAt,
    } as Awaited<ReturnType<typeof db.upsertPublicErayStudyWorkspace>>);

    await appRouter
      .createCaller(makeContext(makeUser("eray")))
      .erayStudyData.sync({ snapshot: legacySnapshot });

    expect(db.upsertPublicErayStudyWorkspace).toHaveBeenCalledWith({
      ownerUserId: 41,
      snapshotJson: JSON.stringify({
        ...legacySnapshot,
        dailyTasks: existingTasks,
      }),
      pomodoro: legacySnapshot.pomodoro.timer,
    });
  });

  it("returns an empty checklist for an older public snapshot", async () => {
    const { dailyTasks: _dailyTasks, ...legacySnapshot } = snapshot;
    const updatedAt = new Date("2026-11-17T12:00:00.000Z");
    vi.mocked(db.getPublicErayStudyWorkspace).mockResolvedValue({
      snapshotJson: JSON.stringify(legacySnapshot),
      updatedAt,
    } as Awaited<ReturnType<typeof db.getPublicErayStudyWorkspace>>);

    const result = await appRouter
      .createCaller(makeContext())
      .erayStudyData.view();

    expect(result?.snapshot.dailyTasks).toEqual([]);
  });

  it("denies a member even when they call the existing profile publication mutation", async () => {
    const caller = appRouter.createCaller(makeContext(makeUser("member")));
    const error = await caller.profile
      .save({
        profilePhoto: null,
        sessions: [],
        days: [],
        isPublic: true,
      })
      .catch(value => value);

    expect(error).toBeInstanceOf(TRPCError);
    expect((error as TRPCError).code).toBe("FORBIDDEN");
    expect(db.upsertPublicProfile).not.toHaveBeenCalled();
  });
});
