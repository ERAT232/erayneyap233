import { describe, expect, it } from "vitest";
import {
  countCompletedDailyTasks,
  normalizeDailyTasksForDay,
  resolveDailyTasksForSnapshot,
} from "../shared/dailyTasks";
import type { PublicErayDailyTask } from "../shared/erayStudyData";

const tasks: PublicErayDailyTask[] = [
  { id: "math", title: "Matematik çalış", completedOn: "2026-11-17" },
  { id: "reading", title: "Paragraf çöz", completedOn: "2026-11-16" },
  { id: "review", title: "Tekrar yap", completedOn: null },
];

describe("daily Eray checklist", () => {
  it("counts only tasks completed on the selected Istanbul day", () => {
    expect(countCompletedDailyTasks(tasks, "2026-11-17")).toBe(1);
  });

  it("clears an old day's checks but keeps all task definitions", () => {
    const today = normalizeDailyTasksForDay(tasks, "2026-11-17");
    expect(today).toEqual([
      { id: "math", title: "Matematik çalış", completedOn: "2026-11-17" },
      { id: "reading", title: "Paragraf çöz", completedOn: null },
      { id: "review", title: "Tekrar yap", completedOn: null },
    ]);
    expect(today.map(task => task.id)).toEqual(tasks.map(task => task.id));
    expect(normalizeDailyTasksForDay(today, "2026-11-17")).toBe(today);
  });

  it("preserves stored tasks when a legacy client omits the field", () => {
    expect(resolveDailyTasksForSnapshot(undefined, tasks)).toEqual(tasks);
    expect(resolveDailyTasksForSnapshot(undefined, undefined)).toEqual([]);
  });

  it("honors an explicit empty list from the current Eray client", () => {
    expect(resolveDailyTasksForSnapshot([], tasks)).toEqual([]);
  });
});
