import { useEffect, useState } from "react";
import { Camera, X } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function HomeFeaturedPhoto() {
  const photo = trpc.homePhoto.current.useQuery(undefined, { refetchInterval: 15_000 });
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    if (!isExpanded) return;
    const previousOverflow = document.body.style.overflow;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIsExpanded(false);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [isExpanded]);

  return (
    <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-md border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.72)] shadow-sm sm:h-16 sm:w-16" aria-label="Ana sayfa fotoğraf alanı">
      {photo.isLoading ? (
        <span className="sr-only" role="status">Fotoğraf yükleniyor…</span>
      ) : photo.isError ? (
        <span className="px-1 text-center text-[10px] leading-tight text-ink-faint" role="alert">Fotoğraf yüklenemedi</span>
      ) : photo.data?.url ? (
        <>
          <button
            type="button"
            onClick={() => setIsExpanded(true)}
            aria-label="Ana sayfa fotoğrafını büyüt"
            aria-haspopup="dialog"
            className="group relative block h-full w-full overflow-hidden rounded-[inherit] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-ink"
          >
          <img
            src={photo.data.url}
            alt="Ana sayfada paylaşılan fotoğraf"
            className="block h-full w-full object-cover transition-transform duration-300 ease-out group-hover:scale-105"
            loading="lazy"
            decoding="async"
          />
            <span className="sr-only">Büyütmek için tıkla</span>
          </button>
          {isExpanded && (
            <div
              className="photo-lightbox-backdrop fixed inset-0 z-[100] flex items-center justify-center bg-[rgba(22,16,10,0.88)] p-4 backdrop-blur-sm sm:p-8"
              role="dialog"
              aria-modal="true"
              aria-label="Büyütülmüş ana sayfa fotoğrafı"
              onClick={event => {
                if (event.target === event.currentTarget) setIsExpanded(false);
              }}
            >
              <button
                type="button"
                autoFocus
                onClick={() => setIsExpanded(false)}
                aria-label="Fotoğrafı kapat"
                className="absolute right-4 top-4 grid h-11 w-11 place-items-center rounded-full border border-white/30 bg-black/35 text-white transition hover:bg-black/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <X className="h-6 w-6" aria-hidden="true" />
              </button>
              <img
                src={photo.data.url}
                alt="Büyütülmüş ana sayfa fotoğrafı"
                className="photo-lightbox-image max-h-[86vh] max-w-[92vw] rounded-md object-contain shadow-[0_24px_80px_rgba(0,0,0,0.45)]"
                decoding="async"
              />
            </div>
          )}
        </>
      ) : (
        <div className="flex flex-col items-center gap-1 px-1 text-center text-ink-faint">
          <Camera className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
          <span className="text-[9px] leading-tight">Fotoğraf yok</span>
        </div>
      )}
    </div>
  );
}
