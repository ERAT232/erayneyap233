import { randomBytes, timingSafeEqual } from "node:crypto";
import type { Request } from "express";
import { parse as parseCookieHeader } from "cookie";
import { CSRF_COOKIE_NAME, CSRF_HEADER_NAME } from "@shared/const";

export function createCsrfToken(): string {
  return randomBytes(32).toString("base64url");
}

export function validCsrfRequest(req: Request): boolean {
  const rawCookieToken = parseCookieHeader(req.headers.cookie ?? "")[CSRF_COOKIE_NAME];
  const cookieToken = typeof rawCookieToken === "string" ? rawCookieToken : null;
  const headerToken = req.get(CSRF_HEADER_NAME);
  if (!cookieToken || !headerToken || cookieToken.length !== headerToken.length) return false;
  try {
    return timingSafeEqual(Buffer.from(cookieToken, "utf8"), Buffer.from(headerToken, "utf8"));
  } catch {
    return false;
  }
}
