import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { notifyErayStudyDataChanged } from "@/lib/erayStudyEvents";
import {
  calculateTytAverages,
  createEmptyTytData,
  getTytStorageKey,
  isValidTytResults,
  parseTytStudyData,
  TYT_EXAM_NAME_LIMIT,
  TYT_MAX_EXAMS,
  TYT_SUBJECTS,
  type TytExam,
  type TytExamResults,
  type TytStudyData,
  type TytSubjectId,
} from "@shared/tyt";

const EMPTY_TYT_DATA = createEmptyTytData();

function makeId(): string {
  return typeof crypto !== "undefined" &&
    typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export function useTytData() {
  const auth = useAuth();
  const accountId = auth.user?.id;
  const storageKey =
    accountId === undefined ? null : getTytStorageKey(accountId);
  const [data, setData] = useState<TytStudyData>(createEmptyTytData);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);
  const [storageErrorShown, setStorageErrorShown] = useState(false);

  useEffect(() => {
    if (!storageKey) {
      setData(createEmptyTytData());
      setLoadedKey(null);
      return;
    }
    let stored: string | null = null;
    try {
      stored = localStorage.getItem(storageKey);
    } catch {
      toast.error("TYT verileri yüklenemedi", {
        description: "Tarayıcı depolama alanına erişilemiyor.",
      });
    }
    setData(parseTytStudyData(stored));
    setLoadedKey(storageKey);
  }, [storageKey]);

  useEffect(() => {
    if (!storageKey || loadedKey !== storageKey) return;
    try {
      const serialized = JSON.stringify(data);
      if (localStorage.getItem(storageKey) !== serialized) {
        localStorage.setItem(storageKey, serialized);
        notifyErayStudyDataChanged();
      }
      if (storageErrorShown) setStorageErrorShown(false);
    } catch {
      if (!storageErrorShown) {
        toast.error("TYT verileri saklanamadı", {
          description: "Tarayıcı hafızasında yer kalmamış olabilir.",
        });
        setStorageErrorShown(true);
      }
    }
  }, [data, loadedKey, storageErrorShown, storageKey]);

  useEffect(() => {
    if (!storageKey) return;
    const onStorage = (event: StorageEvent) => {
      if (event.key === storageKey) setData(parseTytStudyData(event.newValue));
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [storageKey]);

  const ready = Boolean(storageKey && loadedKey === storageKey);
  const visibleData = ready ? data : EMPTY_TYT_DATA;
  const averages = useMemo(
    () => calculateTytAverages(visibleData.exams),
    [visibleData.exams]
  );

  const updateGoal = useCallback(
    (subjectId: TytSubjectId, value: number | null) => {
      if (!ready) return;
      const subject = TYT_SUBJECTS.find(item => item.id === subjectId);
      if (!subject) return;
      const goal =
        value === null
          ? null
          : Math.max(
              0,
              Math.min(subject.questionCount, Math.round(value * 100) / 100)
            );
      setData(current => ({
        ...current,
        goals: { ...current.goals, [subjectId]: goal },
      }));
    },
    [ready]
  );

  const addExam = useCallback(
    (name: string, results: TytExamResults): boolean => {
      const cleanName = name.trim().slice(0, TYT_EXAM_NAME_LIMIT);
      if (
        !ready ||
        !cleanName ||
        !isValidTytResults(results) ||
        visibleData.exams.length >= TYT_MAX_EXAMS
      )
        return false;
      const exam: TytExam = {
        id: makeId(),
        name: cleanName,
        createdAt: new Date().toISOString(),
        results,
      };
      setData(current => ({ ...current, exams: [...current.exams, exam] }));
      return true;
    },
    [ready, visibleData.exams.length]
  );

  const removeExam = useCallback(
    (examId: string) => {
      if (!ready) return;
      setData(current => ({
        ...current,
        exams: current.exams.filter(exam => exam.id !== examId),
      }));
    },
    [ready]
  );

  return {
    data: visibleData,
    ready,
    averages,
    updateGoal,
    addExam,
    removeExam,
  };
}
