ALTER TABLE `chatConversations` ADD `memberOneHiddenAt` timestamp;--> statement-breakpoint
ALTER TABLE `chatConversations` ADD `memberTwoHiddenAt` timestamp;