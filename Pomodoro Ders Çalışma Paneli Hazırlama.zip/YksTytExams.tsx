import { useState, type FormEvent } from "react";
import { ChartNoAxesColumnIncreasing, ChevronDown, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useTytData } from "@/hooks/useTytData";
import {
  calculateTytExamNets,
  calculateTytExamTotal,
  getTytNetChartSegment,
  TYT_EXAM_NAME_LIMIT,
  TYT_MAX_EXAMS,
  TYT_SUBJECTS,
  type TytExamResults,
  type TytSubjectId,
} from "@shared/tyt";

type AnswerDraft = { correct: string; wrong: string };
type AnswerDrafts = Record<TytSubjectId, AnswerDraft>;

const SUBJECT_COLORS: Record<TytSubjectId, string> = {
  turkce: "#bf744f",
  sosyal: "#7189a4",
  matematik: "#d3a33f",
  fen: "#6d9681",
};

function emptyDrafts(): AnswerDrafts {
  return {
    turkce: { correct: "0", wrong: "0" },
    sosyal: { correct: "0", wrong: "0" },
    matematik: { correct: "0", wrong: "0" },
    fen: { correct: "0", wrong: "0" },
  };
}

function formatNet(value: number | null): string {
  return value === null ? "—" : value.toLocaleString("tr-TR", { maximumFractionDigits: 2 });
}

function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Tarih yok";
  return date.toLocaleDateString("tr-TR", { day: "2-digit", month: "short", year: "numeric", timeZone: "Europe/Istanbul" });
}

export default function YksTytExams() {
  const { data, ready, averages, addExam, removeExam } = useTytData();
  const [examName, setExamName] = useState("");
  const [answers, setAnswers] = useState<AnswerDrafts>(emptyDrafts);
  const [expanded, setExpanded] = useState(false);

  const changeAnswer = (subjectId: TytSubjectId, field: keyof AnswerDraft, value: string) => {
    setAnswers(current => ({ ...current, [subjectId]: { ...current[subjectId], [field]: value } }));
  };

  const submitExam = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleanName = examName.trim();
    if (!cleanName) {
      toast.error("Deneme adına bir isim yaz.");
      return;
    }

    const results = {} as TytExamResults;
    for (const subject of TYT_SUBJECTS) {
      const correct = Number(answers[subject.id].correct);
      const wrong = Number(answers[subject.id].wrong);
      if (!Number.isInteger(correct) || !Number.isInteger(wrong) || correct < 0 || wrong < 0) {
        toast.error(`${subject.label} doğru ve yanlış sayıları tam sayı ve sıfır veya daha büyük olmalı.`);
        return;
      }
      if (correct + wrong > subject.questionCount) {
        toast.error(`${subject.label} için doğru ve yanlış toplamı ${subject.questionCount} soruyu aşamaz.`);
        return;
      }
      results[subject.id] = { correct, wrong };
    }

    if (!addExam(cleanName, results)) {
      toast.error(`Deneme kaydedilemedi. En fazla ${TYT_MAX_EXAMS} deneme eklenebilir.`);
      return;
    }
    setExamName("");
    setAnswers(emptyDrafts());
    toast.success("TYT denemesi kaydedildi");
  };

  const overallAverage = data.exams.length === 0
    ? null
    : TYT_SUBJECTS.reduce((total, subject) => total + (averages[subject.id] ?? 0), 0);
  const chartExams = data.exams.slice(-10);
  const chartData = chartExams.map(exam => ({
    exam,
    nets: calculateTytExamNets(exam.results),
  }));

  return (
    <section className="space-y-4" aria-labelledby="tyt-exams-title">
      <button type="button" aria-expanded={expanded} aria-controls="tyt-exams-content" onClick={() => setExpanded(value => !value)} className="group relative mx-auto flex aspect-square w-full max-w-[350px] flex-col items-stretch justify-between gap-4 overflow-hidden rounded-2xl border border-[#bdcbd5] bg-gradient-to-br from-[#e5edf1] via-[#f8fbfc] to-[#e8f0e8] p-5 text-left shadow-[0_22px_48px_-28px_rgba(45,63,86,0.55)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_54px_-28px_rgba(45,63,86,0.65)] motion-reduce:transition-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-sage-ink sm:max-w-[380px] sm:rounded-[1.75rem] sm:p-7">
        <span aria-hidden="true" className="pointer-events-none absolute -right-10 -top-16 h-64 w-64 rounded-full border border-white/55 bg-white/20 shadow-[0_0_0_18px_rgba(255,255,255,0.12),0_0_0_38px_rgba(255,255,255,0.08)] transition duration-500 motion-reduce:transition-none group-hover:scale-110" />
        <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start gap-3">
          <span className="grid h-16 w-16 place-items-center rounded-2xl border border-white/75 bg-white/65 text-[#4d7096] shadow-sm"><ChartNoAxesColumnIncreasing className="h-8 w-8" aria-hidden="true" /></span>
          <span><span className="mb-2 inline-flex rounded-full border border-white/80 bg-white/60 px-3 py-1 text-[0.65rem] font-bold tracking-[0.18em] text-[#5d7480]">DENEME PERFORMANSIN</span><span id="tyt-exams-title" className="block font-display text-3xl font-bold leading-tight text-ink sm:text-4xl">TYT Denemelerim</span><span className="mt-2 block text-sm text-ink-faint">Denemelerini kaydet, net gelişimini takip et.</span><span className="mt-3 flex flex-wrap gap-2"><span className="rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#4c7564]">{data.exams.length} deneme</span><span className="rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#4c7564]">Ort. {formatNet(overallAverage)} net</span></span></span>
        </span>
        <span className="relative z-10 flex w-full items-center justify-between border-t border-[#617780]/15 pt-3"><span className="text-xs font-bold tracking-wide text-[#526f4b]">{expanded ? "KAPAT" : "DENEMELERİ AÇ"}</span><span className="grid h-11 w-11 place-items-center rounded-full border border-white/75 bg-white/60 text-[#526f4b] shadow-md"><ChevronDown className={`h-5 w-5 transition-transform duration-500 motion-reduce:transition-none ${expanded ? "rotate-180" : ""}`} aria-hidden="true" /></span></span>
      </button>
      <div id="tyt-exams-content" aria-hidden={!expanded} inert={!expanded} className={`grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,0.8,0.3,1)] motion-reduce:transition-none ${expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}>
       <div className="min-h-0 overflow-hidden">{expanded && <div className="yks-panel-open overflow-hidden rounded-2xl border border-[#bdcbd5] bg-gradient-to-br from-[#f8fbfc] via-[#fffdf7] to-[#f4f0e6] shadow-[0_24px_55px_-35px_rgba(45,63,86,0.62)]">
      <header className="flex flex-wrap items-center justify-between gap-4 border-b border-[#d4dedf] bg-gradient-to-r from-[#e5edf1] via-[#f6f4e8] to-[#e8f0e8] px-5 py-5 sm:px-7">
        <div>
          <p className="smallcaps flex items-center gap-1.5 text-[#5d7480]"><ChartNoAxesColumnIncreasing className="h-3.5 w-3.5" aria-hidden="true" /> DENEME PERFORMANSIN</p>
          <h2 className="mt-1 font-display text-2xl font-bold text-ink sm:text-3xl">TYT Denemelerim</h2>
          <p className="mt-1 max-w-2xl text-sm text-ink-faint">Denemelerini isimlendir, ders sonuçlarını gir ve net gelişimini takip et.</p>
        </div>
        <div className="rounded-xl border border-white/80 bg-white/65 px-4 py-2 text-right shadow-sm">
          <span className="block text-[0.62rem] font-semibold uppercase tracking-wide text-[#617780]">Genel ortalama</span>
          <span className="font-display text-2xl font-bold tabular-nums text-[#4c7564]">{formatNet(overallAverage)}<span className="ml-1 text-xs font-semibold">net</span></span>
        </div>
      </header>

      <div className="grid gap-6 p-4 sm:p-6 xl:grid-cols-[minmax(0,1.25fr)_minmax(20rem,0.75fr)]">
        <div className="min-w-0">
          <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
            <h3 className="font-display text-lg font-bold text-ink">Deneme grafiği</h3>
            <span className="text-xs text-ink-faint">{data.exams.length > 10 ? "Son 10 deneme gösteriliyor; ortalamalar tüm denemeleri kapsar." : "Ders netleri · deneme adına göre"}</span>
          </div>
          {chartData.length === 0 ? (
            <div className="flex h-[280px] flex-col items-center justify-center rounded-xl border border-dashed border-[#c8d5d7] bg-white/50 px-5 text-center">
              <ChartNoAxesColumnIncreasing className="mb-3 h-8 w-8 text-[#809b9a]" aria-hidden="true" />
              <p className="font-display text-lg font-semibold text-ink">Grafiğin burada oluşacak</p>
              <p className="mt-1 max-w-sm text-sm text-ink-faint">İlk TYT denemeni kaydettiğinde dört dersin netleri isimleriyle bu grafiğe eklenecek.</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-[#e1e7e2] bg-white/60 p-3" role="img" aria-label={`${chartData.length} TYT denemesinin dört derse göre net grafiği; çubuklar her dersin soru sayısına oranlanmıştır`}>
              <div className="min-w-[540px]">
                <div className="mb-2 flex flex-wrap gap-x-4 gap-y-1" aria-label="Grafik açıklaması">
                  {TYT_SUBJECTS.map(subject => (
                    <span key={subject.id} className="inline-flex items-center gap-1.5 text-[0.68rem] font-medium text-ink-soft">
                      <span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: SUBJECT_COLORS[subject.id] }} />{subject.label}
                    </span>
                  ))}
                </div>
                <div className="grid grid-cols-[2.25rem_minmax(0,1fr)] gap-2">
                  <div className="relative h-[205px] text-right text-[0.62rem] tabular-nums text-ink-faint" aria-hidden="true">
                    <span className="absolute right-0 top-0">%100</span>
                    <span className="absolute right-0 top-[80%] -translate-y-1/2">0</span>
                    <span className="absolute bottom-0 right-0">−25%</span>
                  </div>
                  <div>
                    <div className="relative h-[205px] border-b border-[#bdcbc6]">
                      <div className="absolute inset-x-0 top-0 border-t border-dashed border-[#d8e0dc]" />
                      <div className="absolute inset-x-0 top-[80%] border-t border-[#8c9b96]" />
                      <div className="absolute inset-x-0 bottom-0 border-t border-[#bdcbc6]" />
                      <div className="relative z-10 flex h-full items-end justify-around gap-1 px-1">
                        {chartData.map(({ exam, nets }) => (
                          <div key={exam.id} className="flex h-full min-w-[2.7rem] flex-1 flex-col items-center justify-end" title={`${exam.name} · ${TYT_SUBJECTS.map(subject => `${subject.label}: ${formatNet(nets[subject.id])} net`).join(" · ")}`}>
                            <div className="flex h-full w-full items-stretch justify-center gap-[3px]">
                              {TYT_SUBJECTS.map(subject => {
                                const segment = getTytNetChartSegment(nets[subject.id], subject.questionCount);
                                const bottom = segment.isNegative ? 0 : segment.zeroPercent;
                                return (
                                  <div key={subject.id} className="relative h-full w-3 max-w-[14%]">
                                    <div
                                      title={`${exam.name} — ${subject.label}: ${formatNet(nets[subject.id])} net`}
                                      className="absolute w-full rounded-[3px] shadow-sm transition-[height,bottom] duration-500"
                                      style={{ bottom: `${bottom}%`, height: `${segment.sizePercent}%`, minHeight: nets[subject.id] !== 0 ? 2 : 0, backgroundColor: SUBJECT_COLORS[subject.id] }}
                                    />
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="flex justify-around gap-1 pt-2">
                      {chartData.map(({ exam }) => (
                        <span key={exam.id} title={exam.name} className="min-w-[2.7rem] flex-1 truncate text-center text-[0.58rem] font-medium text-ink-soft">{exam.name.slice(0, 11)}</span>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="mt-2 text-right text-[0.62rem] text-ink-faint">Sıfır çizgisinin altı eksi, üstü artı neti gösterir; çubuklar dersin soru sayısına oranlıdır.</p>
              </div>
            </div>
          )}

          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {TYT_SUBJECTS.map(subject => (
              <div key={subject.id} className="rounded-xl border border-[#e0e5dc] bg-white/70 px-3 py-2.5">
                <span className="block truncate text-xs font-semibold text-ink-soft">{subject.label} ort.</span>
                <span className="mt-0.5 block font-display text-xl font-bold tabular-nums text-[#4c7564]">{formatNet(averages[subject.id])}<span className="ml-1 text-[0.65rem] font-semibold">net</span></span>
              </div>
            ))}
          </div>
        </div>

        <div className="min-w-0 rounded-2xl border border-[#d8ded7] bg-white/65 p-4 sm:p-5">
          <div className="mb-4">
            <p className="smallcaps text-[#617780]">YENİ SONUÇ EKLE</p>
            <h3 className="mt-1 font-display text-xl font-bold text-ink">Denemeni kaydet</h3>
          </div>
          <form onSubmit={submitExam} className="space-y-3" aria-label="TYT deneme sonucu ekle">
            <div>
              <label htmlFor="tyt-exam-name" className="mb-1.5 block text-xs font-semibold text-ink-soft">Deneme adı</label>
              <input
                id="tyt-exam-name"
                value={examName}
                onChange={event => setExamName(event.target.value)}
                maxLength={TYT_EXAM_NAME_LIMIT}
                disabled={!ready || data.exams.length >= TYT_MAX_EXAMS}
                placeholder="Örn. 3D TYT Deneme 1"
                className="h-11 w-full rounded-lg border border-[#d4ddd7] bg-white px-3 text-sm text-ink outline-none placeholder:text-ink-faint focus:border-[#6e9c8c] focus:ring-2 focus:ring-[#6e9c8c]/15 disabled:opacity-50"
              />
            </div>

            <div className="space-y-2">
              {TYT_SUBJECTS.map(subject => {
                const correct = Number(answers[subject.id].correct || 0);
                const wrong = Number(answers[subject.id].wrong || 0);
                const blank = Math.max(0, subject.questionCount - correct - wrong);
                return (
                  <fieldset key={subject.id} className="rounded-xl border border-[#e1e5dd] bg-[#fcfbf6] p-3">
                    <legend className="px-1 text-sm font-semibold text-ink">{subject.label}<span className="ml-1 text-xs font-normal text-ink-faint">{subject.questionCount} soru</span></legend>
                    <div className="grid grid-cols-[1fr_1fr_auto] items-end gap-2">
                      <label className="min-w-0">
                        <span className="mb-1 block text-[0.65rem] text-ink-faint">Doğru</span>
                        <input type="number" min={0} max={subject.questionCount} step={1} value={answers[subject.id].correct} onChange={event => changeAnswer(subject.id, "correct", event.target.value)} disabled={!ready} aria-label={`${subject.label} doğru sayısı`} className="h-9 w-full rounded-md border border-[#d7dfd8] bg-white px-2 text-sm tabular-nums text-ink outline-none focus:border-[#6e9c8c] focus:ring-2 focus:ring-[#6e9c8c]/15 disabled:opacity-50" />
                      </label>
                      <label className="min-w-0">
                        <span className="mb-1 block text-[0.65rem] text-ink-faint">Yanlış</span>
                        <input type="number" min={0} max={subject.questionCount} step={1} value={answers[subject.id].wrong} onChange={event => changeAnswer(subject.id, "wrong", event.target.value)} disabled={!ready} aria-label={`${subject.label} yanlış sayısı`} className="h-9 w-full rounded-md border border-[#d7dfd8] bg-white px-2 text-sm tabular-nums text-ink outline-none focus:border-[#6e9c8c] focus:ring-2 focus:ring-[#6e9c8c]/15 disabled:opacity-50" />
                      </label>
                      <span className="pb-2 text-[0.67rem] tabular-nums text-ink-faint">Boş: {blank}</span>
                    </div>
                  </fieldset>
                );
              })}
            </div>

            <p className="rounded-lg bg-[#f1f4ec] px-3 py-2 text-[0.7rem] leading-relaxed text-[#61736c]">Net hesabı: doğru − yanlış ÷ 4. Boş cevaplar neti etkilemez.</p>
            <button type="submit" disabled={!ready || !examName.trim() || data.exams.length >= TYT_MAX_EXAMS} className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#526f91] to-[#5a8875] px-4 text-sm font-bold text-white shadow-[0_8px_16px_-9px_rgba(45,63,86,0.75)] transition hover:-translate-y-0.5 hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-50">
              <Plus className="h-4 w-4" aria-hidden="true" /> Deneme sonuçlarını kaydet
            </button>
          </form>
        </div>
      </div>

      <div className="border-t border-[#d4dedf] px-4 py-5 sm:px-6">
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <h3 className="font-display text-lg font-bold text-ink">Kaydedilen denemeler</h3>
          <span className="text-xs text-ink-faint">{data.exams.length} / {TYT_MAX_EXAMS}</span>
        </div>
        {data.exams.length === 0 ? (
          <p className="rounded-xl bg-white/60 px-4 py-5 text-center text-sm text-ink-faint">Henüz kaydedilmiş deneme yok.</p>
        ) : (
          <ul className="space-y-2">
            {[...data.exams].reverse().map(exam => {
              const nets = calculateTytExamNets(exam.results);
              const total = calculateTytExamTotal(exam.results);
              return (
                <li key={exam.id} className="flex flex-col gap-3 rounded-xl border border-[#dfe5dd] bg-white/70 p-3 sm:flex-row sm:items-center sm:justify-between sm:px-4">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#e9f0eb] text-[#567d6b]"><ChartNoAxesColumnIncreasing className="h-5 w-5" aria-hidden="true" /></div>
                    <div className="min-w-0">
                      <h4 className="truncate font-semibold text-ink">{exam.name}</h4>
                      <p className="text-xs text-ink-faint">{formatDate(exam.createdAt)} · toplam {formatNet(total)} net</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 sm:justify-end">
                    {TYT_SUBJECTS.map(subject => (
                      <span key={subject.id} className="rounded-full border border-[#e1e7df] bg-[#fafbf7] px-2.5 py-1 text-[0.68rem] font-semibold tabular-nums text-[#4d675d]">{subject.label.slice(0, 3)} {formatNet(nets[subject.id])}</span>
                    ))}
                    <button type="button" onClick={() => removeExam(exam.id)} aria-label={`${exam.name} denemesini sil`} title="Denemeyi sil" className="ml-auto grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-[#eadbd5] bg-[#fff8f5] text-[#985343] transition hover:bg-white hover:text-[#a33524] sm:ml-1"><Trash2 className="h-4 w-4" aria-hidden="true" /></button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
      </div>}</div></div>
    </section>
  );
}
