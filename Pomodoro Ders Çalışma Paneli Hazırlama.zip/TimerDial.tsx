import { Fragment } from "react";
import { formatClock } from "@/lib/pomodoro/format";
import { PHASE_META, type Phase } from "@/lib/pomodoro/types";
import { cn } from "@/lib/utils";

interface TimerDialProps {
  phase: Phase;
  remainingSec: number;
  totalSec: number;
  running: boolean;
  cycle: number;
  interval: number;
  taskTitle: string | null;
}

const CENTER = 150;
const RING_R = 118;
const CIRC = 2 * Math.PI * RING_R;

const TICKS = Array.from({ length: 60 }, (_, i) => {
  const major = i % 5 === 0;
  const angle = ((i * 6 - 90) * Math.PI) / 180;
  const outer = 142;
  const inner = major ? 127 : 134;
  return {
    i,
    major,
    x1: CENTER + Math.cos(angle) * inner,
    y1: CENTER + Math.sin(angle) * inner,
    x2: CENTER + Math.cos(angle) * outer,
    y2: CENTER + Math.sin(angle) * outer,
  };
});

export default function TimerDial({
  phase,
  remainingSec,
  totalSec,
  running,
  cycle,
  interval,
  taskTitle,
}: TimerDialProps) {
  const meta = PHASE_META[phase];
  const remainingFraction = totalSec > 0 ? Math.max(0, Math.min(1, remainingSec / totalSec)) : 0;
  const handAngle = 360 * remainingFraction;
  const filled = cycle % interval === 0 && cycle > 0 ? interval : cycle % interval;

  return (
    <div className="relative mx-auto aspect-square w-full max-w-[330px]">
      <svg
        viewBox="0 0 300 300"
        className={cn("h-full w-full", running && "dial-breath")}
        role="img"
        aria-label={`${meta.label} kalan süre ${formatClock(remainingSec)}`}
      >
        <defs>
          <radialGradient id="dial-face" cx="38%" cy="26%" r="82%">
            <stop offset="0%" stopColor="#FFFBF1" />
            <stop offset="62%" stopColor="#F8EEDA" />
            <stop offset="100%" stopColor="#EEDDBA" />
          </radialGradient>
        </defs>

        <circle cx={CENTER} cy={CENTER} r={146} fill="url(#dial-face)" stroke="rgba(90,66,34,0.35)" strokeWidth={1} />
        <circle cx={CENTER} cy={CENTER} r={139} fill="none" stroke="rgba(90,66,34,0.16)" strokeWidth={1} />

        {TICKS.map(t => (
          <line
            key={t.i}
            x1={t.x1}
            y1={t.y1}
            x2={t.x2}
            y2={t.y2}
            stroke={t.major ? "rgba(45,34,22,0.7)" : "rgba(109,91,69,0.35)"}
            strokeWidth={t.major ? 2 : 1}
            strokeLinecap="round"
          />
        ))}

        <circle cx={CENTER} cy={CENTER} r={RING_R} fill="none" stroke="rgba(160,138,104,0.24)" strokeWidth={13} />
        <circle
          cx={CENTER}
          cy={CENTER}
          r={RING_R}
          fill="none"
          stroke={meta.accent}
          strokeWidth={13}
          strokeLinecap="round"
          strokeDasharray={CIRC}
          strokeDashoffset={CIRC * (1 - remainingFraction)}
          transform={`rotate(-90 ${CENTER} ${CENTER})`}
          className="progress-move"
          opacity={0.92}
        />

        <circle cx={CENTER} cy={CENTER} r={101} fill="none" stroke="rgba(90,66,34,0.14)" strokeWidth={1} />

        <g
          className="hand-move"
          style={{ transform: `rotate(${handAngle}deg)`, transformOrigin: `${CENTER}px ${CENTER}px` }}
        >
          <line
            x1={CENTER}
            y1={CENTER - 24}
            x2={CENTER}
            y2={CENTER - 133}
            stroke={meta.accent}
            strokeWidth={2}
            strokeLinecap="round"
            opacity={0.85}
          />
          <circle cx={CENTER} cy={CENTER - 133} r={3.4} fill={meta.accent} />
        </g>
        <circle cx={CENTER} cy={CENTER} r={6.5} fill="#FDF8EC" stroke={meta.accent} strokeWidth={2} />
      </svg>

      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-1 px-10 text-center">
        <span className="smallcaps" style={{ color: meta.accent }}>
          {meta.label}
        </span>

        <span
          className="font-display text-[clamp(3rem,13vw,4.15rem)] leading-none font-semibold tracking-tight text-ink"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          {formatClock(remainingSec).split(":").map((part, index) => (
            <Fragment key={`${index}-${part}`}>
              {index > 0 && (
                <span aria-hidden="true" className="mx-[0.12em] inline-flex translate-y-[-0.08em] flex-col items-center justify-center gap-[0.14em] align-middle">
                  <span className="h-[0.07em] w-[0.14em] rounded-[1px] bg-current" />
                  <span className="h-[0.07em] w-[0.14em] rounded-[1px] bg-current" />
                </span>
              )}
              {part}
            </Fragment>
          ))}
        </span>

        <div className="mt-1 flex items-center gap-1.5">
          {Array.from({ length: interval }, (_, i) => (
            <span
              key={i}
              className={cn(
                "h-2 w-2 rounded-full border transition-colors",
                i < filled ? "border-transparent" : "border-[rgba(109,91,69,0.45)]",
              )}
              style={i < filled ? { backgroundColor: PHASE_META.focus.accent } : undefined}
            />
          ))}
        </div>

        <p className="mt-2 line-clamp-2 max-w-[15rem] text-sm leading-snug text-ink-soft">
          {taskTitle ? <>Şu an: <span className="font-semibold text-ink">{taskTitle}</span></> : meta.note}
        </p>
      </div>
    </div>
  );
}
