import { trpc } from "@/lib/trpc";

function HeadlineGroup({ items, duplicate = false }: { items: { id: number; content: string }[]; duplicate?: boolean }) {
  return (
    <div className="ticker-group" aria-hidden={duplicate || undefined}>
      {items.map((item) => (
        <span className="ticker-item" key={item.id}>
          <span aria-hidden="true" className="h-1.5 w-1.5 shrink-0 rounded-full bg-[#b45309]" />
          {item.content}
        </span>
      ))}
    </div>
  );
}

export default function NewsTicker() {
  const items = trpc.homeTicker.list.useQuery(undefined, { refetchInterval: 15_000 });

  if (items.isLoading) {
    return <div className="mb-6 h-11 w-full overflow-hidden rounded-md border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.88)]" role="status" aria-label="Kayan yazılar yükleniyor" />;
  }

  if (items.isError) {
    return <div className="mb-6 rounded-md border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.88)] px-4 py-3 text-sm text-ink-faint" role="alert">Kayan yazılar yüklenemedi.</div>;
  }

  const messages = items.data ?? [];

  return (
    <section
      aria-label="Kayan yazılar"
      className="mb-6 flex min-h-11 min-w-0 overflow-hidden rounded-md border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.88)] shadow-sm"
    >
      <div
        className="ticker-window min-w-0 flex-1"
        role="group"
        aria-label="Akıştaki odak yazıları"
        tabIndex={0}
      >
        {messages.length > 0 && (
          <div className="ticker-track">
            <HeadlineGroup items={messages} />
            <HeadlineGroup items={messages} duplicate />
          </div>
        )}
      </div>
    </section>
  );
}
