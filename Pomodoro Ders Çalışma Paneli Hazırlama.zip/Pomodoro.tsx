import { useEffect, useState } from "react";
import { ArrowLeft, Check, ChevronRight, Keyboard, LogOut, MessageCircle, Settings2, Volume2, VolumeX } from "lucide-react";
import { toast } from "sonner";
import { Link } from "wouter";

import { useAuth } from "@/_core/hooks/useAuth";
import PhaseTabs from "@/components/pomodoro/PhaseTabs";
import ProfileAvatar from "@/components/pomodoro/ProfileAvatar";
import ProfileShareCard from "@/components/pomodoro/ProfileShareCard";
import LegacyImportCard from "@/components/pomodoro/LegacyImportCard";
import PomodoroStudyPanel from "@/components/pomodoro/PomodoroStudyPanel";
import SettingsDialog from "@/components/pomodoro/SettingsDialog";
import SessionLog from "@/components/pomodoro/SessionLog";
import StatsCard from "@/components/pomodoro/StatsCard";
import TaskLedger from "@/components/pomodoro/TaskLedger";
import TimerControls from "@/components/pomodoro/TimerControls";
import TimerDial from "@/components/pomodoro/TimerDial";
import Wordmark from "@/components/pomodoro/Wordmark";
import { usePomodoro } from "@/hooks/usePomodoro";
import { formatClock, formatLongDate, formatMinutes } from "@/lib/pomodoro/format";
import { KEYS } from "@/lib/pomodoro/storage";
import { PHASE_META } from "@/lib/pomodoro/types";

const SHORTCUTS = [
  { keys: "Boşluk", action: "başlat / duraklat" },
  { keys: "R", action: "sıfırla" },
  { keys: "S", action: "atla" },
  { keys: "G", action: "görevi bitir" },
];

const currentTimeFormat = new Intl.DateTimeFormat("tr-TR", {
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
});

export default function PomodoroPage() {
  const auth = useAuth();
  const pomo = usePomodoro();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const today = formatLongDate(now);
  const pending = pomo.tasks.filter(t => !t.done);

  useEffect(() => {
    const intervalId = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(intervalId);
  }, []);

  /** Aktif görevi kapatır ve sıradaki yapılmamış göreve geçer. */
  const completeActive = () => {
    const result = pomo.finishActiveTask();
    if (!result) return;
    toast.success(`${result.title} tamamlandı`, {
      description: result.left > 0 ? "Sıradaki görev seçildi." : "Defterde sıra bekleyen kalmadı. Aferin.",
      duration: 6000,
    });
  };

  const toggleTimer = () => {
    if (!pomo.running && pomo.phase === "focus" && !pomo.studySelection) {
      toast.error("Pomodoro’yu başlatmadan önce YKS Mod’dan bir ders ve konu seç.");
      return;
    }
    pomo.toggle();
  };

  /* Sekme başlığında geri sayım */
  useEffect(() => {
    const base = "Odak Paneli — Pomodoro Çalışma Saati";
    document.title = pomo.running
      ? `${String(Math.floor(pomo.remainingSec / 60)).padStart(2, "0")}:${String(pomo.remainingSec % 60).padStart(2, "0")} · ${pomo.phaseMeta.label} — Odak Paneli`
      : base;
    return () => {
      document.title = base;
    };
  }, [pomo.running, pomo.remainingSec, pomo.phaseMeta.label]);

  /* Aşama bitince panel içi bildirim */
  useEffect(() => {
    const finished = pomo.finishedPhase;
    if (!finished) return;
    const isFocus = finished.phase === "focus";
    const task = pomo.activeTask;
    toast(isFocus ? "Tur tamam — molaya geç" : "Mola bitti — masaya dön", {
      description: isFocus
        ? `${pomo.settings.focusMin} dakika deftere işlendi. Sıradaki: ${pomo.phaseMeta.label.toLowerCase()}.`
        : "Saati başlat, kaldığın yerden devam et.",
      duration: 9000,
      action:
        isFocus && task
          ? {
              label: "Görevi bitir",
              onClick: () => completeActive(),
            }
          : undefined,
    });
    pomo.clearFinished();
  }, [pomo]);

  /* Klavye kısayolları */
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (settingsOpen || event.metaKey || event.ctrlKey || event.altKey) return;
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) {
        return;
      }
      if (event.code === "Space") {
        event.preventDefault();
        toggleTimer();
      } else if (event.key === "r" || event.key === "R") {
        pomo.reset();
      } else if (event.key === "s" || event.key === "S") {
        pomo.skip();
      } else if (event.key === "g" || event.key === "G") {
        event.preventDefault();
        completeActive();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [completeActive, pomo, settingsOpen, toggleTimer]);

  const clearAll = () => {
    Object.values(KEYS).forEach(key => {
      try {
        localStorage.removeItem(key);
      } catch {
        /* yoksay */
      }
    });
    window.location.reload();
  };

  const goalLeft = Math.max(0, pomo.stats.goal - pomo.stats.pomodoros);

  return (
    <div className="desk-glow paper-grain relative min-h-screen">
      <div className="relative z-10 mx-auto w-full max-w-6xl px-4 pb-12 sm:px-6">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-[rgba(90,66,34,0.28)] py-5">
          <div className="flex flex-wrap items-center gap-3 sm:gap-4">
            <ProfileAvatar />
            <Wordmark />
            <div className="border-l border-[rgba(90,66,34,0.24)] pl-3 sm:pl-4" aria-label={`Saat ${currentTimeFormat.format(now)}, ${today}`}>
              <time className="block font-display text-base font-bold tabular-nums leading-tight text-ink sm:text-lg" dateTime={now.toISOString()}>
                {currentTimeFormat.format(now)}
              </time>
              <span className="mt-1 block text-xs text-ink-faint">{today}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2">
            <Link
              href="/"
              className="flex h-9 items-center gap-1.5 rounded-sm border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.75)] px-2.5 text-sm text-ink-soft transition hover:border-amber-ink hover:text-amber-ink"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Ana sayfa</span>
            </Link>
            <span className="max-w-28 truncate rounded-sm bg-[rgba(233,215,179,0.45)] px-2 py-1 text-xs font-semibold text-ink-soft" title={auth.user?.username}>
              {auth.user?.username}
            </span>
            <button
              type="button"
              onClick={() => pomo.updateSettings({ soundEnabled: !pomo.settings.soundEnabled })}
              title={pomo.settings.soundEnabled ? "Sesli uyarı açık" : "Sesli uyarı kapalı"}
              aria-label="Sesli uyarıyı değiştir"
              className="grid h-9 w-9 place-items-center rounded-sm border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.75)] text-ink-soft transition hover:border-amber-ink hover:text-amber-ink"
            >
              {pomo.settings.soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </button>
            <Link
              href="/eray-bugun"
              aria-label="Sohbet"
              className="flex h-9 items-center gap-1.5 rounded-sm border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.75)] px-2.5 text-sm text-ink-soft transition hover:border-amber-ink hover:text-amber-ink"
            >
              <MessageCircle className="h-4 w-4 shrink-0" />
              <span>Sohbet</span>
            </Link>
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              aria-label="Ayarları aç"
              className="flex h-9 items-center gap-1.5 rounded-sm border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.75)] px-2.5 text-sm text-ink-soft transition hover:border-amber-ink hover:text-amber-ink"
            >
              <Settings2 className="h-4 w-4" />
              <span className="hidden sm:inline">Ayarlar</span>
            </button>
            <button
              type="button"
              onClick={() => void auth.logout().catch(error => toast.error("Çıkış yapılamadı", { description: error instanceof Error ? error.message : "Biraz sonra yeniden dene." }))}
              aria-label="Çıkış yap"
              title="Çıkış yap"
              className="grid h-9 w-9 place-items-center rounded-sm border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.75)] text-ink-soft transition hover:border-destructive hover:text-destructive"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </header>

        <main className="mt-6 grid items-start gap-5 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]">
          <section className="plate relative overflow-hidden rounded-md">
            <span className="screw top-2.5 left-2.5" />
            <span className="screw top-2.5 right-2.5" />
            <span className="screw bottom-2.5 left-2.5" />
            <span className="screw bottom-2.5 right-2.5" />

            <div className="border-b border-[rgba(90,66,34,0.2)] px-4 pt-4">
              <PhaseTabs
                phase={pomo.phase}
                focusMin={pomo.settings.focusMin}
                shortMin={pomo.settings.shortMin}
                longMin={pomo.settings.longMin}
                onSelect={pomo.switchPhase}
              />
            </div>

            <div className="px-5 pt-5 pb-6">
              <TimerDial
                phase={pomo.phase}
                remainingSec={pomo.remainingSec}
                totalSec={pomo.totalSec}
                running={pomo.running}
                cycle={pomo.cycle}
                interval={pomo.settings.longBreakInterval}
                taskTitle={pomo.phase === "focus" ? (pomo.activeTask?.title ?? null) : null}
              />

              <div className="mt-6">
                <TimerControls
                  phase={pomo.phase}
                  running={pomo.running}
                  onToggle={toggleTimer}
                  onReset={pomo.reset}
                  onSkip={pomo.skip}
                />
              </div>

              <p className="mt-4 text-center text-sm text-ink-soft">
                {pomo.running ? (
                  <>
                    <span style={{ color: pomo.phaseMeta.accent }} className="font-semibold">
                      {pomo.phaseMeta.label} sürüyor
                    </span>
                    {" · "}
                    {pomo.phase === "focus"
                      ? `tur ${Math.min(pomo.cycle + 1, pomo.settings.longBreakInterval)}/${pomo.settings.longBreakInterval}`
                      : pomo.phaseMeta.note}
                  </>
                ) : pomo.remainingSec < pomo.totalSec ? (
                  <>
                    Duraklatıldı ·{" "}
                    <span className="font-display font-semibold text-ink">{formatClock(pomo.remainingSec)}</span>{" "}
                    kaldı
                  </>
                ) : pomo.phase === "focus" ? (
                  "Hazır — Başlat'a bastığında sayaç işlemeye başlar."
                ) : (
                  pomo.phaseMeta.note
                )}
              </p>

              {pending.length > 0 && (
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  {pomo.activeTask ? (
                    <button
                      type="button"
                      onClick={completeActive}
                      className="inline-flex max-w-full items-center gap-2 rounded-full border border-[rgba(91,122,84,0.55)] bg-[rgba(91,122,84,0.10)] px-3.5 py-1.5 text-[0.78rem] font-semibold text-sage-ink transition hover:-translate-y-0.5 hover:bg-[rgba(91,122,84,0.2)] active:translate-y-0"
                    >
                      <Check className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">Bitir: {pomo.activeTask.title}</span>
                      <kbd className="rounded-[3px] border border-[rgba(91,122,84,0.4)] px-1 text-[0.62rem]">G</kbd>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => pomo.nextTask()}
                      className="inline-flex items-center gap-1.5 rounded-full border border-[rgba(90,66,34,0.3)] px-3.5 py-1.5 text-[0.78rem] font-semibold text-ink-soft transition hover:-translate-y-0.5 hover:border-amber-ink hover:text-amber-ink"
                    >
                      <ChevronRight className="h-3.5 w-3.5" />
                      Yapılacak bir görev seç ({pending.length} bekliyor)
                    </button>
                  )}

                  {pomo.activeTask && pending.length > 1 && (
                    <button
                      type="button"
                      onClick={() => pomo.nextTask()}
                      className="inline-flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[0.76rem] text-ink-faint transition hover:bg-[rgba(160,138,104,0.16)] hover:text-ink-soft"
                    >
                      <ChevronRight className="h-3.5 w-3.5" />
                      Sonraki görev
                    </button>
                  )}
                </div>
              )}

              {pending.length === 0 && pomo.tasks.length > 0 && (
                <p className="mt-4 text-center text-[0.8rem] text-sage-ink">
                  Defterdeki tüm görevler tamam. Yeni bir ders ekleyebilirsin.
                </p>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1.5 border-t border-[rgba(90,66,34,0.18)] bg-[rgba(233,215,179,0.42)] px-5 py-2.5 text-[0.78rem] text-ink-soft">
              <span>
                Bugün <strong className="font-display text-ink">{pomo.stats.pomodoros}</strong> tur ·{" "}
                <strong className="font-display text-ink">{formatMinutes(pomo.stats.focusSeconds)}</strong> odak
              </span>
              <span className="text-ink-faint">
                {goalLeft > 0 ? `Hedefe ${goalLeft} tur kaldı` : "Günlük hedef tamam"}
              </span>
            </div>
          </section>

          <div className="grid gap-5">
            <PomodoroStudyPanel />
            <LegacyImportCard />
            <ProfileShareCard />
            <TaskLedger
              tasks={pomo.tasks}
              activeTaskId={pomo.activeTask?.id ?? null}
              onAdd={pomo.addTask}
              onSelect={pomo.selectTask}
              onFinish={pomo.finishTask}
              onUnfinish={pomo.toggleTaskDone}
              onRemove={pomo.removeTask}
            />
            <StatsCard
              stats={pomo.stats}
              week={pomo.week}
              weeks={pomo.weeks}
              studyEntries={pomo.studyEntries}
              focusSessions={pomo.todayFocusSessions}
              canEditStudyEntries={auth.user?.isEray === true}
              onUpdateStudyEntry={pomo.updateStudyEntry}
              onDeleteStudyEntry={pomo.deleteStudyEntry}
              onUpdateFocusSession={pomo.updateFocusSession}
              onDeleteFocusSession={pomo.deleteFocusSession}
            />
            <SessionLog sessions={pomo.recentSessions} />
          </div>
        </main>

        <footer className="mt-7 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-[0.75rem] text-ink-faint">
          <span className="flex items-center gap-1.5">
            <Keyboard className="h-3.5 w-3.5" />
            Kısayollar:
          </span>
          {SHORTCUTS.map(s => (
            <span key={s.keys}>
              <kbd className="rounded-[3px] border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.8)] px-1.5 py-0.5 font-sans text-[0.7rem] text-ink-soft">
                {s.keys}
              </kbd>{" "}
              {s.action}
            </span>
          ))}
          <span className="hidden sm:inline">· Panel verileri bu tarayıcıda; herkese açık profil yalnızca seçip paylaştığında</span>
        </footer>
      </div>

      <SettingsDialog
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        settings={pomo.settings}
        onChange={pomo.updateSettings}
        permission={pomo.permission}
        onEnableNotifications={pomo.enableNotifications}
        onClearData={clearAll}
      />
    </div>
  );
}
