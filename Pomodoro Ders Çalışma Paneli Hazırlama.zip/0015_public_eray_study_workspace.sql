CREATE TABLE `publicErayStudyWorkspaces` (
	`id` int NOT NULL,
	`ownerUserId` int NOT NULL,
	`snapshotJson` longtext NOT NULL,
	`pomodoroPhase` enum('focus','short','long') NOT NULL DEFAULT 'focus',
	`pomodoroRunning` boolean NOT NULL DEFAULT false,
	`pomodoroEndAt` bigint,
	`pomodoroRemainingSec` int NOT NULL DEFAULT 1500,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `publicErayStudyWorkspaces_id` PRIMARY KEY(`id`),
	CONSTRAINT `publicErayStudyWorkspaces_ownerUserId_unique` UNIQUE(`ownerUserId`)
);
--> statement-breakpoint
ALTER TABLE `publicErayStudyWorkspaces` ADD CONSTRAINT `publicErayStudyWorkspaces_ownerUserId_users_id_fk` FOREIGN KEY (`ownerUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;