"""Odak Paneli marka işareti: masa saati silueti (amber mürekkep, krem plaka)."""

from PIL import Image, ImageDraw

S = 4  # antialiasing supersample factor
SIZE = 512 * S
AMBER = (180, 83, 9, 255)
CREAM = (253, 248, 236, 255)
PAPER = (244, 231, 204, 0)

img = Image.new("RGBA", (SIZE, SIZE), PAPER)
d = ImageDraw.Draw(img)

cx, cy = SIZE // 2, int(SIZE * 0.575)
r = int(SIZE * 0.30)
lw = int(SIZE * 0.033)


def ring(x, y, radius, color, width):
    d.ellipse(
        [x - radius, y - radius, x + radius, y + radius],
        outline=color,
        width=width,
    )


# kulaklar / çanlar
for bx in (cx - int(r * 0.72), cx + int(r * 0.72)):
    ring(bx, cy - int(r * 1.02), int(r * 0.26), AMBER, lw)

# gövde
ring(cx, cy, r, AMBER, lw)

# iç plaka
d.ellipse(
    [cx - r + lw, cy - r + lw, cx + r - lw, cy + r - lw],
    fill=CREAM,
)

# akrep ve yelkovan
d.line([cx, cy, cx, cy - int(r * 0.62)], fill=AMBER, width=lw)
d.line([cx, cy, cx + int(r * 0.42), cy + int(r * 0.26)], fill=AMBER, width=lw)
d.ellipse(
    [cx - lw, cy - lw, cx + lw, cy + lw],
    fill=AMBER,
)

# saat 12 işareti
d.line([cx, cy - int(r * 0.82), cx, cy - int(r * 0.92)], fill=AMBER, width=lw)

# ayaklar
d.line([cx - int(r * 0.6), cy + int(r * 0.82), cx - int(r * 0.82), cy + int(r * 1.12)], fill=AMBER, width=lw)
d.line([cx + int(r * 0.6), cy + int(r * 0.82), cx + int(r * 0.82), cy + int(r * 1.12)], fill=AMBER, width=lw)

img = img.resize((512, 512), Image.LANCZOS)
img.save("/home/ubuntu/odakpaneli/client/public/odak-logo.png")
print("ok")
