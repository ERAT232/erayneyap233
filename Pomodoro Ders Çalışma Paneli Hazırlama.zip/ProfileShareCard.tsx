import { useState } from "react";
import { Copy, ExternalLink, EyeOff, LoaderCircle, Share2, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  getProfilePhotoStorageKey,
  loadHistory,
  loadSessions,
  loadStudyEntries,
} from "@/lib/pomodoro/storage";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { includeManualStudyFocusHistory } from "@shared/studyTracking";

function loadPublicData() {
  const profilePhoto = localStorage.getItem(getProfilePhotoStorageKey());
  const sessions = loadSessions()
    .filter(session => session.phase === "focus" && session.completed && session.actualSec > 0)
    .map(session => ({
      endedAt: Math.trunc(session.endedAt),
      minutes: Math.max(1, Math.min(120, Math.round(session.actualSec / 60))),
    }))
    .sort((a, b) => b.endedAt - a.endedAt)
    .slice(0, 400);
  const days = Object.entries(
    includeManualStudyFocusHistory(loadHistory(), loadStudyEntries())
  )
    .map(([date, totals]) => ({ date, pomodoros: totals.pomodoros, focusSeconds: totals.focusSeconds }))
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 2_000);
  return { profilePhoto, sessions, days };
}

export default function ProfileShareCard() {
  const utils = trpc.useUtils();
  const profileQuery = trpc.profile.mine.useQuery();
  const [pending, setPending] = useState(false);
  const save = trpc.profile.save.useMutation({
    onSuccess: async profile => {
      await utils.profile.mine.invalidate();
      toast.success(profile.isPublic ? "Profilin herkese açık" : "Profilin gizlendi", {
        description: profile.isPublic ? "Bağlantını kopyalayıp paylaşabilirsin." : "Profil bağlantısı artık görüntülenemez.",
      });
    },
    onError: error => toast.error("Profil kaydedilemedi", { description: error.message }),
    onSettled: () => setPending(false),
  });

  const profile = profileQuery.data;
  const shareUrl = profile?.shareId ? `${window.location.origin}/paylasim/${profile.shareId}` : null;

  const publishOrUpdate = () => {
    const local = loadPublicData();
    const old = profileQuery.data;
    const sessionsByEnd = new Map<number, { endedAt: number; minutes: number }>();
    for (const session of [...(old?.sessions ?? []), ...local.sessions]) sessionsByEnd.set(session.endedAt, session);
    const daysByDate = new Map<string, { date: string; pomodoros: number; focusSeconds: number }>();
    for (const day of [...(old?.days ?? []), ...local.days]) {
      const previous = daysByDate.get(day.date);
      daysByDate.set(day.date, previous
        ? { ...day, pomodoros: Math.max(previous.pomodoros, day.pomodoros), focusSeconds: Math.max(previous.focusSeconds, day.focusSeconds) }
        : day);
    }
    if (!local.profilePhoto) {
      toast.info("Sol üstten profil fotoğrafı ekleyebilirsin", {
        description: "Fotoğraf olmadan da odak geçmişin paylaşılır; önceki paylaşılmış fotoğrafın korunur.",
      });
    }
    setPending(true);
    save.mutate({
      profilePhoto: local.profilePhoto ?? old?.profilePhoto ?? null,
      sessions: [...sessionsByEnd.values()].sort((a, b) => b.endedAt - a.endedAt).slice(0, 400),
      days: [...daysByDate.values()].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 2_000),
      isPublic: true,
    });
  };

  const unpublish = () => {
    if (!profile) return;
    setPending(true);
    save.mutate({
      profilePhoto: profile.profilePhoto,
      sessions: profile.sessions,
      days: profile.days,
      isPublic: false,
    });
  };

  const copyLink = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast.success("Profil bağlantısı kopyalandı");
    } catch {
      toast.error("Bağlantı kopyalanamadı", { description: "Adres çubuğundaki bağlantıyı seçip kopyala." });
    }
  };

  return (
    <section className="plate relative rounded-md px-5 py-4">
      <span className="screw top-2 left-2" />
      <span className="screw top-2 right-2" />
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-lg leading-none font-bold text-ink">Odak Geçmişini Paylaş</h2>
          <p className="mt-1 text-[0.68rem] font-semibold tracking-[0.08em] text-ink-faint uppercase">
            Fotoğraf + odak kayıtları · görev adları/e-posta gizli
          </p>
        </div>
        <Share2 className="h-4 w-4 shrink-0 text-amber-ink" />
      </div>

      {profileQuery.isLoading ? (
        <div className="mt-4 flex items-center gap-2 text-sm text-ink-faint">
          <LoaderCircle className="h-4 w-4 animate-spin" /> Profil ayarları yükleniyor…
        </div>
      ) : profileQuery.isError ? (
        <p className="mt-3 text-sm text-destructive">Profil servisine ulaşılamadı. Biraz sonra yeniden dene.</p>
      ) : (
        <>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-soft">
            {profile?.isPublic
              ? "Herkes profil bağlantını açabilir. Değişiklikleri yeniden aktararak fotoğrafını ve geçmişini güncellersin."
              : "Yayınlama yalnızca bu hesaba ait fotoğrafı ve odak geçmişini aktarır; ders başlıkları paylaşılmaz."}
          </p>
          <p className="mt-2 text-[0.72rem] text-ink-faint">
            {profile?.isPublic
              ? `${profile.sessions.length} oturum · ${profile.days.length} günlük kayıt paylaşımda`
              : "Aktarılacaklar: profil fotoğrafı, günlük odak toplamları ve oturumların tarih/süresi."}
          </p>
          <p className="mt-1 text-[0.7rem] text-ink-faint">
            Güncelleme yeni kayıtları birleştirir; başka tarayıcıdaki mevcut paylaşımı boşaltmaz.
          </p>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={pending || save.isPending}
              onClick={publishOrUpdate}
              className={cn(
                "inline-flex items-center gap-2 rounded-sm px-3.5 py-2 text-sm font-semibold text-[#fffaf0] transition hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-60",
                profile?.isPublic ? "bg-sage-ink" : "bg-amber-ink",
              )}
            >
              {pending || save.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
              {profile?.isPublic ? "Profili güncelle" : "Aktar ve herkese aç"}
            </button>

            {profile?.isPublic && shareUrl && (
              <>
                <button
                  type="button"
                  onClick={() => void copyLink()}
                  className="inline-flex items-center gap-1.5 rounded-sm border border-[rgba(90,66,34,0.3)] px-3 py-2 text-sm text-ink-soft transition hover:border-amber-ink hover:text-amber-ink"
                >
                  <Copy className="h-3.5 w-3.5" /> Bağlantıyı kopyala
                </button>
                <a
                  href={shareUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 rounded-sm px-2.5 py-2 text-sm text-ink-faint transition hover:text-amber-ink"
                >
                  <ExternalLink className="h-3.5 w-3.5" /> Görüntüle
                </a>
                <button
                  type="button"
                  disabled={pending || save.isPending}
                  onClick={unpublish}
                  className="ml-auto inline-flex items-center gap-1.5 rounded-sm px-2.5 py-2 text-sm text-ink-faint transition hover:bg-[rgba(156,59,35,0.1)] hover:text-destructive disabled:opacity-50"
                >
                  <EyeOff className="h-3.5 w-3.5" /> Gizle
                </button>
              </>
            )}
          </div>
        </>
      )}
    </section>
  );
}
