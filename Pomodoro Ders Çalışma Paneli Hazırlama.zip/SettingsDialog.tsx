import { Minus, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { LIMITS, type Settings } from "@/lib/pomodoro/types";
import { cn } from "@/lib/utils";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  settings: Settings;
  onChange: (patch: Partial<Settings>) => void;
  permission: NotificationPermission;
  onEnableNotifications: () => void;
  onClearData: () => void;
}

interface NumberFieldProps {
  label: string;
  hint?: string;
  value: number;
  min: number;
  max: number;
  unit: string;
  onChange: (value: number) => void;
}

function NumberField({ label, hint, value, min, max, unit, onChange }: NumberFieldProps) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5">
      <div className="min-w-0">
        <p className="text-[0.95rem] leading-tight font-semibold text-ink">{label}</p>
        {hint && <p className="mt-0.5 text-[0.78rem] leading-snug text-ink-faint">{hint}</p>}
      </div>
      <div className="flex shrink-0 items-center gap-1 rounded-sm border border-[rgba(90,66,34,0.28)] bg-[rgba(255,251,241,0.9)] p-1">
        <button
          type="button"
          aria-label={`${label} azalt`}
          disabled={value <= min}
          onClick={() => onChange(value - 1)}
          className="grid h-7 w-7 place-items-center rounded-sm text-ink-soft transition hover:bg-[rgba(160,138,104,0.18)] disabled:opacity-35"
        >
          <Minus className="h-3.5 w-3.5" />
        </button>
        <span className="min-w-[4.2rem] text-center font-display text-sm font-bold text-ink tabular-nums">
          {value} {unit}
        </span>
        <button
          type="button"
          aria-label={`${label} artır`}
          disabled={value >= max}
          onClick={() => onChange(value + 1)}
          className="grid h-7 w-7 place-items-center rounded-sm text-ink-soft transition hover:bg-[rgba(160,138,104,0.18)] disabled:opacity-35"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

function SwitchRow({
  label,
  hint,
  checked,
  disabled,
  onCheckedChange,
}: {
  label: string;
  hint?: string;
  checked: boolean;
  disabled?: boolean;
  onCheckedChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5">
      <div className="min-w-0">
        <p className="text-[0.95rem] leading-tight font-semibold text-ink">{label}</p>
        {hint && <p className="mt-0.5 text-[0.78rem] leading-snug text-ink-faint">{hint}</p>}
      </div>
      <Switch
        checked={checked}
        disabled={disabled}
        onCheckedChange={onCheckedChange}
        className={cn(
          "shrink-0 border-[rgba(90,66,34,0.3)] data-[state=checked]:bg-amber-ink data-[state=unchecked]:bg-[#E9D7B3]",
        )}
      />
    </div>
  );
}

export default function SettingsDialog({
  open,
  onOpenChange,
  settings,
  onChange,
  permission,
  onEnableNotifications,
  onClearData,
}: SettingsDialogProps) {
  const notifyHint =
    permission === "denied"
      ? "Tarayıcı bildirim izni reddedildi; zil sesi ve sekme başlığı yine çalışır."
      : permission === "granted"
        ? "Tur bitince masaüstüne bildirim düşer."
        : "Açtığında tarayıcı izin ister.";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-y-auto rounded-md border-[rgba(90,66,34,0.35)] bg-[#FDF8EC] text-ink sm:max-w-[26rem]">
        <DialogHeader>
          <DialogTitle className="font-display text-xl tracking-wide text-ink">Saat Ayarları</DialogTitle>
          <DialogDescription className="text-ink-faint">
            Değişiklikler bu tarayıcıda saklanır, hemen uygulanır.
          </DialogDescription>
        </DialogHeader>

        <div className="divide-y divide-[rgba(160,138,104,0.25)]">
          <NumberField
            label="Odak süresi"
            hint="Kesintisiz çalışma turu"
            value={settings.focusMin}
            min={LIMITS.minutes.min}
            max={LIMITS.minutes.max}
            unit="dk"
            onChange={focusMin => onChange({ focusMin })}
          />
          <NumberField
            label="Kısa mola"
            value={settings.shortMin}
            min={LIMITS.minutes.min}
            max={LIMITS.minutes.max}
            unit="dk"
            onChange={shortMin => onChange({ shortMin })}
          />
          <NumberField
            label="Uzun mola"
            value={settings.longMin}
            min={LIMITS.minutes.min}
            max={LIMITS.minutes.max}
            unit="dk"
            onChange={longMin => onChange({ longMin })}
          />
          <NumberField
            label="Uzun moladan önce"
            hint="Kaç odak turundan sonra uzun mola gelsin"
            value={settings.longBreakInterval}
            min={LIMITS.interval.min}
            max={LIMITS.interval.max}
            unit="tur"
            onChange={longBreakInterval => onChange({ longBreakInterval })}
          />
          <NumberField
            label="Günlük hedef"
            hint="İlerleme çubuğu buna göre dolar"
            value={settings.dailyGoal}
            min={LIMITS.goal.min}
            max={LIMITS.goal.max}
            unit="pomodoro"
            onChange={dailyGoal => onChange({ dailyGoal })}
          />

          <SwitchRow
            label="Sonraki aşamaya otomatik geç"
            hint="Tur bitince mola (veya mola bitince odak) kendiliğinden başlar"
            checked={settings.autoStartNext}
            onCheckedChange={autoStartNext => onChange({ autoStartNext })}
          />
          <SwitchRow
            label="Sesli uyarı"
            hint="Aşama sonunda masa saati çanı"
            checked={settings.soundEnabled}
            onCheckedChange={soundEnabled => onChange({ soundEnabled })}
          />
          <SwitchRow
            label="Tarayıcı bildirimi"
            hint={notifyHint}
            checked={settings.notifyEnabled && permission === "granted"}
            disabled={permission === "denied"}
            onCheckedChange={() => onEnableNotifications()}
          />
        </div>

        <div className="mt-2 border-t border-[rgba(160,138,104,0.35)] pt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={onClearData}
            className="w-full border-[rgba(156,59,35,0.45)] text-destructive hover:bg-[rgba(156,59,35,0.08)] hover:text-destructive"
          >
            Görevleri ve kayıtları temizle
          </Button>
          <p className="mt-2 text-[0.72rem] leading-snug text-ink-faint">
            Ayarlar dahil her şey bu cihazdaki tarayıcı hafızasından silinir.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
