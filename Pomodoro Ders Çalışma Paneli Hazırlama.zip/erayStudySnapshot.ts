import {
  publicErayStudySnapshotSchema,
  type PublicErayDailyTask,
  type PublicErayStudySnapshot,
} from "@shared/erayStudyData";
import {
  createEmptyTytData,
  getTytStorageKey,
  parseTytStudyData,
} from "@shared/tyt";
import {
  DEFAULT_SETTINGS,
  DEFAULT_TIMER,
  type SessionRecord,
} from "@/lib/pomodoro/types";
import {
  KEYS,
  loadActiveTaskId,
  loadHistory,
  loadSessions,
  loadStudyEntries,
  loadSettings,
  loadTasks,
  loadTimer,
} from "@/lib/pomodoro/storage";
import {
  getYksSubjectsStorageKey,
  readYksSubjects,
} from "@/lib/yks/subjectsStorage";
import {
  getYksDailyTasksStorageKey,
  readYksDailyTasks,
} from "@/lib/yks/dailyTasksStorage";
import { getIstanbulDayKey } from "@shared/studyTracking";

type LocalErayStudySnapshot = PublicErayStudySnapshot & {
  dailyTasks: PublicErayDailyTask[];
};

const BOOKS_PREFIX = "odak-paneli/yks-books/v1/accounts/";
const PROGRAMS_PREFIX = "odak-paneli/yks-desired-programs/v1/accounts/";
const MAX_EPOCH_MS = 4_102_444_800_000;

function accountKey(prefix: string, accountId: string | number): string {
  return `${prefix}${encodeURIComponent(String(accountId))}`;
}

function readArray(key: string): unknown[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

function buildBooks(
  accountId: string | number
): PublicErayStudySnapshot["books"] {
  return readArray(accountKey(BOOKS_PREFIX, accountId))
    .filter(
      (value): value is Record<string, unknown> =>
        Boolean(value) && typeof value === "object" && !Array.isArray(value)
    )
    .slice(0, 25)
    .flatMap(value => {
      if (typeof value.id !== "string" || typeof value.title !== "string")
        return [];
      const id = value.id.trim().slice(0, 120);
      if (!id) return [];
      const totalPages =
        typeof value.totalPages === "number" &&
        Number.isFinite(value.totalPages)
          ? Math.max(1, Math.min(100_000, Math.floor(value.totalPages)))
          : 1;
      const solvedPages =
        typeof value.solvedPages === "number" &&
        Number.isFinite(value.solvedPages)
          ? Math.max(0, Math.min(totalPages, Math.floor(value.solvedPages)))
          : 0;
      const cover =
        typeof value.cover === "string" &&
        value.cover.startsWith("data:image/jpeg;base64,") &&
        value.cover.length <= 600_000
          ? value.cover
          : null;
      return [
        {
          id,
          title: value.title.trim().slice(0, 100),
          cover,
          totalPages,
          solvedPages,
        },
      ].filter(book => book.title.length > 0);
    });
}

function buildPrograms(
  accountId: string | number
): PublicErayStudySnapshot["programs"] {
  return readArray(accountKey(PROGRAMS_PREFIX, accountId))
    .filter(
      (value): value is Record<string, unknown> =>
        Boolean(value) && typeof value === "object" && !Array.isArray(value)
    )
    .slice(0, 100)
    .flatMap(value => {
      if (
        typeof value.id !== "string" ||
        typeof value.name !== "string" ||
        typeof value.requiredNet !== "number" ||
        !Number.isFinite(value.requiredNet)
      )
        return [];
      const name = value.name.trim().slice(0, 120);
      const id = value.id.trim().slice(0, 120);
      if (!name || !id) return [];
      return [
        {
          id,
          name,
          requiredNet: Math.max(0, Math.min(120, value.requiredNet)),
        },
      ];
    });
}

function validSessions(
  sessions: SessionRecord[]
): PublicErayStudySnapshot["pomodoro"]["sessions"] {
  return sessions.slice(0, 400).flatMap(session => {
    if (
      !session ||
      typeof session.id !== "string" ||
      !["focus", "short", "long"].includes(session.phase)
    )
      return [];
    const id = session.id.trim().slice(0, 120);
    if (!id) return [];
    return [
      {
        id,
        phase: session.phase,
        taskId:
          typeof session.taskId === "string"
            ? session.taskId.slice(0, 120)
            : null,
        taskTitle:
          typeof session.taskTitle === "string"
            ? session.taskTitle.slice(0, 80)
            : "Serbest çalışma",
        startedAt: Number.isFinite(session.startedAt)
          ? Math.max(0, session.startedAt)
          : 0,
        endedAt: Number.isFinite(session.endedAt)
          ? Math.max(0, session.endedAt)
          : 0,
        plannedSec: Number.isFinite(session.plannedSec)
          ? Math.max(0, Math.min(86_400, Math.floor(session.plannedSec)))
          : 0,
        actualSec: Number.isFinite(session.actualSec)
          ? Math.max(0, Math.min(86_400, Math.floor(session.actualSec)))
          : 0,
        completed: Boolean(session.completed),
      },
    ];
  });
}

export function readLocalErayStudySnapshot(
  accountId: string | number
): LocalErayStudySnapshot {
  const settings = loadSettings();
  const tasks = loadTasks()
    .slice(0, 500)
    .flatMap(task => {
      const id =
        typeof task.id === "string" ? task.id.trim().slice(0, 120) : "";
      if (!id) return [];
      return [
        {
          id,
          title: typeof task.title === "string" ? task.title.slice(0, 80) : "",
          estimate: Math.max(
            1,
            Math.min(
              24,
              Math.floor(Number.isFinite(task.estimate) ? task.estimate : 1)
            )
          ),
          done: Boolean(task.done),
          completed: Math.max(
            0,
            Math.min(
              9_999,
              Math.floor(Number.isFinite(task.completed) ? task.completed : 0)
            )
          ),
          createdAt: Number.isSafeInteger(task.createdAt)
            ? Math.max(0, Math.min(MAX_EPOCH_MS, task.createdAt))
            : 0,
        },
      ];
    });
  const rawTimer = loadTimer(settings);
  const safeEpoch = (value: number | null): number | null =>
    value === null || !Number.isSafeInteger(value)
      ? null
      : Math.max(0, Math.min(MAX_EPOCH_MS, value));
  const endAt = safeEpoch(rawTimer.endAt);
  const timer = {
    phase: rawTimer.phase,
    running: Boolean(rawTimer.running && endAt !== null),
    endAt,
    remainingSec: Math.max(
      0,
      Math.min(
        86_400,
        Math.floor(
          Number.isFinite(rawTimer.remainingSec) ? rawTimer.remainingSec : 0
        )
      )
    ),
    startedAt: safeEpoch(rawTimer.startedAt),
    cycle: Math.max(
      0,
      Math.min(
        999,
        Math.floor(Number.isFinite(rawTimer.cycle) ? rawTimer.cycle : 0)
      )
    ),
    studySelection: rawTimer.studySelection,
  };
  const rawSubjects = readYksSubjects(getYksSubjectsStorageKey(accountId));
  const subjects = rawSubjects
    .filter(subject => subject.name.trim())
    .map(subject => ({
      ...subject,
      topics: subject.topics.filter(topic => topic.name.trim()),
    }));
  const tytRaw = localStorage.getItem(getTytStorageKey(accountId));
  const todayKey = getIstanbulDayKey();
  const dailyTasks = readYksDailyTasks(
    getYksDailyTasksStorageKey(accountId)
  ).map(task => ({
    ...task,
    completedOn: task.completedOn === todayKey ? todayKey : null,
  }));

  const snapshot = publicErayStudySnapshotSchema.parse({
    version: 1,
    pomodoro: {
      settings,
      tasks,
      activeTaskId: loadActiveTaskId(tasks),
      timer,
      sessions: validSessions(loadSessions()),
      history: loadHistory(),
      studyEntries: loadStudyEntries(),
    },
    subjects,
    books: buildBooks(accountId),
    programs: buildPrograms(accountId),
    dailyTasks,
    tyt: tytRaw ? parseTytStudyData(tytRaw) : createEmptyTytData(),
  });
  return { ...snapshot, dailyTasks: snapshot.dailyTasks ?? [] };
}

export function hasLocalErayStudyData(
  accountId: string | number,
  snapshot: PublicErayStudySnapshot
): boolean {
  const keys = [
    KEYS.settings,
    KEYS.tasks,
    KEYS.activeTaskId,
    KEYS.timer,
    KEYS.sessions,
    KEYS.history,
    KEYS.studyEntries,
    getYksSubjectsStorageKey(accountId),
    getYksDailyTasksStorageKey(accountId),
    accountKey(BOOKS_PREFIX, accountId),
    accountKey(PROGRAMS_PREFIX, accountId),
    getTytStorageKey(accountId),
  ];
  try {
    return (
      keys.some(key => localStorage.getItem(key) !== null) ||
      snapshot.pomodoro.tasks.length > 0 ||
      snapshot.subjects.length > 0 ||
      (snapshot.dailyTasks?.length ?? 0) > 0 ||
      snapshot.books.length > 0 ||
      snapshot.programs.length > 0 ||
      snapshot.tyt.exams.length > 0
    );
  } catch {
    return false;
  }
}

export function restoreErayStudySnapshot(
  snapshot: PublicErayStudySnapshot,
  accountId: string | number
): void {
  const pomodoro = snapshot.pomodoro;
  const values: Array<[string, unknown]> = [
    [KEYS.settings, pomodoro.settings],
    [KEYS.tasks, pomodoro.tasks],
    [KEYS.activeTaskId, pomodoro.activeTaskId],
    [KEYS.timer, pomodoro.timer],
    [KEYS.sessions, pomodoro.sessions],
    [KEYS.history, pomodoro.history],
    [KEYS.studyEntries, pomodoro.studyEntries],
    [getYksSubjectsStorageKey(accountId), snapshot.subjects],
    [getYksDailyTasksStorageKey(accountId), snapshot.dailyTasks ?? []],
    [accountKey(BOOKS_PREFIX, accountId), snapshot.books],
    [accountKey(PROGRAMS_PREFIX, accountId), snapshot.programs],
    [getTytStorageKey(accountId), snapshot.tyt],
  ];
  for (const [key, value] of values) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Keep rendering the server copy even if this browser has exhausted local storage.
    }
  }
}

export function emptyErayStudySnapshot(): LocalErayStudySnapshot {
  return {
    version: 1,
    pomodoro: {
      settings: DEFAULT_SETTINGS,
      tasks: [],
      activeTaskId: null,
      timer: { ...DEFAULT_TIMER },
      sessions: [],
      history: {},
      studyEntries: [],
    },
    subjects: [],
    books: [],
    programs: [],
    dailyTasks: [],
    tyt: createEmptyTytData(),
  };
}
