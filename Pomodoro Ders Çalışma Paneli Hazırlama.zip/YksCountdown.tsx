import { useEffect, useState } from "react";

// ÖSYM'nin 2027 takviminde YKS'nin ilk oturum günü 19 Haziran 2027 olarak açıklandı.
// Saat belirtilmediğinden sayaç, Türkiye saatiyle o günün başlangıcına sayar.
const YKS_FIRST_DAY = new Date("2027-06-19T00:00:00+03:00").getTime();
const SECOND = 1_000;
const DAY = 24 * 60 * 60 * SECOND;

const units = [
  { key: "days", label: "gün" },
  { key: "hours", label: "saat" },
  { key: "minutes", label: "dakika" },
  { key: "seconds", label: "saniye" },
] as const;

type YksCountdownProps = {
  size?: "compact" | "large";
};

export default function YksCountdown({ size = "compact" }: YksCountdownProps) {
  const [remainingMs, setRemainingMs] = useState(() => Math.max(0, YKS_FIRST_DAY - Date.now()));

  useEffect(() => {
    const update = () => setRemainingMs(Math.max(0, YKS_FIRST_DAY - Date.now()));
    const intervalId = window.setInterval(update, SECOND);
    return () => window.clearInterval(intervalId);
  }, []);

  const totalSeconds = Math.floor(remainingMs / SECOND);
  const values = {
    days: Math.floor(totalSeconds / (DAY / SECOND)),
    hours: Math.floor((totalSeconds % (DAY / SECOND)) / 3600),
    minutes: Math.floor((totalSeconds % 3600) / 60),
    seconds: totalSeconds % 60,
  };
  const large = size === "large";

  return (
    <section className={large ? "w-fit pt-0.5 text-center" : "pt-0.5"} aria-label="YKS 2027 geri sayımı">
      <h1 className={`font-display font-bold leading-tight text-ink ${large ? "text-3xl sm:text-4xl" : "text-lg"}`}>
        YKS 2027'ye kalan
      </h1>
      <p className={`text-ink-faint ${large ? "mt-3 text-sm sm:text-base" : "mt-1 text-xs"}`}>
        İlk oturum günü: <time dateTime="2027-06-19">19 Haziran 2027</time>
      </p>
      <div className={`mt-4 flex justify-center ${large ? "gap-3 sm:gap-4" : "gap-1.5"}`} aria-live="off">
        {units.map(unit => (
          <div
            key={unit.key}
            className={`rounded-sm border border-[rgba(90,66,34,0.22)] bg-[rgba(253,248,236,0.78)] text-center ${large ? "min-w-[4.75rem] px-3 py-3 sm:min-w-[6rem] sm:px-5 sm:py-4" : "min-w-[3.3rem] px-2 py-1.5"}`}
          >
            <span className={`block font-display font-bold tabular-nums leading-none text-amber-ink ${large ? "text-3xl sm:text-4xl" : "text-lg"}`}>
              {String(values[unit.key]).padStart(2, "0")}
            </span>
            <span className={`mt-1 block font-medium text-ink-faint ${large ? "text-xs sm:text-sm" : "text-[0.62rem]"}`}>
              {unit.label}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
