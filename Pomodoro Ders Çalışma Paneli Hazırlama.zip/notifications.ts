export function notificationSupported(): boolean {
  return typeof window !== "undefined" && "Notification" in window;
}

export function currentPermission(): NotificationPermission {
  return notificationSupported() ? Notification.permission : "denied";
}

export async function requestPermission(): Promise<NotificationPermission> {
  if (!notificationSupported()) return "denied";
  try {
    if (Notification.permission === "granted") return "granted";
    return await Notification.requestPermission();
  } catch {
    // Cross-site embedded previews can reject this call outright.
    return Notification.permission;
  }
}

export function showNotification(title: string, body: string): boolean {
  if (!notificationSupported() || Notification.permission !== "granted") return false;
  try {
    const note = new Notification(title, {
      body,
      tag: "odak-paneli",
      lang: "tr",
    });
    note.onclick = () => {
      window.focus();
      note.close();
    };
    return true;
  } catch {
    return false;
  }
}
