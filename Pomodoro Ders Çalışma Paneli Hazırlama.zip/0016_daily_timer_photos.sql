CREATE TABLE `dailyTimerPhotos` (
	`dayKey` date NOT NULL,
	`storageKey` varchar(255) NOT NULL,
	`uploadedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dailyTimerPhotos_dayKey` PRIMARY KEY(`dayKey`)
);
--> statement-breakpoint
ALTER TABLE `dailyTimerPhotos` ADD CONSTRAINT `dailyTimerPhotos_uploadedBy_users_id_fk` FOREIGN KEY (`uploadedBy`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;