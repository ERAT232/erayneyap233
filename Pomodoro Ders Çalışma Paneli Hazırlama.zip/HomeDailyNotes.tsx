import { createPortal } from "react-dom";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { LoaderCircle, NotebookPen, Send, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const MAX_NOTE_LENGTH = 160;
const stickyNoteColors = [
  "rotate-[-1.3deg] border-[#e6d47f] bg-[#fff2b8]",
  "rotate-[1.1deg] border-[#efc1cb] bg-[#ffe7ec]",
  "rotate-[-0.8deg] border-[#b9ddc4] bg-[#e1f4e5]",
  "rotate-[1.4deg] border-[#bfd3ed] bg-[#e6f0ff]",
];

function formatTime(value: Date | string) {
  return new Intl.DateTimeFormat("tr-TR", { hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

export default function HomeDailyNotes() {
  const [draft, setDraft] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const utils = trpc.useUtils();
  const notes = trpc.dailyNotes.list.useQuery(undefined, { refetchInterval: 15_000 });
  const myNote = notes.data?.notes.find(note => note.isMine);
  const todayNotes = notes.data?.notes ?? [];

  useEffect(() => {
    setDraft(myNote?.content ?? "");
  }, [notes.data?.dayKey, myNote?.id, myNote?.content]);

  useEffect(() => {
    if (!isOpen) return;
    const previousOverflow = document.body.style.overflow;
    const focusFrame = window.requestAnimationFrame(() => textareaRef.current?.focus());
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsOpen(false);
        window.requestAnimationFrame(() => triggerRef.current?.focus());
      }
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.cancelAnimationFrame(focusFrame);
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [isOpen]);

  const closeDialog = () => {
    setIsOpen(false);
    window.requestAnimationFrame(() => triggerRef.current?.focus());
  };

  const save = trpc.dailyNotes.save.useMutation({
    onSuccess: async () => {
      await utils.dailyNotes.list.invalidate();
      toast.success(myNote ? "Günlük notun güncellendi." : "Günlük notun eklendi.");
      closeDialog();
    },
    onError: error => toast.error(error.message || "Not kaydedilemedi."),
  });

  const remove = trpc.dailyNotes.remove.useMutation({
    onSuccess: async () => {
      setDraft("");
      await utils.dailyNotes.list.invalidate();
      toast.success("Günlük notun kaldırıldı.");
    },
    onError: error => toast.error(error.message || "Not silinemedi."),
  });

  const openDialog = () => {
    setDraft(myNote?.content ?? "");
    setIsOpen(true);
  };

  const submitNote = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!draft.trim() || save.isPending) return;
    save.mutate({ content: draft });
  };

  return (
    <>
      <div className="mb-3 flex justify-end">
        <button
          ref={triggerRef}
          type="button"
          onClick={openDialog}
          aria-haspopup="dialog"
          aria-expanded={isOpen}
          aria-controls="home-daily-notes-dialog"
          aria-label={`Günlük notları aç. Bugün ${todayNotes.length} not var.`}
          className="group inline-flex h-10 items-center gap-2 rounded-full border border-[#e6d47f] bg-[#fff2b8] px-3.5 text-xs font-semibold text-[#5c4b25] shadow-[0_5px_12px_-8px_rgba(60,40,15,0.7)] transition hover:-translate-y-0.5 hover:rotate-[-1deg] hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-ink active:translate-y-0"
        >
          <NotebookPen className="h-4 w-4 text-amber-ink transition-transform group-hover:-rotate-6" aria-hidden="true" />
          <span>Günlük notlar</span>
          {todayNotes.length > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-white/75 px-1.5 text-[10px] tabular-nums">{todayNotes.length}</span>}
        </button>
      </div>

      {isOpen && typeof document !== "undefined" && createPortal(
        <div
          className="daily-notes-backdrop fixed inset-0 z-[90] grid place-items-center bg-[rgba(28,20,12,0.58)] p-3 backdrop-blur-[3px] sm:p-6"
          onMouseDown={event => {
            if (event.target === event.currentTarget) closeDialog();
          }}
        >
          <section
            id="home-daily-notes-dialog"
            className="daily-notes-dialog note-paper relative flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-md border border-[#d7c69e] px-3 py-4 pl-10 shadow-[0_24px_80px_rgba(20,14,8,0.35)] sm:px-6 sm:py-5 sm:pl-14"
            role="dialog"
            aria-modal="true"
            aria-labelledby="home-daily-notes-title"
            aria-describedby="home-daily-notes-description"
          >
            <header className="mb-3 flex shrink-0 items-start gap-3 border-b border-[rgba(90,66,34,0.15)] pb-3">
              <NotebookPen className="mt-0.5 h-5 w-5 shrink-0 text-amber-ink" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <h2 id="home-daily-notes-title" className="font-display text-lg font-semibold text-ink">Bugünün Notları</h2>
                <p id="home-daily-notes-description" className="mt-0.5 text-xs leading-5 text-ink-faint">Herkes günde bir kısa not ekleyebilir. Notlar Türkiye saatiyle 00.00’da yenilenir.</p>
              </div>
              {notes.data?.dayKey && <time className="shrink-0 pt-1 text-xs text-ink-faint">{notes.data.dayKey}</time>}
              <button
                type="button"
                onClick={closeDialog}
                aria-label="Günlük notları kapat"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-[rgba(90,66,34,0.2)] bg-white/60 text-ink-faint transition hover:bg-white hover:text-ink focus-visible:outline-2 focus-visible:outline-amber-ink"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </header>

            <div className="min-h-0 flex-1 overflow-y-auto pr-1">
              {notes.isLoading ? (
                <div className="mb-3 flex min-h-14 items-center justify-center text-sm text-ink-faint" role="status">Bugünün notları yükleniyor…</div>
              ) : notes.isError ? (
                <p className="mb-3 rounded-sm border border-destructive/30 bg-red-50/70 px-3 py-2 text-sm text-destructive" role="alert">Bugünün notları yüklenemedi.</p>
              ) : todayNotes.length === 0 ? (
                <p className="mb-3 rounded-sm border border-dashed border-[rgba(90,66,34,0.22)] bg-white/45 px-3 py-3 text-sm text-ink-faint">Kâğıt bugün bomboş. İlk tatlı notu sen bırak.</p>
              ) : (
                <ul className="mb-4 grid max-h-64 gap-3 overflow-y-auto px-1 py-2 sm:grid-cols-2 lg:grid-cols-3" aria-label="Bugün eklenen notlar">
                  {todayNotes.map(note => (
                    <li key={note.id} className={`sticky-note-card relative min-w-0 rounded-[3px] border px-3 pb-2 pt-4 shadow-md ${stickyNoteColors[note.id % stickyNoteColors.length]}`}>
                      <span className="sticky-note-tape absolute left-1/2 top-0 h-3 w-12 -translate-x-1/2 -translate-y-1/2 rotate-[-2deg]" aria-hidden="true" />
                      <p className="break-words whitespace-pre-wrap font-display text-[0.98rem] leading-5 text-ink">{note.content}</p>
                      <div className="mt-3 flex items-center justify-between gap-2 text-[11px] text-ink-faint">
                        <span className="truncate font-semibold">{note.authorUsername ?? "Üye"}{note.isMine ? " · sen" : ""}</span>
                        <time dateTime={new Date(note.updatedAt).toISOString()}>{formatTime(note.updatedAt)}</time>
                      </div>
                    </li>
                  ))}
                </ul>
              )}

              <form className="sticky-note-card relative rounded-[3px] border border-[#e6d47f] bg-[#fff7d2] p-3 pt-4 shadow-md" onSubmit={submitNote}>
                <span className="sticky-note-tape absolute left-1/2 top-0 h-3 w-14 -translate-x-1/2 -translate-y-1/2 rotate-[2deg]" aria-hidden="true" />
                <label className="block">
                  <span className="sr-only">Bugün için kısa notun</span>
                  <textarea
                    ref={textareaRef}
                    value={draft}
                    onChange={event => setDraft(event.target.value.slice(0, MAX_NOTE_LENGTH))}
                    maxLength={MAX_NOTE_LENGTH}
                    rows={2}
                    placeholder="Küçük bir not bırak…"
                    className="w-full resize-y border-0 border-b border-dashed border-[#c8b66f] bg-transparent px-1 py-1 font-display text-sm text-ink placeholder:text-ink-faint focus-visible:outline-2 focus-visible:outline-amber-ink"
                  />
                </label>
                <div className="mt-2 flex items-center justify-between gap-2">
                  <span className="text-xs text-ink-faint" aria-live="polite">{draft.length}/{MAX_NOTE_LENGTH}</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      disabled={save.isPending || remove.isPending || !draft.trim()}
                      className="inline-flex h-8 items-center gap-1.5 rounded-sm bg-amber-ink px-3 text-xs font-semibold text-[#fffaf0] transition hover:bg-[#914206] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {save.isPending ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" aria-hidden="true" />}
                      {save.isPending ? "Kaydediliyor…" : myNote ? "Notu güncelle" : "Not ekle"}
                    </button>
                    {myNote && (
                      <button
                        type="button"
                        onClick={() => remove.mutate({ id: myNote.id })}
                        disabled={save.isPending || remove.isPending}
                        aria-label="Kendi günlük notunu sil"
                        title="Notunu sil"
                        className="grid h-8 w-8 place-items-center rounded-sm border border-[rgba(145,31,23,0.3)] text-destructive transition hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        {remove.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" aria-hidden="true" />}
                      </button>
                    )}
                  </div>
                </div>
              </form>
              <p className="mt-2 text-right text-[11px] text-ink-faint">Yalnızca kendi notunu değiştirebilir veya kaldırabilirsin.</p>
            </div>
          </section>
        </div>,
        document.body,
      )}
    </>
  );
}
