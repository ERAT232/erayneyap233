import { useMemo, useState, type FormEvent } from "react";
import { Flame, Pencil, Save, Target, Timer, Trash2, X } from "lucide-react";
import { formatMinutes, formatTime } from "@/lib/pomodoro/format";
import type { DayBar, TodayStats, WeekBar } from "@/hooks/usePomodoro";
import { PHASE_META, type SessionRecord } from "@/lib/pomodoro/types";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { getIstanbulDayKey, type StudyEntry } from "@shared/studyTracking";

interface StatsCardProps {
  stats: TodayStats;
  week: DayBar[];
  weeks: WeekBar[];
  studyEntries: StudyEntry[];
  focusSessions: SessionRecord[];
  canEditStudyEntries: boolean;
  onUpdateStudyEntry: (id: string, patch: Partial<StudyEntry>) => void;
  onDeleteStudyEntry: (id: string) => void;
  onUpdateFocusSession: (id: string, actualSec: number) => void;
  onDeleteFocusSession: (id: string) => void;
}

function linkedStudyEntry(session: SessionRecord, entries: StudyEntry[]) {
  return entries.find(entry => entry.source === "pomodoro" && entry.sessionId === session.id)
    ?? entries.find(entry => entry.source === "pomodoro" && !entry.sessionId && entry.endedAt === session.endedAt);
}

export default function StatsCard({ stats, week, weeks, studyEntries, focusSessions, canEditStudyEntries, onUpdateStudyEntry, onDeleteStudyEntry, onUpdateFocusSession, onDeleteFocusSession }: StatsCardProps) {
  const [editing, setEditing] = useState<{ kind: "entry" | "session"; id: string; minutes: string } | null>(null);
  const todayKey = getIstanbulDayKey();
  const todayEntries = useMemo(
    () => studyEntries.filter(entry => entry.dayKey === todayKey).sort((a, b) => b.endedAt - a.endedAt),
    [studyEntries, todayKey],
  );
  const todaySessions = useMemo(
    () => focusSessions.filter(session => getIstanbulDayKey(session.endedAt) === todayKey),
    [focusSessions, todayKey],
  );
  const linkedEntryIds = new Set(todaySessions.map(session => linkedStudyEntry(session, todayEntries)?.id).filter((id): id is string => Boolean(id)));
  const otherEntries = todayEntries.filter(entry => !linkedEntryIds.has(entry.id));
  const recordCount = todaySessions.length + otherEntries.length;
  const peak = Math.max(1, ...week.map(d => d.focusSeconds));
  const weeklyPeak = Math.max(1, ...weeks.map(d => d.focusSeconds));

  const saveDuration = (event: FormEvent<HTMLFormElement>, entry: StudyEntry) => {
    event.preventDefault();
    if (!editing || editing.kind !== "entry" || editing.id !== entry.id) return;
    const minutes = Number(editing.minutes);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      toast.error("Süre 1 ile 1.440 dakika arasında tam sayı olmalı.");
      return;
    }
    const seconds = minutes * 60;
    onUpdateStudyEntry(entry.id, { seconds, startedAt: entry.endedAt - seconds * 1000 });
    setEditing(null);
    toast.success(entry.source === "pomodoro" ? "Pomodoro süresi güncellendi; toplam odak yenilendi." : "Manuel çalışma kaydı güncellendi.");
  };

  const saveSessionDuration = (event: FormEvent<HTMLFormElement>, session: SessionRecord) => {
    event.preventDefault();
    if (!editing || editing.kind !== "session" || editing.id !== session.id) return;
    const minutes = Number(editing.minutes);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      toast.error("Süre 1 ile 1.440 dakika arasında tam sayı olmalı.");
      return;
    }
    onUpdateFocusSession(session.id, minutes * 60);
    setEditing(null);
    toast.success("Odak süresi ve günlük toplam güncellendi.");
  };

  const removeSession = (session: SessionRecord) => {
    const impact = session.completed ? "Günlük odak ve tamamlanan tur sayısı güncellenecek." : "Günlük odak süresi güncellenecek.";
    if (!window.confirm(`Bu odak oturumunu ve varsa bağlı ders kaydını silmek istiyor musun? ${impact}`)) return;
    onDeleteFocusSession(session.id);
    if (editing?.id === session.id) setEditing(null);
    toast.success("Odak kaydı silindi; günlük toplam güncellendi.");
  };

  const removeEntry = (entry: StudyEntry) => {
    if (!window.confirm("Bu çalışma kaydını silmek istiyor musun? Pomodoro kaydıysa günlük odak toplamı da güncellenecek.")) return;
    onDeleteStudyEntry(entry.id);
    if (editing?.id === entry.id) setEditing(null);
    toast.success("Çalışma kaydı silindi.");
  };

  return (
    <section className="plate rounded-md px-5 py-4">
      <header className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-lg font-bold text-ink">Bugünün Kaydı</h2>
        {stats.streak > 1 && (
          <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(180,83,9,0.12)] px-2 py-0.5 text-[0.68rem] font-semibold text-amber-ink">
            <Flame className="h-3 w-3" />
            {stats.streak} gün seri
          </span>
        )}
      </header>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <div className="rounded-sm border border-[rgba(90,66,34,0.2)] bg-[rgba(255,251,241,0.75)] px-3 py-2.5">
          <div className="smallcaps flex items-center gap-1.5">
            <Timer className="h-3 w-3" /> Tamamlanan
          </div>
          <p className="mt-1 font-display text-3xl leading-none font-bold text-ink">
            {stats.pomodoros}
            <span className="ml-1 text-sm font-normal text-ink-faint">/ {stats.goal}</span>
          </p>
        </div>
        <div className="rounded-sm border border-[rgba(90,66,34,0.2)] bg-[rgba(255,251,241,0.75)] px-3 py-2.5">
          <div className="smallcaps flex items-center gap-1.5">
            <Target className="h-3 w-3" /> Odak
          </div>
          <p className="mt-1 font-display text-3xl leading-none font-bold text-ink">
            {formatMinutes(stats.focusSeconds)}
          </p>
        </div>
      </div>

      <div className="mt-4 rounded-sm border border-[rgba(90,66,34,0.16)] bg-[rgba(255,251,241,0.52)] p-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="smallcaps">Bugünün odak kayıtları</h3>
          <span className="text-[0.65rem] text-ink-faint">{recordCount} kayıt</span>
        </div>
        <p className="mt-1 text-[0.65rem] text-ink-faint">Pomodoro süresini düzelt veya sil; odak toplamı güncellenir. Manuel kayıtlar ders dökümünü etkiler.</p>
        {recordCount ? (
          <ul className="mt-2 max-h-72 space-y-2 overflow-y-auto pr-1">
            {todaySessions.map(session => {
              const entry = linkedStudyEntry(session, todayEntries);
              const isEditing = editing?.kind === "session" && editing.id === session.id;
              return (
                <li key={`session-${session.id}`} className="rounded-sm border border-[rgba(90,66,34,0.12)] bg-white/70 px-2.5 py-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-xs font-semibold text-ink">{entry ? `${entry.subjectName} · ${entry.topicName}` : session.taskTitle}</p>
                      <span className="text-[0.62rem] text-ink-faint">Pomodoro · {formatTime(session.endedAt)} · {session.completed ? "tamamlandı" : "yarıda"}</span>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <span className="font-display text-sm font-bold tabular-nums text-ink">{formatMinutes(session.actualSec)}</span>
                      {canEditStudyEntries && !isEditing && (
                        <button type="button" onClick={() => setEditing({ kind: "session", id: session.id, minutes: String(Math.max(1, Math.round(session.actualSec / 60))) })} aria-label={`${session.taskTitle} odak süresini düzenle`} className="grid h-7 w-7 place-items-center rounded-sm border border-[rgba(90,66,34,0.16)] text-ink-soft transition hover:text-amber-ink">
                          <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      )}
                      {canEditStudyEntries && (
                        <button type="button" onClick={() => removeSession(session)} aria-label={`${session.taskTitle} odak kaydını sil`} className="grid h-7 w-7 place-items-center rounded-sm border border-[#ead8d3] text-[#9b5147] transition hover:bg-[#fff1ed]">
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>
                  {isEditing && editing && canEditStudyEntries && (
                    <form onSubmit={event => saveSessionDuration(event, session)} className="mt-2 flex items-end gap-2">
                      <div className="min-w-0 flex-1">
                        <label htmlFor={`today-session-minutes-${session.id}`} className="mb-1 block text-[0.62rem] font-semibold text-ink-soft">Süre (dakika)</label>
                        <input id={`today-session-minutes-${session.id}`} type="number" min={1} max={1440} step={1} value={editing.minutes} onChange={event => setEditing(current => current?.kind === "session" && current.id === session.id ? { ...current, minutes: event.target.value } : current)} className="h-8 w-full rounded-sm border border-[rgba(90,66,34,0.25)] bg-white px-2 text-sm text-ink" />
                      </div>
                      <button type="submit" aria-label="Odak süresini kaydet" className="grid h-8 w-8 place-items-center rounded-sm bg-sage-ink text-white transition hover:brightness-110"><Save className="h-4 w-4" aria-hidden="true" /></button>
                      <button type="button" onClick={() => setEditing(null)} aria-label="Düzenlemeyi iptal et" className="grid h-8 w-8 place-items-center rounded-sm border border-[rgba(90,66,34,0.2)] text-ink-soft transition hover:text-amber-ink"><X className="h-4 w-4" aria-hidden="true" /></button>
                    </form>
                  )}
                </li>
              );
            })}
            {otherEntries.map(entry => {
              const isEditing = editing?.kind === "entry" && editing.id === entry.id;
              return (
                <li key={`entry-${entry.id}`} className="rounded-sm border border-[rgba(90,66,34,0.12)] bg-white/70 px-2.5 py-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-xs font-semibold text-ink">{entry.subjectName} · {entry.topicName}</p>
                      <span className="text-[0.62rem] text-ink-faint">{entry.source === "pomodoro" ? "Pomodoro çalışma kaydı" : "Manuel çalışma"} · {formatTime(entry.endedAt)}</span>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <span className="font-display text-sm font-bold tabular-nums text-ink">{formatMinutes(entry.seconds)}</span>
                      {canEditStudyEntries && !isEditing && (
                        <button type="button" onClick={() => setEditing({ kind: "entry", id: entry.id, minutes: String(Math.max(1, Math.round(entry.seconds / 60))) })} aria-label={`${entry.subjectName} · ${entry.topicName} süresini düzenle`} className="grid h-7 w-7 place-items-center rounded-sm border border-[rgba(90,66,34,0.16)] text-ink-soft transition hover:text-amber-ink"><Pencil className="h-3.5 w-3.5" aria-hidden="true" /></button>
                      )}
                      {canEditStudyEntries && (
                        <button type="button" onClick={() => removeEntry(entry)} aria-label={`${entry.subjectName} çalışma kaydını sil`} className="grid h-7 w-7 place-items-center rounded-sm border border-[#ead8d3] text-[#9b5147] transition hover:bg-[#fff1ed]"><Trash2 className="h-3.5 w-3.5" aria-hidden="true" /></button>
                      )}
                    </div>
                  </div>
                  {isEditing && editing && canEditStudyEntries && (
                    <form onSubmit={event => saveDuration(event, entry)} className="mt-2 flex items-end gap-2">
                      <div className="min-w-0 flex-1">
                        <label htmlFor={`today-study-minutes-${entry.id}`} className="mb-1 block text-[0.62rem] font-semibold text-ink-soft">Süre (dakika)</label>
                        <input id={`today-study-minutes-${entry.id}`} type="number" min={1} max={1440} step={1} value={editing.minutes} onChange={event => setEditing(current => current?.kind === "entry" && current.id === entry.id ? { ...current, minutes: event.target.value } : current)} className="h-8 w-full rounded-sm border border-[rgba(90,66,34,0.25)] bg-white px-2 text-sm text-ink" />
                      </div>
                      <button type="submit" aria-label="Süreyi kaydet" className="grid h-8 w-8 place-items-center rounded-sm bg-sage-ink text-white transition hover:brightness-110"><Save className="h-4 w-4" aria-hidden="true" /></button>
                      <button type="button" onClick={() => setEditing(null)} aria-label="Düzenlemeyi iptal et" className="grid h-8 w-8 place-items-center rounded-sm border border-[rgba(90,66,34,0.2)] text-ink-soft transition hover:text-amber-ink"><X className="h-4 w-4" aria-hidden="true" /></button>
                    </form>
                  )}
                </li>
              );
            })}
          </ul>
        ) : (
          <p className="mt-2 text-xs text-ink-faint">Bugün için odak veya çalışma kaydı yok.</p>
        )}
      </div>

      <div className="mt-3.5">
        <div className="flex items-center justify-between text-[0.66rem] font-semibold tracking-[0.12em] text-ink-faint uppercase">
          <span>Günlük hedef</span>
          <span>{Math.round(stats.ratio * 100)}%</span>
        </div>
        <div className="mt-1.5 h-2.5 overflow-hidden rounded-full border border-[rgba(90,66,34,0.24)] bg-[rgba(233,215,179,0.7)]">
          <div
            className="h-full rounded-full transition-[width] duration-700 ease-out"
            style={{
              width: `${Math.max(stats.ratio * 100, stats.pomodoros > 0 ? 6 : 0)}%`,
              backgroundColor: stats.ratio >= 1 ? PHASE_META.short.accent : PHASE_META.focus.accent,
            }}
          />
        </div>
      </div>

      <div className="mt-4">
        <div className="flex items-baseline justify-between gap-2">
          <span className="smallcaps">Günlük odak süresi · son 7 gün</span>
          <span className="text-[0.62rem] text-ink-faint">dakika</span>
        </div>
        <div
          role="img"
          aria-label={`Son 7 günün günlük performansı: ${week.map(day => `${day.label} ${formatMinutes(day.focusSeconds)}, ${day.pomodoros} pomodoro`).join(", ")}`}
          className="mt-2 flex h-20 items-end gap-1.5"
        >
          {week.map(day => (
            <div key={day.key} className="flex min-w-0 flex-1 flex-col items-center gap-1.5" aria-label={`${day.label}: ${formatMinutes(day.focusSeconds)} odak`}>
              <span className="h-3 text-[0.58rem] leading-3 tabular-nums text-ink-soft" title={formatMinutes(day.focusSeconds)}>
                {Math.round(day.focusSeconds / 60)}
              </span>
              <div className="flex h-14 w-full items-end">
                <div
                  title={`${formatMinutes(day.focusSeconds)} · ${day.pomodoros} pomodoro`}
                  className={cn(
                    "w-full rounded-t-[2px] border-x border-t transition-all duration-500",
                    day.isToday ? "border-[rgba(90,66,34,0.45)]" : "border-transparent",
                  )}
                  style={{
                    height: `${Math.max(day.focusSeconds > 0 ? 8 : 2, (day.focusSeconds / peak) * 100)}%`,
                    backgroundColor: day.isToday
                      ? PHASE_META.focus.accent
                      : day.focusSeconds > 0
                        ? "rgba(180,83,9,0.34)"
                        : "rgba(160,138,104,0.18)",
                  }}
                />
              </div>
              <span
                className={cn(
                  "text-[0.62rem] tracking-wide",
                  day.isToday ? "font-bold text-ink" : "text-ink-faint",
                )}
              >
                {day.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 border-t border-[rgba(90,66,34,0.16)] pt-3">
        <div className="flex items-baseline justify-between gap-2">
          <span className="smallcaps">Haftalık odak süresi · son 4 hafta</span>
          <span className="text-[0.62rem] text-ink-faint">saat</span>
        </div>
        <div
          role="img"
          aria-label={`Son 4 haftanın haftalık odak süresi: ${weeks.map(item => `${item.label} ${formatMinutes(item.focusSeconds)}, ${item.pomodoros} pomodoro`).join(", ")}`}
          className="mt-2 flex h-24 items-end gap-2"
        >
          {weeks.map(item => (
            <div key={item.key} className="flex min-w-0 flex-1 flex-col items-center gap-1.5">
              <span className="h-3 text-[0.58rem] leading-3 tabular-nums text-ink-soft" title={`${formatMinutes(item.focusSeconds)} · ${item.pomodoros} pomodoro`}>
                {item.focusSeconds > 0 ? (item.focusSeconds / 3600).toFixed(1) : "0"}
              </span>
              <div className="flex h-14 w-full items-end">
                <div
                  title={`${formatMinutes(item.focusSeconds)} · ${item.pomodoros} pomodoro`}
                  className={cn(
                    "w-full rounded-t-[2px] border-x border-t transition-all duration-500",
                    item.isCurrentWeek ? "border-[rgba(90,66,34,0.45)]" : "border-transparent",
                  )}
                  style={{
                    height: `${Math.max(item.focusSeconds > 0 ? 8 : 2, (item.focusSeconds / weeklyPeak) * 100)}%`,
                    backgroundColor: item.isCurrentWeek
                      ? PHASE_META.focus.accent
                      : item.focusSeconds > 0
                        ? "rgba(91,122,84,0.42)"
                        : "rgba(160,138,104,0.18)",
                  }}
                />
              </div>
              <span className={cn("text-center text-[0.56rem] leading-tight tabular-nums", item.isCurrentWeek ? "font-bold text-ink" : "text-ink-faint")}>
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
