const JPEG_DATA_URL_PREFIX = "data:image/jpeg;base64,";
const MAX_CHAT_IMAGE_BYTES = 3 * 1024 * 1024;
const MAX_CHAT_IMAGE_EDGE = 1600;
const MAX_DATA_URL_LENGTH = JPEG_DATA_URL_PREFIX.length + 4 * Math.ceil(MAX_CHAT_IMAGE_BYTES / 3);

const SOF_MARKERS = new Set([
  0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7,
  0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf,
]);
const STANDALONE_MARKERS = new Set([0xd8, 0x01, 0xd0, 0xd1, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7]);

function jpegDimensions(bytes: Buffer): { width: number; height: number } | null {
  if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) return null;
  let offset = 2;

  while (offset < bytes.length) {
    if (bytes[offset] !== 0xff) return null;
    while (offset < bytes.length && bytes[offset] === 0xff) offset += 1;
    if (offset >= bytes.length) return null;

    const marker = bytes[offset]!;
    offset += 1;
    if (marker === 0xd9 || marker === 0xda || marker === 0x00) return null;
    if (STANDALONE_MARKERS.has(marker)) continue;
    if (offset + 2 > bytes.length) return null;

    const segmentLength = bytes.readUInt16BE(offset);
    if (segmentLength < 2 || offset + segmentLength > bytes.length) return null;
    if (SOF_MARKERS.has(marker)) {
      if (segmentLength < 11) return null;
      const height = bytes.readUInt16BE(offset + 3);
      const width = bytes.readUInt16BE(offset + 5);
      const components = bytes[offset + 7]!;
      if (width < 1 || height < 1 || components < 1 || components > 4 || segmentLength < 8 + components * 3) return null;
      return { width, height };
    }
    offset += segmentLength;
  }
  return null;
}

/** Validate the actual decoded size and pixel dimensions, not only client-side compression claims. */
export function isValidChatImageData(dataUrl: string): boolean {
  if (dataUrl.length > MAX_DATA_URL_LENGTH || !dataUrl.startsWith(JPEG_DATA_URL_PREFIX)) return false;
  const base64 = dataUrl.slice(JPEG_DATA_URL_PREFIX.length);
  if (!base64 || base64.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(base64)) return false;

  const bytes = Buffer.from(base64, "base64");
  if (bytes.length < 4 || bytes.length > MAX_CHAT_IMAGE_BYTES || bytes.toString("base64") !== base64) return false;
  const dimensions = jpegDimensions(bytes);
  return Boolean(dimensions && dimensions.width <= MAX_CHAT_IMAGE_EDGE && dimensions.height <= MAX_CHAT_IMAGE_EDGE);
}
