import { describe, expect, it } from "vitest";
import { getIstanbulDayKey } from "./dailyNoteDay";

describe("Istanbul-local daily note day key", () => {
  it("keeps the current date before midnight in Istanbul and advances at midnight", () => {
    expect(getIstanbulDayKey(new Date("2026-11-14T20:59:59.000Z"))).toBe("2026-11-14");
    expect(getIstanbulDayKey(new Date("2026-11-14T21:00:00.000Z"))).toBe("2026-11-15");
  });
});
