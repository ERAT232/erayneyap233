import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";
import type { User } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const dbMocks = vi.hoisted(() => ({
  getChatIdentity: vi.fn(),
  listDirectConversations: vi.fn(),
  startDirectConversation: vi.fn(),
  getDirectConversation: vi.fn(),
  hideDirectConversation: vi.fn(),
  getDirectMessageImage: vi.fn(),
  markDirectConversationEntered: vi.fn(),
  markDirectConversationRead: vi.fn(),
  deleteDirectMessage: vi.fn(),
  updateMemberChatProfilePhoto: vi.fn(),
  sendDirectMessage: vi.fn(),
  bumpSlidingRateLimitBucket: vi.fn(),
}));

vi.mock("./db", () => dbMocks);

import * as db from "./db";
import { appRouter } from "./routers";

let serial = 300;
function makeUser(username: string): User {
  serial += 1;
  const now = new Date();
  return {
    id: serial,
    openId: `local_chat_account_${serial}`,
    chatUserId: `chat_${serial}_unique`,
    username,
    passwordHash: "scrypt$test",
    name: username,
    email: null,
    loginMethod: "password",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
    chatPhotoData: null,
    lastChatSeenAt: null,
    chatLastReadMessageId: null,
  };
}

function makeContext(user: User | null): TrpcContext {
  const ip = `198.51.100.${(serial % 200) + 1}`;
  const req = {
    protocol: "https",
    method: "POST",
    originalUrl: "/api/trpc/chat",
    ip,
    socket: { remoteAddress: ip },
    headers: {},
  } as unknown as TrpcContext["req"];
  const res = { cookie: vi.fn(), clearCookie: vi.fn() } as unknown as TrpcContext["res"];
  return { req, res, user };
}

const bucketCounts = new Map<string, number>();
const validJpegDataUrl = `data:image/jpeg;base64,${Buffer.from([
  0xff, 0xd8, 0xff, 0xc0, 0x00, 0x0b, 0x08,
  0x00, 0x01, 0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xff, 0xd9,
]).toString("base64")}`;
beforeEach(() => {
  vi.clearAllMocks();
  bucketCounts.clear();
  vi.stubEnv("MANUS_JWT_SECRET", "test-rate-limit-secret-long-enough-0123456789");
  vi.mocked(db.bumpSlidingRateLimitBucket).mockImplementation(async input => {
    const count = (bucketCounts.get(input.bucketPrefix) ?? 0) + 1;
    bucketCounts.set(input.bucketPrefix, count);
    return { count, resetAt: new Date((input.now ?? new Date()).getTime() + input.windowMs) };
  });
});
afterEach(() => vi.unstubAllEnvs());

describe("private member chat", () => {
  it("returns the signed-in member's unique shareable chat ID", async () => {
    const user = makeUser("eray");
    const identity = { id: user.id, chatUserId: user.chatUserId, username: user.username, profilePhoto: null };
    vi.mocked(db.getChatIdentity).mockResolvedValue(identity);
    await expect(appRouter.createCaller(makeContext(user)).chat.identity()).resolves.toEqual(identity);
  });

  it("lists only conversations returned for the authenticated member", async () => {
    const user = makeUser("member");
    const data = [{ id: 19, peer: { chatUserId: "peer_123456", username: "peer", profilePhoto: null }, peerLastReadMessageId: 8, peerLastSeenAt: null, lastMessage: null }];
    vi.mocked(db.listDirectConversations).mockResolvedValue(data);
    await expect(appRouter.createCaller(makeContext(user)).chat.list()).resolves.toEqual(data);
    expect(db.listDirectConversations).toHaveBeenCalledWith(user.id);
  });

  it("starts a direct conversation by user chat ID", async () => {
    const user = makeUser("member");
    const conversation = { id: 23, peer: { id: 99, chatUserId: "peer_123456", username: "peer", profilePhoto: null } };
    vi.mocked(db.startDirectConversation).mockResolvedValue(conversation);
    await expect(appRouter.createCaller(makeContext(user)).chat.start({ chatUserId: "peer_123456" })).resolves.toEqual(conversation);
    expect(db.startDirectConversation).toHaveBeenCalledWith(user.id, "peer_123456");
  });

  it("rejects unknown or self chat IDs and malformed identifiers", async () => {
    const user = makeUser("member");
    vi.mocked(db.startDirectConversation).mockResolvedValue(null);
    const caller = appRouter.createCaller(makeContext(user));
    await expect(caller.chat.start({ chatUserId: user.chatUserId })).rejects.toMatchObject({ code: "NOT_FOUND" });
    await expect(caller.chat.start({ chatUserId: "invalid" })).rejects.toBeInstanceOf(TRPCError);
  });

  it("requires a signed-in member for private chat endpoints", async () => {
    const caller = appRouter.createCaller(makeContext(null));
    await expect(caller.chat.identity()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.chat.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.chat.start({ chatUserId: "peer_123456" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("hides only the caller's view through the authenticated mutation", async () => {
    const user = makeUser("member");
    const caller = appRouter.createCaller(makeContext(user));
    vi.mocked(db.hideDirectConversation).mockResolvedValue(true);
    await expect(caller.chat.hide({ conversationId: 17 })).resolves.toEqual({ success: true });
    expect(db.hideDirectConversation).toHaveBeenCalledWith(user.id, 17);
    vi.mocked(db.hideDirectConversation).mockResolvedValue(false);
    await expect(caller.chat.hide({ conversationId: 18 })).rejects.toMatchObject({ code: "NOT_FOUND" });
    await expect(appRouter.createCaller(makeContext(null)).chat.hide({ conversationId: 17 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("opens only a conversation returned by the membership-scoped DB lookup", async () => {
    const user = makeUser("member");
    const data = { id: 4, me: { id: user.id, chatUserId: user.chatUserId, username: "member", profilePhoto: null }, peer: { id: 8, chatUserId: "peer_123456", username: "peer", profilePhoto: null, lastReadMessageId: 3, lastSeenAt: null }, messages: [] };
    vi.mocked(db.getDirectConversation).mockResolvedValue(data);
    await expect(appRouter.createCaller(makeContext(user)).chat.open({ conversationId: 4 })).resolves.toEqual(data);
    expect(db.getDirectConversation).toHaveBeenCalledWith(user.id, 4);
  });

  it("does not reveal a conversation the DB membership check rejects", async () => {
    vi.mocked(db.getDirectConversation).mockResolvedValue(null);
    await expect(appRouter.createCaller(makeContext(makeUser("outsider"))).chat.open({ conversationId: 404 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("loads image bytes only through the participant-scoped image endpoint", async () => {
    const user = makeUser("member");
    const imageData = validJpegDataUrl;
    vi.mocked(db.getDirectMessageImage).mockResolvedValue(imageData);
    const caller = appRouter.createCaller(makeContext(user));
    await expect(caller.chat.image({ conversationId: 4, messageId: 12 })).resolves.toEqual({ imageData });
    expect(db.getDirectMessageImage).toHaveBeenCalledWith(user.id, 4, 12);
    vi.mocked(db.getDirectMessageImage).mockResolvedValue(null);
    await expect(caller.chat.image({ conversationId: 4, messageId: 12 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("soft-deletes only messages the caller owns", async () => {
    const user = makeUser("member");
    vi.mocked(db.deleteDirectMessage).mockResolvedValue(true);
    const caller = appRouter.createCaller(makeContext(user));
    await expect(caller.chat.deleteMessage({ conversationId: 4, messageId: 12 })).resolves.toEqual({ success: true });
    expect(db.deleteDirectMessage).toHaveBeenCalledWith(user.id, 4, 12);
    vi.mocked(db.deleteDirectMessage).mockResolvedValue(false);
    await expect(caller.chat.deleteMessage({ conversationId: 4, messageId: 13 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("updates last seen and read markers only through explicit authorized conversation mutations", async () => {
    const user = makeUser("member");
    vi.mocked(db.markDirectConversationEntered).mockResolvedValue(true);
    vi.mocked(db.markDirectConversationRead).mockResolvedValue(true);
    const caller = appRouter.createCaller(makeContext(user));
    await expect(caller.chat.enter({ conversationId: 5 })).resolves.toEqual({ success: true });
    await expect(caller.chat.markRead({ conversationId: 5, messageId: 27 })).resolves.toEqual({ success: true });
    expect(db.markDirectConversationEntered).toHaveBeenCalledWith(user.id, 5);
    expect(db.markDirectConversationRead).toHaveBeenCalledWith(user.id, 5, 27);
  });

  it("rejects read markers and sends for conversations the user does not belong to", async () => {
    const user = makeUser("outsider");
    vi.mocked(db.markDirectConversationRead).mockResolvedValue(false);
    vi.mocked(db.sendDirectMessage).mockResolvedValue(false);
    const caller = appRouter.createCaller(makeContext(user));
    await expect(caller.chat.markRead({ conversationId: 7, messageId: 1 })).rejects.toMatchObject({ code: "NOT_FOUND" });
    await expect(caller.chat.send({ conversationId: 7, message: "hello" })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("stores a private profile photo for any authenticated account", async () => {
    const user = makeUser("new_user");
    const photoData = "data:image/jpeg;base64,Zm9v";
    vi.mocked(db.updateMemberChatProfilePhoto).mockResolvedValue(undefined);
    await appRouter.createCaller(makeContext(user)).chat.setPhoto({ photoData });
    expect(db.updateMemberChatProfilePhoto).toHaveBeenCalledWith(user.id, photoData);
  });

  it("trims and sends plain text only to a conversation member", async () => {
    const user = makeUser("member");
    vi.mocked(db.sendDirectMessage).mockResolvedValue(true);
    const caller = appRouter.createCaller(makeContext(user));
    await expect(caller.chat.send({ conversationId: 9, message: "  hi  " })).resolves.toEqual({ success: true });
    expect(db.sendDirectMessage).toHaveBeenCalledWith({ userId: user.id, conversationId: 9, message: "hi", imageData: undefined });
    await expect(caller.chat.send({ conversationId: 9, message: "  " })).rejects.toBeInstanceOf(TRPCError);
    await expect(caller.chat.send({ conversationId: 9, message: "x".repeat(501) })).rejects.toBeInstanceOf(TRPCError);
  });

  it("accepts a validated standalone JPEG and rejects empty or non-JPEG attachments", async () => {
    const user = makeUser("member");
    const imageData = validJpegDataUrl;
    vi.mocked(db.sendDirectMessage).mockResolvedValue(true);
    const caller = appRouter.createCaller(makeContext(user));
    await expect(caller.chat.send({ conversationId: 3, imageData })).resolves.toEqual({ success: true });
    expect(db.sendDirectMessage).toHaveBeenCalledWith({ userId: user.id, conversationId: 3, message: "", imageData });
    await expect(caller.chat.send({ conversationId: 3 })).rejects.toBeInstanceOf(TRPCError);
    await expect(caller.chat.send({ conversationId: 3, imageData: "data:image/svg+xml;base64,PHN2Zz4=" })).rejects.toBeInstanceOf(TRPCError);
  });

  it("limits a member to five messages in a rolling ten-second window", async () => {
    const user = makeUser("member");
    vi.mocked(db.sendDirectMessage).mockResolvedValue(true);
    const caller = appRouter.createCaller(makeContext(user));
    for (let index = 0; index < 5; index += 1) await caller.chat.send({ conversationId: 2, message: `message ${index}` });
    await expect(caller.chat.send({ conversationId: 2, message: "too soon" })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(db.sendDirectMessage).toHaveBeenCalledTimes(5);
    expect(db.bumpSlidingRateLimitBucket).toHaveBeenCalledWith(expect.objectContaining({ windowMs: 10_000, bucketMs: 100 }));
  });
});
