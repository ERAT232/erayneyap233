import { TRPCError } from "@trpc/server";
import { bumpSlidingRateLimitBucket } from "../db";
import { makeRateLimitKey } from "./rateLimits";

const WINDOW_MS = 10_000;
const MAX_MESSAGES_PER_WINDOW = 5;
const BUCKET_MS = 100;

export async function enforceMemberChatRateLimit(userId: number): Promise<void> {
  const bucket = await bumpSlidingRateLimitBucket({
    bucketPrefix: makeRateLimitKey("member-chat", String(userId)).slice(0, 32),
    windowMs: WINDOW_MS,
    bucketMs: BUCKET_MS,
  });
  if (bucket.count > MAX_MESSAGES_PER_WINDOW) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Kısa sürede çok mesaj gönderdin. Biraz bekle." });
  }
}
