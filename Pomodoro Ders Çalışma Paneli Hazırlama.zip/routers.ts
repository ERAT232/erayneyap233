import { ACCOUNT_SESSION_COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import {
  createHash,
  createHmac,
  randomBytes,
  randomInt,
  timingSafeEqual,
} from "node:crypto";
import { nanoid } from "nanoid";
import { z } from "zod";
import { pickDailyWheelPercentage } from "@shared/dailyWheel";
import { extractTweetIdFromUrl } from "@shared/twitter";
import * as db from "./db";
import {
  ACCOUNT_SESSION_TTL_MS,
  createAccountOpenId,
  createSessionToken,
  enforceAuthRateLimit,
  getSessionExpiry,
  hashPassword,
  hashSessionToken,
  normalizeUsername,
  readAccountSessionToken,
  verifyPasswordOrDummy,
} from "./_core/accountAuth";
import { getSessionCookieOptions } from "./_core/cookies";
import { enforceMemberChatRateLimit } from "./_core/chatRateLimit";
import { isValidChatImageData } from "./_core/chatImage";
import { getIstanbulDayKey } from "./_core/dailyNoteDay";
import { ENV } from "./_core/env";
import {
  enforceDistributedRateLimit,
  makeRateLimitKey,
} from "./_core/rateLimits";
import { systemRouter } from "./_core/systemRouter";
import {
  erayProcedure,
  protectedProcedure,
  publicProcedure,
  router,
} from "./_core/trpc";
import { isErayOwner } from "./_core/accessPolicy";
import {
  publicErayStudySnapshotSchema,
  type PublicErayDailyTask,
} from "@shared/erayStudyData";
import { resolveDailyTasksForSnapshot } from "@shared/dailyTasks";
import { isStudyDayKey } from "@shared/studyTracking";
import { storagePut } from "./storage";

const usernameSchema = z
  .string()
  .trim()
  .min(3, "Kullanıcı adı en az 3 karakter olmalı.")
  .max(24, "Kullanıcı adı en fazla 24 karakter olabilir.")
  .regex(
    /^[\p{L}\p{N}._-]+$/u,
    "Kullanıcı adı harf, sayı, nokta, tire veya alt çizgi içerebilir."
  );
const passwordSchema = z
  .string()
  .min(10, "Şifre en az 10 karakter olmalı.")
  .max(128, "Şifre en fazla 128 karakter olabilir.");
const credentialSchema = z.object({
  username: usernameSchema,
  password: passwordSchema,
});

const focusSessionSchema = z.object({
  endedAt: z.number().int().min(0).max(4_102_444_800_000),
  minutes: z.number().int().min(1).max(120),
});
const focusDaySchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  pomodoros: z.number().int().min(0).max(9999),
  focusSeconds: z.number().int().min(0).max(86_400),
});
const profilePhotoSchema = z
  .string()
  .max(400_000)
  .nullable()
  .refine(
    value =>
      value === null ||
      /^data:image\/jpeg;base64,[A-Za-z0-9+/]+=*$/.test(value),
    {
      message: "Only a compressed JPEG profile photo is supported",
    }
  );

function publicSessionsFromJson(value: string) {
  try {
    const parsed: unknown = JSON.parse(value);
    const result = z.array(focusSessionSchema).max(400).safeParse(parsed);
    return result.success ? result.data : [];
  } catch {
    return [];
  }
}

function publicDaysFromJson(value: string) {
  try {
    const parsed: unknown = JSON.parse(value);
    const result = z.array(focusDaySchema).max(2_000).safeParse(parsed);
    return result.success ? result.data : [];
  } catch {
    return [];
  }
}

function safeProfile(
  profile: NonNullable<Awaited<ReturnType<typeof db.getPublicProfileByOwner>>>
) {
  return {
    shareId: profile.shareId,
    profilePhoto: profile.profilePhoto,
    sessions: publicSessionsFromJson(profile.sessionsJson),
    days: publicDaysFromJson(profile.daysJson),
    isPublic: profile.isPublic,
    updatedAt: profile.updatedAt,
  };
}

function safeAccountUser(
  user: NonNullable<Awaited<ReturnType<typeof db.getUserByOpenId>>>
) {
  if (!user?.username)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Hesap kaydı okunamadı.",
    });
  return {
    id: user.id,
    username: user.username,
    name: user.username,
    role: user.role,
    chatUserId: user.chatUserId,
    isEray: isErayOwner(user),
  };
}

function isDuplicateEntryError(error: unknown): boolean {
  let current: unknown = error;
  for (let depth = 0; depth < 4 && current; depth += 1) {
    if (
      typeof current === "object" &&
      "code" in current &&
      current.code === "ER_DUP_ENTRY"
    )
      return true;
    current =
      typeof current === "object" && "cause" in current ? current.cause : null;
  }
  return false;
}

const TWITTER_MANAGER_TOKEN_TTL_MS = 30 * 60 * 1_000;
const TWITTER_MANAGER_RATE_WINDOW_MS = 15 * 60 * 1_000;

function passwordMatches(candidate: string, expected: string): boolean {
  const candidateDigest = createHash("sha256")
    .update(candidate, "utf8")
    .digest();
  const expectedDigest = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(candidateDigest, expectedDigest);
}

function createTwitterManagerToken(userId: number): string {
  if (ENV.cookieSecret.length < 16)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Yönetim oturumu şu anda başlatılamıyor.",
    });
  const payload = Buffer.from(
    JSON.stringify({
      purpose: "twitter-corner-manager-v1",
      userId,
      expiresAt: Date.now() + TWITTER_MANAGER_TOKEN_TTL_MS,
      nonce: randomBytes(16).toString("base64url"),
    })
  ).toString("base64url");
  const signature = createHmac("sha256", ENV.cookieSecret)
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

function isValidTwitterManagerToken(token: string, userId: number): boolean {
  if (ENV.cookieSecret.length < 16) return false;
  const parts = token.split(".");
  if (
    parts.length !== 2 ||
    !/^[A-Za-z0-9_-]+$/.test(parts[0]) ||
    !/^[A-Za-z0-9_-]+$/.test(parts[1])
  )
    return false;
  const expected = createHmac("sha256", ENV.cookieSecret)
    .update(parts[0])
    .digest();
  const supplied = Buffer.from(parts[1], "base64url");
  if (
    supplied.length !== expected.length ||
    !timingSafeEqual(supplied, expected)
  )
    return false;
  try {
    const payload: unknown = JSON.parse(
      Buffer.from(parts[0], "base64url").toString("utf8")
    );
    if (!payload || typeof payload !== "object") return false;
    const value = payload as {
      purpose?: unknown;
      userId?: unknown;
      expiresAt?: unknown;
      nonce?: unknown;
    };
    return (
      value.purpose === "twitter-corner-manager-v1" &&
      value.userId === userId &&
      typeof value.expiresAt === "number" &&
      value.expiresAt > Date.now() &&
      typeof value.nonce === "string"
    );
  } catch {
    return false;
  }
}

async function rateLimitTwitterManagerPassword(
  req: Parameters<typeof enforceAuthRateLimit>[0],
  userId: number
): Promise<void> {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const message =
    "Çok fazla parola denemesi yapıldı. Bir süre sonra yeniden dene.";
  await enforceDistributedRateLimit({
    bucketKey: makeRateLimitKey("twitter-manager", "ip", ip),
    limit: 5,
    windowMs: TWITTER_MANAGER_RATE_WINDOW_MS,
    message,
  });
  await enforceDistributedRateLimit({
    bucketKey: makeRateLimitKey("twitter-manager", "user", String(userId)),
    limit: 10,
    windowMs: TWITTER_MANAGER_RATE_WINDOW_MS,
    message,
  });
}

async function establishSession(
  ctx: {
    req: Parameters<typeof getSessionCookieOptions>[0];
    res: {
      cookie: (
        name: string,
        value: string,
        options: Record<string, unknown>
      ) => unknown;
    };
  },
  userId: number
) {
  const token = createSessionToken();
  await db.createAccountSession({
    userId,
    tokenHash: hashSessionToken(token),
    expiresAt: getSessionExpiry(),
  });
  ctx.res.cookie(ACCOUNT_SESSION_COOKIE_NAME, token, {
    ...getSessionCookieOptions(ctx.req),
    maxAge: ACCOUNT_SESSION_TTL_MS,
  });
}

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(({ ctx }) =>
      ctx.user?.username ? safeAccountUser(ctx.user) : null
    ),

    signup: publicProcedure
      .input(credentialSchema)
      .mutation(async ({ ctx, input }) => {
        const username = normalizeUsername(input.username);
        await enforceAuthRateLimit(ctx.req, username, "signup");
        const passwordHash = await hashPassword(input.password);
        let created;
        try {
          created = await db.createPasswordUser({
            openId: createAccountOpenId(),
            username,
            passwordHash,
          });
        } catch (error) {
          if (isDuplicateEntryError(error)) {
            throw new TRPCError({
              code: "CONFLICT",
              message: "Bu kullanıcı adı kullanılıyor. Başka bir tane seç.",
            });
          }
          throw error;
        }
        if (!created)
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Hesap oluşturulamadı.",
          });
        await establishSession(ctx, created.id);
        return safeAccountUser(created);
      }),

    login: publicProcedure
      .input(credentialSchema)
      .mutation(async ({ ctx, input }) => {
        const username = normalizeUsername(input.username);
        await enforceAuthRateLimit(ctx.req, username, "login");
        const user = await db.getUserByUsername(username);
        const validPassword = await verifyPasswordOrDummy(
          input.password,
          user?.passwordHash
        );
        if (!user || !user.username || !validPassword) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Kullanıcı adı veya şifre yanlış.",
          });
        }
        await db.updateUserLastSignedIn(user.id);
        await establishSession(ctx, user.id);
        return safeAccountUser({ ...user, lastSignedIn: new Date() });
      }),

    logout: publicProcedure.mutation(async ({ ctx }) => {
      const token = readAccountSessionToken(ctx.req);
      if (token) await db.deleteAccountSession(hashSessionToken(token));
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(ACCOUNT_SESSION_COOKIE_NAME, {
        ...cookieOptions,
        maxAge: -1,
      });
      return { success: true } as const;
    }),
  }),

  profile: router({
    /** Returns only the authenticated user's own share settings. */
    mine: protectedProcedure.query(async ({ ctx }) => {
      const profile = await db.getPublicProfileByOwner(ctx.user.openId);
      return profile ? safeProfile(profile) : null;
    }),

    /** Public, read-only profile endpoint. Never returns account identity or task details. */
    view: publicProcedure
      .input(z.object({ shareId: z.string().regex(/^[A-Za-z0-9_-]{12}$/) }))
      .query(async ({ input }) => {
        const profile = await db.getPublicProfileByShareId(input.shareId);
        if (!profile || !profile.isPublic) return null;
        return {
          shareId: profile.shareId,
          profilePhoto: profile.profilePhoto,
          sessions: publicSessionsFromJson(profile.sessionsJson),
          days: publicDaysFromJson(profile.daysJson),
          updatedAt: profile.updatedAt,
        };
      }),

    /** Mutations are scoped strictly to the authenticated account's own profile. */
    save: erayProcedure
      .input(
        z.object({
          profilePhoto: profilePhotoSchema,
          sessions: z.array(focusSessionSchema).max(400),
          days: z.array(focusDaySchema).max(2_000),
          isPublic: z.boolean(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const current = await db.getPublicProfileByOwner(ctx.user.openId);
        const shareId = current?.shareId ?? nanoid(12);
        const sessions = [...input.sessions]
          .sort((a, b) => b.endedAt - a.endedAt)
          .slice(0, 400);
        const updated = await db.upsertPublicProfile({
          ownerOpenId: ctx.user.openId,
          shareId,
          profilePhoto: input.profilePhoto,
          sessionsJson: JSON.stringify(sessions),
          daysJson: JSON.stringify(input.days),
          isPublic: input.isPublic,
        });
        if (!updated) throw new Error("Could not save public profile");
        return safeProfile(updated);
      }),
  }),

  erayStudyData: router({
    /** This is a deliberately public endpoint: the owner authorized these study fields for everyone to view. */
    view: publicProcedure.query(async () => {
      const workspace = await db.getPublicErayStudyWorkspace();
      if (!workspace) return null;
      try {
        const parsed: unknown = JSON.parse(workspace.snapshotJson);
        const safeSnapshot = publicErayStudySnapshotSchema.safeParse(parsed);
        if (!safeSnapshot.success) return null;
        return {
          snapshot: {
            ...safeSnapshot.data,
            dailyTasks: safeSnapshot.data.dailyTasks ?? [],
          },
          updatedAt: workspace.updatedAt,
        };
      } catch {
        return null;
      }
    }),

    /** Lightweight live status avoids repeatedly sending large book-cover snapshots to visitors. */
    status: publicProcedure.query(async () => {
      const status = await db.getPublicErayStudyStatus();
      if (!status) return null;
      return status;
    }),

    /** Timer ticks update only the compact projection, never re-uploading covers or study history. */
    statusSync: erayProcedure
      .input(
        z
          .object({
            phase: z.enum(["focus", "short", "long"]),
            running: z.boolean(),
            endAt: z.number().int().min(0).max(4_102_444_800_000).nullable(),
            remainingSec: z.number().int().min(0).max(86_400),
          })
          .strict()
          .refine(status => !status.running || status.endAt !== null)
      )
      .mutation(async ({ ctx, input }) => {
        await db.updatePublicErayStudyStatus(ctx.user.id, input);
        return { success: true } as const;
      }),

    /** Only the authenticated account whose canonical username is `eray` can change public study data. */
    sync: erayProcedure
      .input(z.object({ snapshot: publicErayStudySnapshotSchema }))
      .mutation(async ({ ctx, input }) => {
        const existingWorkspace =
          input.snapshot.dailyTasks === undefined
            ? await db.getPublicErayStudyWorkspace()
            : null;
        let existingDailyTasks: PublicErayDailyTask[] | undefined;
        if (existingWorkspace) {
          try {
            const current: unknown = JSON.parse(existingWorkspace.snapshotJson);
            const safeCurrent =
              publicErayStudySnapshotSchema.safeParse(current);
            if (safeCurrent.success)
              existingDailyTasks = safeCurrent.data.dailyTasks;
          } catch {
            existingDailyTasks = undefined;
          }
        }
        const snapshot = {
          ...input.snapshot,
          dailyTasks: resolveDailyTasksForSnapshot(
            input.snapshot.dailyTasks,
            existingDailyTasks
          ),
        };
        const saved = await db.upsertPublicErayStudyWorkspace({
          ownerUserId: ctx.user.id,
          snapshotJson: JSON.stringify(snapshot),
          pomodoro: snapshot.pomodoro.timer,
        });
        if (!saved)
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Çalışma verileri kaydedilemedi.",
          });
        return { updatedAt: saved.updatedAt } as const;
      }),
  }),

  dailyTimerPhotos: router({
    list: publicProcedure.query(async () => {
      const photos = await db.listDailyTimerPhotos();
      return photos.map(photo => ({
        dayKey: photo.dayKey,
        url: `/manus-storage/${photo.storageKey}`,
        uploadedAt: photo.uploadedAt,
      }));
    }),

    replace: erayProcedure
      .input(
        z
          .object({
            dayKey: z.string().refine(isStudyDayKey, "Geçerli bir gün seç."),
            imageData: z.string().max(4_200_000),
          })
          .strict()
      )
      .mutation(async ({ ctx, input }) => {
        if (input.dayKey > getIstanbulDayKey()) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Gelecek bir gün için kronometre fotoğrafı yüklenemez.",
          });
        }
        if (!isValidChatImageData(input.imageData)) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              "Fotoğraf JPEG olmalı; en fazla 3 MB ve 1600 piksel kenar ölçüsünde olabilir.",
          });
        }

        const base64 = input.imageData.slice("data:image/jpeg;base64,".length);
        let uploaded: Awaited<ReturnType<typeof storagePut>>;
        try {
          uploaded = await storagePut(
            `daily-timer-photos/${input.dayKey}.jpg`,
            Buffer.from(base64, "base64"),
            "image/jpeg"
          );
        } catch {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message:
              "Kronometre fotoğrafı depolama alanına yüklenemedi. Daha sonra yeniden dene.",
          });
        }

        try {
          await db.upsertDailyTimerPhoto({
            dayKey: input.dayKey,
            storageKey: uploaded.key,
            uploadedBy: ctx.user.id,
          });
        } catch {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Kronometre fotoğrafı gün kaydına eklenemedi.",
          });
        }
        return {
          dayKey: input.dayKey,
          url: uploaded.url,
        } as const;
      }),
  }),

  twitterCorner: router({
    list: publicProcedure.query(() => db.listHomeTwitterItems()),

    unlock: protectedProcedure
      .input(z.object({ password: z.string().min(1).max(128) }))
      .mutation(async ({ ctx, input }) => {
        const expected = process.env.TWITTER_CORNER_PASSWORD;
        if (!expected)
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Arayüz erişimi şu anda kullanılamıyor.",
          });
        if (!passwordMatches(input.password, expected)) {
          await rateLimitTwitterManagerPassword(ctx.req, ctx.user.id);
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Arayüz parolası hatalı.",
          });
        }
        return { token: createTwitterManagerToken(ctx.user.id) };
      }),

    add: protectedProcedure
      .input(
        z.object({
          managerToken: z.string().min(20).max(512),
          url: z.string().trim().min(1).max(2048),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        const tweetId = extractTweetIdFromUrl(input.url);
        if (!tweetId)
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Yalnızca HTTPS X/Twitter gönderi bağlantısı eklenebilir.",
          });
        try {
          const item = await db.addHomeTwitterItem(tweetId, ctx.user.id, true);
          if (!item)
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "Tweet eklenemedi.",
            });
          return item;
        } catch (error) {
          if (isDuplicateEntryError(error))
            throw new TRPCError({
              code: "CONFLICT",
              message: "Bu tweet zaten Twitter köşesinde.",
            });
          throw error;
        }
      }),

    importLegacy: protectedProcedure
      .input(
        z.object({
          managerToken: z.string().min(20).max(512),
          urls: z.array(z.string().trim().min(1).max(2048)).max(20),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        const tweetIds = input.urls.map(extractTweetIdFromUrl);
        if (tweetIds.some(tweetId => !tweetId)) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              "Eski listede desteklenmeyen bir bağlantı var; yalnızca HTTPS X/Twitter gönderileri aktarılabilir.",
          });
        }
        let imported = 0;
        for (const tweetId of [...new Set(tweetIds as string[])]) {
          try {
            if (await db.addHomeTwitterItem(tweetId, ctx.user.id))
              imported += 1;
          } catch (error) {
            if (!isDuplicateEntryError(error)) throw error;
          }
        }
        return { imported } as const;
      }),

    remove: protectedProcedure
      .input(
        z.object({
          managerToken: z.string().min(20).max(512),
          id: z.number().int().positive(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        const deleted = await db.deleteHomeTwitterItem(input.id);
        if (!deleted)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Tweet bulunamadı veya zaten kaldırılmış.",
          });
        return { success: true } as const;
      }),
  }),

  homeTicker: router({
    list: publicProcedure.query(() => db.listHomeTickerItems()),

    add: protectedProcedure
      .input(
        z.object({
          managerToken: z.string().min(20).max(512),
          content: z.string().trim().min(1).max(280),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        await db.addHomeTickerItem(input.content);
        return { success: true } as const;
      }),

    update: protectedProcedure
      .input(
        z.object({
          managerToken: z.string().min(20).max(512),
          id: z.number().int().positive(),
          content: z.string().trim().min(1).max(280),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        const updated = await db.updateHomeTickerItem(input.id, input.content);
        if (!updated)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Kayan yazı bulunamadı veya silinmiş.",
          });
        return { success: true } as const;
      }),

    remove: protectedProcedure
      .input(
        z.object({
          managerToken: z.string().min(20).max(512),
          id: z.number().int().positive(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        const deleted = await db.deleteHomeTickerItem(input.id);
        if (!deleted)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Kayan yazı bulunamadı veya silinmiş.",
          });
        return { success: true } as const;
      }),
  }),

  homePhoto: router({
    current: publicProcedure.query(async () => {
      const photo = await db.getHomeFeaturedPhoto();
      return photo ? { url: `/manus-storage/${photo.storageKey}` } : null;
    }),

    replace: protectedProcedure
      .input(
        z.object({
          managerToken: z.string().min(20).max(512),
          imageData: z.string().max(4_200_000),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        if (!isValidChatImageData(input.imageData)) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              "Fotoğraf JPEG olmalı; dosya en fazla 3 MB ve 1600 piksel kenar ölçüsünde olabilir.",
          });
        }

        const base64 = input.imageData.slice("data:image/jpeg;base64,".length);
        let uploaded: Awaited<ReturnType<typeof storagePut>>;
        try {
          uploaded = await storagePut(
            "home-photo/featured.jpg",
            Buffer.from(base64, "base64"),
            "image/jpeg"
          );
        } catch {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message:
              "Fotoğraf depolama alanına yüklenemedi. Daha sonra yeniden dene.",
          });
        }

        try {
          await db.setHomeFeaturedPhoto(uploaded.key, ctx.user.id);
        } catch {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Fotoğraf ana sayfaya kaydedilemedi.",
          });
        }
        return { success: true } as const;
      }),

    remove: protectedProcedure
      .input(z.object({ managerToken: z.string().min(20).max(512) }))
      .mutation(async ({ ctx, input }) => {
        if (!isValidTwitterManagerToken(input.managerToken, ctx.user.id)) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message:
              "Arayüz erişimi süresi doldu. Parolayla yeniden giriş yap.",
          });
        }
        await db.deleteHomeFeaturedPhoto();
        return { success: true } as const;
      }),
  }),

  dailyNotes: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const dayKey = getIstanbulDayKey();
      const notes = await db.listDailyHomeNotes(dayKey);
      return {
        dayKey,
        notes: notes.map(note => ({
          id: note.id,
          content: note.content,
          authorUsername: note.authorUsername,
          updatedAt: note.updatedAt,
          isMine: note.userId === ctx.user.id,
        })),
      };
    }),

    save: protectedProcedure
      .input(z.object({ content: z.string().trim().min(1).max(160) }))
      .mutation(async ({ ctx, input }) => {
        const dayKey = getIstanbulDayKey();
        await db.upsertDailyHomeNote(dayKey, ctx.user.id, input.content);
        return { success: true, dayKey } as const;
      }),

    remove: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const deleted = await db.deleteDailyHomeNote(
          input.id,
          ctx.user.id,
          getIstanbulDayKey()
        );
        if (!deleted)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Bugünkü not bulunamadı veya sana ait değil.",
          });
        return { success: true } as const;
      }),
  }),

  notifications: router({
    list: protectedProcedure.query(({ ctx }) =>
      db.listUserNotifications(ctx.user.id)
    ),

    markRead: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const marked = await db.markUserNotificationRead(ctx.user.id, input.id);
        if (!marked)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Bildirim bulunamadı.",
          });
        return { success: true } as const;
      }),
  }),

  dailyWheel: router({
    today: protectedProcedure.query(async ({ ctx }) => {
      const dayKey = getIstanbulDayKey();
      const percentage = await db.getDailyWheelSpin(ctx.user.id, dayKey);
      return { dayKey, percentage } as const;
    }),

    spin: protectedProcedure.mutation(async ({ ctx }) => {
      const dayKey = getIstanbulDayKey();
      const candidate = pickDailyWheelPercentage(randomInt(100));
      const result = await db.createDailyWheelSpin(
        ctx.user.id,
        dayKey,
        candidate
      );
      return {
        dayKey,
        percentage: result.percentage,
        alreadySpun: result.alreadySpun,
      } as const;
    }),
  }),

  chat: router({
    identity: protectedProcedure.query(({ ctx }) =>
      db.getChatIdentity(ctx.user.id)
    ),

    list: protectedProcedure.query(({ ctx }) =>
      db.listDirectConversations(ctx.user.id)
    ),

    start: protectedProcedure
      .input(
        z.object({
          chatUserId: z
            .string()
            .trim()
            .min(8)
            .max(16)
            .regex(/^[A-Za-z0-9_-]+$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const conversation = await db.startDirectConversation(
          ctx.user.id,
          input.chatUserId
        );
        if (!conversation) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message:
              "Bu sohbet ID'si bulunamadı. Kendi ID'nle sohbet başlatamazsın.",
          });
        }
        return conversation;
      }),

    hide: protectedProcedure
      .input(z.object({ conversationId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const hidden = await db.hideDirectConversation(
          ctx.user.id,
          input.conversationId
        );
        if (!hidden)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Sohbet bulunamadı.",
          });
        return { success: true } as const;
      }),

    open: protectedProcedure
      .input(z.object({ conversationId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const conversation = await db.getDirectConversation(
          ctx.user.id,
          input.conversationId
        );
        if (!conversation)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Sohbet bulunamadı.",
          });
        return conversation;
      }),

    image: protectedProcedure
      .input(
        z.object({
          conversationId: z.number().int().positive(),
          messageId: z.number().int().positive(),
        })
      )
      .query(async ({ ctx, input }) => {
        const imageData = await db.getDirectMessageImage(
          ctx.user.id,
          input.conversationId,
          input.messageId
        );
        if (!imageData)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Görsel bulunamadı veya bu sohbete erişimin yok.",
          });
        return { imageData };
      }),

    enter: protectedProcedure
      .input(z.object({ conversationId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const entered = await db.markDirectConversationEntered(
          ctx.user.id,
          input.conversationId
        );
        if (!entered)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Sohbet bulunamadı.",
          });
        return { success: true } as const;
      }),

    markRead: protectedProcedure
      .input(
        z.object({
          conversationId: z.number().int().positive(),
          messageId: z.number().int().positive(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const marked = await db.markDirectConversationRead(
          ctx.user.id,
          input.conversationId,
          input.messageId
        );
        if (!marked)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Sohbet bulunamadı.",
          });
        return { success: true } as const;
      }),

    deleteMessage: protectedProcedure
      .input(
        z.object({
          conversationId: z.number().int().positive(),
          messageId: z.number().int().positive(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const deleted = await db.deleteDirectMessage(
          ctx.user.id,
          input.conversationId,
          input.messageId
        );
        if (!deleted)
          throw new TRPCError({
            code: "NOT_FOUND",
            message:
              "Mesaj bulunamadı, zaten silinmiş ya da yalnızca kendi mesajlarını silebilirsin.",
          });
        return { success: true } as const;
      }),

    setPhoto: protectedProcedure
      .input(z.object({ photoData: profilePhotoSchema }))
      .mutation(async ({ ctx, input }) => {
        await db.updateMemberChatProfilePhoto(ctx.user.id, input.photoData);
        return { success: true } as const;
      }),

    send: protectedProcedure
      .input(
        z
          .object({
            conversationId: z.number().int().positive(),
            message: z
              .string()
              .trim()
              .max(500, "Mesaj en fazla 500 karakter olabilir.")
              .optional(),
            imageData: z
              .string()
              .max(4_194_327)
              .refine(
                isValidChatImageData,
                "Görsel JPEG olmalı, en fazla 3 MB ve 1600 px kenar ölçüsünde olmalı."
              )
              .optional(),
          })
          .refine(input => Boolean(input.message || input.imageData), {
            message: "Boş mesaj gönderilemez; metin veya görsel ekle.",
            path: ["message"],
          })
      )
      .mutation(async ({ ctx, input }) => {
        await enforceMemberChatRateLimit(ctx.user.id);
        const sent = await db.sendDirectMessage({
          userId: ctx.user.id,
          conversationId: input.conversationId,
          message: input.message ?? "",
          imageData: input.imageData,
        });
        if (!sent)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Sohbet bulunamadı.",
          });
        return { success: true } as const;
      }),
  }),
});

export type AppRouter = typeof appRouter;
