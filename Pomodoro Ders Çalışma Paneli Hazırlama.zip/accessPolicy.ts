import type { User } from "../../drizzle/schema";

/** The username is canonicalized to lowercase when accounts are created. */
export function isErayOwner(
  user: User | null | undefined
): user is User {
  return user?.username?.toLocaleLowerCase("en-US") === "eray";
}
