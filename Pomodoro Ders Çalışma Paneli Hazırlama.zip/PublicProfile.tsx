import { useEffect } from "react";
import { useRoute } from "wouter";
import { ArrowLeft, CalendarDays, Clock3, Timer, UserRound } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { formatMinutes } from "@/lib/pomodoro/format";

function dateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

const dateTime = new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium", timeStyle: "short" });
const shortDay = new Intl.DateTimeFormat("tr-TR", { weekday: "short" });

export default function PublicProfile() {
  const [, params] = useRoute("/paylasim/:shareId");
  const shareId = params?.shareId ?? "";
  const profileQuery = trpc.profile.view.useQuery(
    { shareId },
    { enabled: /^[A-Za-z0-9_-]{12}$/.test(shareId), retry: false },
  );
  const profile = profileQuery.data;

  useEffect(() => {
    document.title = "Açık Odak Günlüğü — Odak Paneli";
    return () => {
      document.title = "Odak Paneli — Pomodoro Çalışma Saati";
    };
  }, []);

  if (profileQuery.isLoading) {
    return (
      <main className="desk-glow paper-grain grid min-h-screen place-items-center px-4">
        <p className="text-sm text-ink-faint">Odak günlüğü yükleniyor…</p>
      </main>
    );
  }

  if (profileQuery.isError || !profile) {
    return (
      <main className="desk-glow paper-grain grid min-h-screen place-items-center px-4">
        <section className="plate w-full max-w-lg rounded-md p-8 text-center">
          <h1 className="font-display text-2xl font-bold text-ink">Odak günlüğü bulunamadı</h1>
          <p className="mt-2 text-sm text-ink-soft">Bu bağlantı hatalı olabilir veya profil sahibi paylaşımı kapatmıştır.</p>
          <a href="/" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-amber-ink hover:underline">
            <ArrowLeft className="h-4 w-4" /> Odak Paneli'ne dön
          </a>
        </section>
      </main>
    );
  }

  const today = dateKey(new Date());
  const weekStartDate = new Date();
  weekStartDate.setDate(weekStartDate.getDate() - 6);
  const weekStart = dateKey(weekStartDate);
  const todayTotals = profile.days.find(day => day.date === today);
  const weekDays = profile.days.filter(day => day.date >= weekStart && day.date <= today);
  const weekPomodoros = weekDays.reduce((sum, day) => sum + day.pomodoros, 0);
  const weekFocusSeconds = weekDays.reduce((sum, day) => sum + day.focusSeconds, 0);
  const allPomodoros = profile.days.reduce((sum, day) => sum + day.pomodoros, 0);
  const bars = Array.from({ length: 7 }, (_, index) => {
    const day = new Date();
    day.setDate(day.getDate() - (6 - index));
    const key = dateKey(day);
    return { key, label: shortDay.format(day), value: profile.days.find(item => item.date === key)?.focusSeconds ?? 0 };
  });
  const maxBar = Math.max(1, ...bars.map(bar => bar.value));
  const recent = [...profile.sessions].sort((a, b) => b.endedAt - a.endedAt).slice(0, 20);

  return (
    <main className="desk-glow paper-grain min-h-screen px-4 pb-12">
      <div className="mx-auto w-full max-w-4xl">
        <header className="flex items-center justify-between border-b border-[rgba(90,66,34,0.28)] py-5">
          <a href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-ink-soft transition hover:text-amber-ink">
            <ArrowLeft className="h-4 w-4" /> Odak Paneli
          </a>
          <span className="text-xs tracking-[0.14em] text-ink-faint uppercase">Herkese açık profil</span>
        </header>

        <section className="plate mt-6 overflow-hidden rounded-md">
          <div className="flex flex-col items-center gap-4 border-b border-[rgba(90,66,34,0.2)] px-5 py-7 text-center sm:flex-row sm:text-left">
            <div className="grid h-24 w-24 shrink-0 place-items-center overflow-hidden rounded-full border-[3px] border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.9)] shadow-[0_4px_16px_rgba(60,40,15,0.14)]">
              {profile.profilePhoto ? (
                <img src={profile.profilePhoto} alt="Paylaşılan profil fotoğrafı" className="h-full w-full object-cover" />
              ) : (
                <UserRound className="h-10 w-10 text-ink-faint" strokeWidth={1.4} />
              )}
            </div>
            <div>
              <p className="text-[0.7rem] font-semibold tracking-[0.18em] text-amber-ink uppercase">Odak Paneli</p>
              <h1 className="mt-1 font-display text-3xl font-bold text-ink">Açık Odak Günlüğü</h1>
              <p className="mt-1 text-sm text-ink-soft">Düzenli çalışma oturumları ve odak süreleri</p>
            </div>
          </div>

          <div className="grid gap-3 px-5 py-5 sm:grid-cols-3">
            <article className="rounded-sm border border-[rgba(90,66,34,0.22)] bg-[rgba(255,251,241,0.72)] px-4 py-3">
              <p className="flex items-center gap-1.5 text-[0.67rem] font-semibold tracking-[0.13em] text-ink-faint uppercase">
                <CalendarDays className="h-3.5 w-3.5" /> Bugün
              </p>
              <p className="mt-1 font-display text-2xl font-bold text-ink">{formatMinutes(todayTotals?.focusSeconds ?? 0)}</p>
              <p className="text-xs text-ink-faint">{todayTotals?.pomodoros ?? 0} tamamlanan pomodoro</p>
            </article>
            <article className="rounded-sm border border-[rgba(90,66,34,0.22)] bg-[rgba(255,251,241,0.72)] px-4 py-3">
              <p className="flex items-center gap-1.5 text-[0.67rem] font-semibold tracking-[0.13em] text-ink-faint uppercase">
                <Clock3 className="h-3.5 w-3.5" /> Son 7 gün
              </p>
              <p className="mt-1 font-display text-2xl font-bold text-ink">{formatMinutes(weekFocusSeconds)}</p>
              <p className="text-xs text-ink-faint">{weekPomodoros} tamamlanan pomodoro</p>
            </article>
            <article className="rounded-sm border border-[rgba(90,66,34,0.22)] bg-[rgba(255,251,241,0.72)] px-4 py-3">
              <p className="flex items-center gap-1.5 text-[0.67rem] font-semibold tracking-[0.13em] text-ink-faint uppercase">
                <Timer className="h-3.5 w-3.5" /> Toplam
              </p>
              <p className="mt-1 font-display text-2xl font-bold text-ink">{allPomodoros}</p>
              <p className="text-xs text-ink-faint">kayıtlı pomodoro turu</p>
            </article>
          </div>

          <section className="px-5 pb-5">
            <div className="flex items-center justify-between border-b border-dashed border-[rgba(90,66,34,0.26)] pb-2">
              <h2 className="font-display text-lg font-bold text-ink">Haftalık odak</h2>
              <span className="text-xs text-ink-faint">Son 7 gün</span>
            </div>
            <div className="mt-4 grid h-28 grid-cols-7 items-end gap-3">
              {bars.map(bar => {
                const height = bar.value === 0 ? 4 : Math.max(10, Math.round((bar.value / maxBar) * 96));
                return (
                  <div key={bar.key} className="flex h-full flex-col items-center justify-end gap-1.5">
                    <div className="flex w-full flex-1 items-end justify-center">
                      <div
                        className="w-full max-w-9 rounded-t-[3px] bg-amber-ink/80 transition-[height]"
                        style={{ height: `${height}%` }}
                        title={`${bar.label}: ${formatMinutes(bar.value)}`}
                      />
                    </div>
                    <span className="text-[0.65rem] text-ink-faint">{bar.label}</span>
                  </div>
                );
              })}
            </div>
          </section>
        </section>

        <section className="plate mt-5 rounded-md px-5 py-4">
          <div className="flex items-baseline justify-between gap-3 border-b border-dashed border-[rgba(90,66,34,0.26)] pb-2">
            <h2 className="font-display text-lg font-bold text-ink">Son oturumlar</h2>
            <span className="text-xs text-ink-faint">{profile.sessions.length} oturum kaydı</span>
          </div>
          {recent.length ? (
            <ul className="mt-2 divide-y divide-[rgba(90,66,34,0.12)]">
              {recent.map((session, index) => (
                <li key={`${session.endedAt}-${index}`} className="flex items-center justify-between gap-4 py-2.5">
                  <span className="text-sm text-ink-soft">{dateTime.format(new Date(session.endedAt))}</span>
                  <span className="shrink-0 font-display text-sm font-bold text-ink">{session.minutes} dk odak</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="py-5 text-sm text-ink-faint italic">Henüz herkese açık odak oturumu bulunmuyor.</p>
          )}
        </section>

        <p className="mx-auto mt-4 max-w-2xl text-center text-xs leading-relaxed text-ink-faint">
          Bu sayfada yalnızca profil fotoğrafı ve odak geçmişi yer alır. Hesap e-postası, ders adları ve görev başlıkları paylaşılmaz.
        </p>
      </div>
    </main>
  );
}
