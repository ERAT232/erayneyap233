export interface YksTopic {
  id: string;
  name: string;
}

export interface YksSubject {
  id: string;
  name: string;
  topics: YksTopic[];
}

export const YKS_SUBJECT_STORAGE_PREFIX =
  "odak-paneli/yks-subjects/v1/accounts/";
export const YKS_SUBJECT_LIMIT = 60;
export const YKS_TOPIC_LIMIT = 120;
export const YKS_NAME_LIMIT = 80;

export function getYksSubjectsStorageKey(accountId: string | number): string {
  return `${YKS_SUBJECT_STORAGE_PREFIX}${encodeURIComponent(String(accountId))}`;
}

export function readYksSubjects(key: string): YksSubject[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (subject): subject is YksSubject =>
          Boolean(subject) &&
          typeof subject.id === "string" &&
          typeof subject.name === "string" &&
          Array.isArray(subject.topics)
      )
      .slice(0, YKS_SUBJECT_LIMIT)
      .map(subject => ({
        id: subject.id.slice(0, 120),
        name: subject.name.trim().slice(0, YKS_NAME_LIMIT),
        topics: subject.topics
          .filter(
            (topic): topic is YksTopic =>
              Boolean(topic) &&
              typeof topic.id === "string" &&
              typeof topic.name === "string"
          )
          .slice(0, YKS_TOPIC_LIMIT)
          .map(topic => ({
            id: topic.id.slice(0, 120),
            name: topic.name.trim().slice(0, YKS_NAME_LIMIT),
          })),
      }));
  } catch {
    return [];
  }
}
