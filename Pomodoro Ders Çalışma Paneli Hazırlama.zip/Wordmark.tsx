export function ClockMark({ className, color = "#B45309" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true" fill="none">
      <circle cx="6.6" cy="7" r="3" stroke={color} strokeWidth="1.7" />
      <circle cx="25.4" cy="7" r="3" stroke={color} strokeWidth="1.7" />
      <circle cx="16" cy="18" r="10.4" stroke={color} strokeWidth="1.9" />
      <path d="M16 18V11.6" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
      <path d="M16 18l4.4 2.6" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
      <path d="M9.4 27.2 7.2 30M22.6 27.2l2.2 2.8" stroke={color} strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

export default function Wordmark() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative grid h-11 w-11 place-items-center rounded-full border border-[rgba(90,66,34,0.3)] bg-[rgba(253,248,236,0.85)] shadow-[inset_0_1px_0_rgba(255,255,255,0.7)]">
        <ClockMark className="h-6 w-6" />
      </div>
      <div className="leading-none">
        <div className="font-display text-2xl font-bold tracking-[0.22em] text-ink">ODAK</div>
        <div className="mt-1.5 text-[0.62rem] font-semibold tracking-[0.3em] text-ink-faint uppercase">
          Pomodoro Defteri
        </div>
      </div>
    </div>
  );
}
