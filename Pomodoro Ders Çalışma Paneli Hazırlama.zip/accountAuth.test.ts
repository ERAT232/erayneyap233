import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { Request } from "express";
import { TRPCError } from "@trpc/server";

const dbMocks = vi.hoisted(() => ({ bumpRateLimitBucket: vi.fn() }));
vi.mock("../db", () => dbMocks);

import * as db from "../db";
import {
  createSessionToken,
  enforceAuthRateLimit,
  hashPassword,
  hashSessionToken,
  normalizeUsername,
  verifyPassword,
} from "./accountAuth";
import { makeRateLimitKey } from "./rateLimits";

const bucketCounts = new Map<string, number>();
beforeEach(() => {
  vi.clearAllMocks();
  bucketCounts.clear();
  vi.stubEnv("MANUS_JWT_SECRET", "test-rate-limit-secret-long-enough-0123456789");
  vi.mocked(db.bumpRateLimitBucket).mockImplementation(async input => {
    const count = (bucketCounts.get(input.bucketKey) ?? 0) + 1;
    bucketCounts.set(input.bucketKey, count);
    return { count, resetAt: new Date((input.now ?? new Date()).getTime() + input.windowMs) };
  });
});
afterEach(() => vi.unstubAllEnvs());

describe("local account credentials", () => {
  it("normalizes Unicode usernames and keeps them case-insensitive", () => {
    expect(normalizeUsername("  ErAy_12  ")).toBe("eray_12");
    expect(normalizeUsername("Ａbc")).toBe("abc");
  });

  it("stores a salted scrypt hash rather than the password", async () => {
    const password = "a-unique-long-test-password";
    const first = await hashPassword(password);
    const second = await hashPassword(password);
    expect(first).toMatch(/^scrypt\$16384\$8\$1\$/);
    expect(first).not.toContain(password);
    expect(first).not.toBe(second);
    await expect(verifyPassword(password, first)).resolves.toBe(true);
    await expect(verifyPassword("incorrect-long-password", first)).resolves.toBe(false);
    await expect(verifyPassword(password, "bad-format")).resolves.toBe(false);
  });

  it("creates opaque, non-reversible, independently random session tokens", () => {
    const first = createSessionToken();
    const second = createSessionToken();
    expect(first).toMatch(/^[A-Za-z0-9_-]{40,50}$/);
    expect(first).not.toBe(second);
    expect(hashSessionToken(first)).toMatch(/^[a-f0-9]{64}$/);
    expect(hashSessionToken(first)).not.toBe(first);
  });

  it("HMACs rate-limit identifiers so the database never stores raw usernames or IPs", () => {
    const key = makeRateLimitKey("auth", "login", "username", "private-name");
    expect(key).toMatch(/^[a-f0-9]{64}$/);
    expect(key).not.toContain("private-name");
  });

  it("rate-limits repeated login attempts for one username using shared buckets", async () => {
    const request = { ip: "203.0.113.51", socket: { remoteAddress: "203.0.113.51" } } as Request;
    for (let attempt = 0; attempt < 12; attempt += 1) {
      await enforceAuthRateLimit(request, "unique-rate-limit-test-user", "login");
    }
    await expect(enforceAuthRateLimit(request, "unique-rate-limit-test-user", "login"))
      .rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(db.bumpRateLimitBucket).toHaveBeenCalledTimes(26);
  });
});
