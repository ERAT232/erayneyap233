import { describe, expect, it } from "vitest";
import { canonicalTweetUrl, extractTweetIdFromUrl } from "../shared/twitter";

describe("X/Twitter tweet URL validation", () => {
  it("accepts canonical X and legacy Twitter status links", () => {
    expect(extractTweetIdFromUrl("https://x.com/study/status/1234567890123456789?s=20")).toBe("1234567890123456789");
    expect(extractTweetIdFromUrl("https://twitter.com/study/status/12345/")).toBe("12345");
    expect(extractTweetIdFromUrl("https://x.com/i/status/99999999999")).toBe("99999999999");
  });

  it("rejects non-HTTPS, lookalike domains, credentials, custom ports and non-post URLs", () => {
    expect(extractTweetIdFromUrl("http://x.com/study/status/123456")).toBeNull();
    expect(extractTweetIdFromUrl("https://x.com.example.org/study/status/123456")).toBeNull();
    expect(extractTweetIdFromUrl("https://example.com/x.com/study/status/123456")).toBeNull();
    expect(extractTweetIdFromUrl("https://user@x.com/study/status/123456")).toBeNull();
    expect(extractTweetIdFromUrl("https://x.com:8443/study/status/123456")).toBeNull();
    expect(extractTweetIdFromUrl("https://x.com/study/status/not-a-number")).toBeNull();
    expect(extractTweetIdFromUrl("https://x.com/study/status/1234")).toBeNull();
    expect(extractTweetIdFromUrl("https://x.com/study/media/123456")).toBeNull();
  });

  it("constructs a canonical public link for a validated numeric ID", () => {
    expect(canonicalTweetUrl("123456789")).toBe("https://x.com/i/status/123456789");
    expect(() => canonicalTweetUrl("not-an-id")).toThrow("Invalid tweet ID");
  });
});
