import { useEffect } from "react";
import { Activity, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import YksCountdown from "@/components/YksCountdown";
import YksSubjects from "@/components/YksSubjects";
import YksBooks from "@/components/YksBooks";
import YksTytExams from "@/components/YksTytExams";
import YksDesiredPrograms from "@/components/YksDesiredPrograms";
import YksDailyTasks from "@/components/YksDailyTasks";
import YksTimerPhotos from "@/components/YksTimerPhotos";

export default function YksModePage() {
  useEffect(() => {
    const previousTitle = document.title;
    document.title = "YKS Mod — Odak Paneli";
    return () => {
      document.title = previousTitle;
    };
  }, []);

  return (
    <main className="desk-glow paper-grain min-h-screen px-4 py-8 sm:px-6 sm:py-10">
      <div className="mx-auto w-full max-w-7xl">
        <div className="flex flex-wrap justify-end gap-2">
          <Link href="/eray-ne-durumda" className="inline-flex h-11 items-center gap-2 rounded-xl border border-[rgba(91,122,84,0.3)] bg-[rgba(91,122,84,0.09)] px-4 text-sm font-semibold text-sage-ink shadow-sm transition hover:-translate-y-0.5 hover:bg-[rgba(91,122,84,0.15)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sage-ink">
            <Activity className="h-4 w-4" aria-hidden="true" />
            Eray Ne Durumda
          </Link>
          <Link href="/" className="inline-flex h-11 items-center gap-2 rounded-xl border border-white/75 bg-white/70 px-4 text-sm font-semibold text-ink-soft shadow-sm transition hover:-translate-y-0.5 hover:bg-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-ink">
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            Ana menüye dön
          </Link>
        </div>
        <div className="flex min-h-[34vh] items-center justify-center py-8">
          <YksCountdown size="large" />
        </div>
        <div className="mb-8">
          <YksDailyTasks />
        </div>
        <div className="mb-8">
          <YksTimerPhotos mode="owner" />
        </div>
        <div className="grid items-start gap-5 md:grid-cols-2 md:gap-6">
          <YksSubjects />
          <YksBooks />
        </div>
        <div className="mt-8 grid items-start gap-5 md:grid-cols-2 md:gap-6">
          <YksTytExams />
          <YksDesiredPrograms />
        </div>
      </div>
    </main>
  );
}
