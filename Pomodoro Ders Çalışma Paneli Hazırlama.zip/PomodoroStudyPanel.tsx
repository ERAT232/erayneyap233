import { useEffect, useRef, useState, type FormEvent } from "react";
import { BookOpenCheck, Clock3, Plus } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { usePomodoro } from "@/hooks/usePomodoro";
import { useYksSubjects } from "@/hooks/useYksSubjects";
import { getIstanbulDayKey, isStudyDayKey } from "@shared/studyTracking";
import { newId } from "@/lib/pomodoro/types";

export default function PomodoroStudyPanel() {
  const auth = useAuth();
  const pomo = usePomodoro();
  const { subjects, ready } = useYksSubjects(auth.user?.id);
  const storageKey = auth.user?.id === undefined ? null : String(auth.user.id);
  const initializedKey = useRef<string | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState("");
  const [selectedTopicId, setSelectedTopicId] = useState("");
  const [manualMinutes, setManualMinutes] = useState(String(pomo.settings.focusMin));
  const [manualDay, setManualDay] = useState(getIstanbulDayKey());

  useEffect(() => {
    if (!ready || !storageKey || initializedKey.current === storageKey) return;
    initializedKey.current = storageKey;
    const saved = pomo.studySelection;
    if (!saved) return;
    const subject = subjects.find(item => item.id === saved.subjectId);
    const topic = subject?.topics.find(item => item.id === saved.topicId);
    if (subject && topic) {
      setSelectedSubjectId(subject.id);
      setSelectedTopicId(topic.id);
    } else {
      pomo.setStudySelection(null);
    }
  }, [pomo, ready, storageKey, subjects]);

  const activeSubject = subjects.find(subject => subject.id === selectedSubjectId) ?? null;
  const activeTopic = activeSubject?.topics.find(topic => topic.id === selectedTopicId) ?? null;
  const selectedStudy = activeSubject && activeTopic
    ? {
        subjectId: activeSubject.id,
        subjectName: activeSubject.name,
        topicId: activeTopic.id,
        topicName: activeTopic.name,
      }
    : null;
  const studyInProgress = pomo.phase === "focus" && (pomo.running || pomo.remainingSec < pomo.totalSec);

  const selectSubject = (subjectId: string) => {
    const subject = subjects.find(item => item.id === subjectId) ?? null;
    const topic = subject?.topics[0] ?? null;
    setSelectedSubjectId(subject?.id ?? "");
    setSelectedTopicId(topic?.id ?? "");
    pomo.setStudySelection(subject && topic ? {
      subjectId: subject.id,
      subjectName: subject.name,
      topicId: topic.id,
      topicName: topic.name,
    } : null);
  };

  const selectTopic = (topicId: string) => {
    setSelectedTopicId(topicId);
    if (!activeSubject) return;
    const topic = activeSubject.topics.find(item => item.id === topicId);
    pomo.setStudySelection(topic ? {
      subjectId: activeSubject.id,
      subjectName: activeSubject.name,
      topicId: topic.id,
      topicName: topic.name,
    } : null);
  };

  const addManualStudy = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const minutes = Number(manualMinutes);
    if (!selectedStudy) {
      toast.error("Önce ders ve konu seç.");
      return;
    }
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      toast.error("Süre 1 ile 1.440 dakika arasında tam sayı olmalı.");
      return;
    }
    if (!isStudyDayKey(manualDay)) {
      toast.error("Geçerli bir çalışma günü seç.");
      return;
    }
    const now = Date.now();
    const endedAt = manualDay === getIstanbulDayKey(now)
      ? now
      : new Date(`${manualDay}T12:00:00+03:00`).getTime();
    const seconds = minutes * 60;
    pomo.addStudyEntry({
      id: newId(),
      source: "manual",
      ...selectedStudy,
      seconds,
      dayKey: manualDay,
      startedAt: endedAt - seconds * 1000,
      endedAt,
    });
    toast.success(`${selectedStudy.subjectName} · ${selectedStudy.topicName} için ${minutes} dk eklendi.`);
    setManualMinutes(String(pomo.settings.focusMin));
  };

  return (
    <section className="plate relative overflow-hidden rounded-md p-4 sm:p-5" aria-labelledby="pomodoro-study-title">
      <span className="screw top-2 left-2" />
      <span className="screw top-2 right-2" />
      <header className="mb-4 flex items-start gap-3 border-b border-[rgba(90,66,34,0.16)] pb-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-[rgba(91,122,84,0.24)] bg-[rgba(91,122,84,0.1)] text-sage-ink">
          <BookOpenCheck className="h-5 w-5" aria-hidden="true" />
        </span>
        <div>
          <p className="smallcaps">DERSİNİ KAYDA AL</p>
          <h2 id="pomodoro-study-title" className="mt-0.5 font-display text-xl font-bold text-ink">Ders ve konu</h2>
        </div>
      </header>

      {!ready ? (
        <p className="text-sm text-ink-faint" role="status">Derslerin yükleniyor…</p>
      ) : subjects.length === 0 ? (
        <div className="rounded-lg border border-dashed border-[rgba(90,66,34,0.25)] bg-white/35 p-4 text-sm text-ink-soft">
          <p>Pomodoro başlatmadan önce YKS Mod’da ders ve konu ekle.</p>
          <Link href="/yks-mod" className="mt-3 inline-flex h-9 items-center rounded-sm bg-sage-ink px-3 text-xs font-semibold text-white transition hover:brightness-110">
            YKS Mod’a git
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          <div>
            <label htmlFor="pomodoro-study-subject" className="mb-1.5 block text-xs font-semibold text-ink-soft">Ders</label>
            <select
              id="pomodoro-study-subject"
              value={selectedSubjectId}
              onChange={event => selectSubject(event.target.value)}
              disabled={studyInProgress}
              className="h-11 w-full rounded-sm border border-[rgba(90,66,34,0.3)] bg-[rgba(255,251,241,0.9)] px-3 text-sm text-ink outline-none focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/20 disabled:opacity-60"
            >
              <option value="">Ders seç</option>
              {subjects.map(subject => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
            </select>
          </div>

          <div>
            <label htmlFor="pomodoro-study-topic" className="mb-1.5 block text-xs font-semibold text-ink-soft">Konu</label>
            <select
              id="pomodoro-study-topic"
              value={selectedTopicId}
              onChange={event => selectTopic(event.target.value)}
              disabled={studyInProgress || !activeSubject || activeSubject.topics.length === 0}
              className="h-11 w-full rounded-sm border border-[rgba(90,66,34,0.3)] bg-[rgba(255,251,241,0.9)] px-3 text-sm text-ink outline-none focus:border-amber-ink focus:ring-2 focus:ring-amber-ink/20 disabled:opacity-60"
            >
              <option value="">{activeSubject ? (activeSubject.topics.length ? "Konu seç" : "Bu derse henüz konu eklenmedi") : "Önce ders seç"}</option>
              {activeSubject?.topics.map(topic => <option key={topic.id} value={topic.id}>{topic.name}</option>)}
            </select>
            {activeSubject && activeSubject.topics.length === 0 && (
              <Link href="/yks-mod" className="mt-1.5 inline-flex text-xs font-semibold text-sage-ink underline-offset-2 hover:underline">YKS Mod’da konu ekle</Link>
            )}
          </div>

          <p className="rounded-md bg-[rgba(233,215,179,0.35)] px-3 py-2 text-xs leading-relaxed text-ink-soft">
            {studyInProgress
              ? `Bu odak turu ${pomo.studySelection?.subjectName ?? "seçili ders"} · ${pomo.studySelection?.topicName ?? "seçili konu"} olarak kaydedilecek.`
              : selectedStudy
                ? `Başlatınca ${selectedStudy.subjectName} · ${selectedStudy.topicName} seçili olacak.`
                : "Odak turunu başlatmadan önce ders ve konu seç."}
          </p>

          <form onSubmit={addManualStudy} className="rounded-lg border border-[rgba(91,122,84,0.22)] bg-[rgba(91,122,84,0.06)] p-3">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
              <Clock3 className="h-4 w-4 text-sage-ink" aria-hidden="true" />
              Manuel çalışma ekle
            </div>
            <div className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)] gap-2">
              <div>
                <label htmlFor="manual-study-minutes" className="mb-1 block text-[0.68rem] font-semibold text-ink-soft">Dakika</label>
                <input
                  id="manual-study-minutes"
                  type="number"
                  min={1}
                  max={1440}
                  step={1}
                  value={manualMinutes}
                  onChange={event => setManualMinutes(event.target.value)}
                  className="h-10 w-full rounded-sm border border-[rgba(90,66,34,0.28)] bg-white/80 px-2.5 text-sm text-ink outline-none focus:border-sage-ink focus:ring-2 focus:ring-sage-ink/20"
                />
              </div>
              <div>
                <label htmlFor="manual-study-day" className="mb-1 block text-[0.68rem] font-semibold text-ink-soft">Çalışma günü</label>
                <input
                  id="manual-study-day"
                  type="date"
                  max={getIstanbulDayKey()}
                  value={manualDay}
                  onChange={event => setManualDay(event.target.value)}
                  className="h-10 w-full min-w-0 rounded-sm border border-[rgba(90,66,34,0.28)] bg-white/80 px-2 text-xs text-ink outline-none focus:border-sage-ink focus:ring-2 focus:ring-sage-ink/20"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={!selectedStudy}
              className="mt-2 inline-flex h-10 w-full items-center justify-center gap-2 rounded-sm bg-sage-ink px-4 text-sm font-semibold text-white transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Plus className="h-4 w-4" aria-hidden="true" /> Süreyi günlüğe ekle
            </button>
          </form>
        </div>
      )}
    </section>
  );
}
