import { Twitter } from "lucide-react";
import { trpc } from "@/lib/trpc";
import TweetEmbedList from "@/components/TweetEmbedList";

export default function TwitterCorner() {
  const items = trpc.twitterCorner.list.useQuery();

  return (
    <section id="twitter-corner" className="w-full max-w-xl overflow-hidden rounded-md border border-[rgba(90,66,34,0.28)] bg-[rgba(253,248,236,0.84)] shadow-sm" aria-labelledby="twitter-corner-title">
      <div className="flex items-center gap-2 border-b border-[rgba(90,66,34,0.18)] bg-[rgba(233,215,179,0.28)] px-4 py-3">
        <Twitter className="h-4 w-4 text-amber-ink" aria-hidden="true" />
        <h2 id="twitter-corner-title" className="font-display text-base font-bold text-ink">Twitter köşem</h2>
      </div>
      <div className="p-4">
        {items.isLoading ? (
          <p className="py-5 text-center text-sm text-ink-faint" role="status">Tweetler yükleniyor…</p>
        ) : items.isError ? (
          <p className="py-5 text-center text-sm text-destructive" role="alert">Twitter köşesi şu anda yüklenemedi.</p>
        ) : (
          <TweetEmbedList items={items.data ?? []} />
        )}
      </div>
    </section>
  );
}
