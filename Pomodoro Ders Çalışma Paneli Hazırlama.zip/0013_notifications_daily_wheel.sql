CREATE TABLE `dailyWheelSpins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dayKey` date NOT NULL,
	`percentage` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `dailyWheelSpins_id` PRIMARY KEY(`id`),
	CONSTRAINT `dailyWheelSpins_user_day_unique` UNIQUE(`userId`,`dayKey`)
);
--> statement-breakpoint
CREATE TABLE `userNotifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`kind` enum('direct_message','twitter_link') NOT NULL,
	`actorLabel` varchar(80) NOT NULL,
	`referenceId` int NOT NULL,
	`relatedMessageId` int,
	`readAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userNotifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `dailyWheelSpins` ADD CONSTRAINT `dailyWheelSpins_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `userNotifications` ADD CONSTRAINT `userNotifications_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `userNotifications` ADD CONSTRAINT `userNotifications_relatedMessageId_chatMessages_id_fk` FOREIGN KEY (`relatedMessageId`) REFERENCES `chatMessages`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `dailyWheelSpins_day_idx` ON `dailyWheelSpins` (`dayKey`);--> statement-breakpoint
CREATE INDEX `userNotifications_user_created_idx` ON `userNotifications` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `userNotifications_user_read_idx` ON `userNotifications` (`userId`,`readAt`);--> statement-breakpoint
CREATE INDEX `userNotifications_dm_message_idx` ON `userNotifications` (`userId`,`kind`,`referenceId`,`relatedMessageId`,`readAt`);