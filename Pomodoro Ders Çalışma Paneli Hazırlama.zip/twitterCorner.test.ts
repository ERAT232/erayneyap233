import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";
import type { User } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";

const dbMocks = vi.hoisted(() => ({
  listHomeTwitterItems: vi.fn(),
  addHomeTwitterItem: vi.fn(),
  deleteHomeTwitterItem: vi.fn(),
  listHomeTickerItems: vi.fn(),
  addHomeTickerItem: vi.fn(),
  updateHomeTickerItem: vi.fn(),
  deleteHomeTickerItem: vi.fn(),
  getHomeFeaturedPhoto: vi.fn(),
  setHomeFeaturedPhoto: vi.fn(),
  deleteHomeFeaturedPhoto: vi.fn(),
  listDailyHomeNotes: vi.fn(),
  upsertDailyHomeNote: vi.fn(),
  deleteDailyHomeNote: vi.fn(),
  getDailyWheelSpin: vi.fn(),
  createDailyWheelSpin: vi.fn(),
  listUserNotifications: vi.fn(),
  markUserNotificationRead: vi.fn(),
  bumpRateLimitBucket: vi.fn(),
}));
const storageMocks = vi.hoisted(() => ({ storagePut: vi.fn() }));
vi.mock("./db", () => dbMocks);
vi.mock("./storage", () => storageMocks);

import * as db from "./db";
import * as storage from "./storage";
import { getIstanbulDayKey } from "./_core/dailyNoteDay";
import { DAILY_WHEEL_OPTIONS } from "../shared/dailyWheel";
import { appRouter } from "./routers";

let serial = 900;
const testOnlyPassword = "test-only-manager-password";
function makeUser(id?: number): User {
  serial += 1;
  const now = new Date();
  return {
    id: id ?? serial,
    openId: `local_test_account_${serial}`,
    chatUserId: `chat_test_${serial}`,
    username: `member${serial}`,
    passwordHash: "not-used-in-this-test",
    name: `member${serial}`,
    email: null,
    loginMethod: "password",
    role: "user",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
    chatPhotoData: null,
    lastChatSeenAt: null,
    chatLastReadMessageId: null,
  };
}
function makeContext(user: User | null, ip = "198.51.100.11"): TrpcContext {
  const req = {
    protocol: "https",
    method: "POST",
    originalUrl: "/api/trpc/twitterCorner",
    ip,
    socket: { remoteAddress: ip },
    headers: {},
  } as unknown as TrpcContext["req"];
  const res = { cookie: vi.fn(), clearCookie: vi.fn() } as unknown as TrpcContext["res"];
  return { req, res, user };
}
function makeSmallJpegDataUrl(): string {
  const bytes = Buffer.from([
    0xff, 0xd8, 0xff, 0xc0, 0x00, 0x0b, 0x08,
    0x00, 0x01, 0x00, 0x01, 0x01, 0x01, 0x11, 0x00,
    0xff, 0xd9,
  ]);
  return `data:image/jpeg;base64,${bytes.toString("base64")}`;
}

const bucketCounts = new Map<string, number>();
beforeEach(() => {
  vi.clearAllMocks();
  bucketCounts.clear();
  vi.stubEnv("TWITTER_CORNER_PASSWORD", testOnlyPassword);
  vi.stubEnv("MANUS_JWT_SECRET", "test-rate-limit-secret-long-enough-0123456789");
  vi.mocked(db.bumpRateLimitBucket).mockImplementation(async input => {
    const count = (bucketCounts.get(input.bucketKey) ?? 0) + 1;
    bucketCounts.set(input.bucketKey, count);
    return { count, resetAt: new Date(Date.now() + input.windowMs) };
  });
});
afterEach(() => vi.unstubAllEnvs());

describe("public global Twitter corner and protected management", () => {
  it("allows public reading but requires a signed-in account to unlock management", async () => {
    const caller = appRouter.createCaller(makeContext(null));
    const item = { id: 3, tweetId: "1234567890123", createdAt: new Date() };
    vi.mocked(db.listHomeTwitterItems).mockResolvedValue([item]);
    await expect(caller.twitterCorner.list()).resolves.toEqual([item]);
    await expect(caller.twitterCorner.unlock({ password: testOnlyPassword })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects a wrong manager password and records distributed rate-limit buckets", async () => {
    const caller = appRouter.createCaller(makeContext(makeUser()));
    await expect(caller.twitterCorner.unlock({ password: "wrong-test-password" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(db.bumpRateLimitBucket).toHaveBeenCalledTimes(2);
  });

  it("issues a short-lived user-bound token and adds only a valid X/Twitter URL", async () => {
    const user = makeUser(41);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    const item = { id: 7, tweetId: "1234567890123", createdAt: new Date() };
    vi.mocked(db.addHomeTwitterItem).mockResolvedValue(item);

    await expect(caller.twitterCorner.add({ managerToken: unlocked.token, url: "https://x.com/study/status/1234567890123?s=20" })).resolves.toEqual(item);
    expect(db.addHomeTwitterItem).toHaveBeenCalledWith(item.tweetId, user.id, true);
    await expect(caller.twitterCorner.add({ managerToken: unlocked.token, url: "https://evil.example/study/status/1234567890123" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(db.addHomeTwitterItem).toHaveBeenCalledTimes(1);
  });

  it("does not accept a token from another account or a forged token", async () => {
    const user = makeUser(51);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    const other = appRouter.createCaller(makeContext(makeUser(52)));
    await expect(other.twitterCorner.add({ managerToken: unlocked.token, url: "https://x.com/study/status/123456789" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.twitterCorner.add({ managerToken: `${unlocked.token}forged`, url: "https://x.com/study/status/123456789" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(db.addHomeTwitterItem).not.toHaveBeenCalled();
  });

  it("imports previous-account tweets only through the manager token and skips shared duplicates", async () => {
    const user = makeUser(56);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    vi.mocked(db.addHomeTwitterItem)
      .mockResolvedValueOnce({ id: 1, tweetId: "123456789", createdAt: new Date() })
      .mockRejectedValueOnce({ code: "ER_DUP_ENTRY" });

    await expect(caller.twitterCorner.importLegacy({
      managerToken: unlocked.token,
      urls: ["https://x.com/study/status/123456789", "https://twitter.com/study/status/987654321"],
    })).resolves.toEqual({ imported: 1 });
    expect(db.addHomeTwitterItem).toHaveBeenNthCalledWith(1, "123456789", user.id);
    expect(db.addHomeTwitterItem).toHaveBeenNthCalledWith(2, "987654321", user.id);
    await expect(caller.twitterCorner.importLegacy({ managerToken: unlocked.token, urls: ["https://evil.example/status/123456"] })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("maps duplicate posts to a conflict and permits token-authorized removal", async () => {
    const user = makeUser(61);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    vi.mocked(db.addHomeTwitterItem).mockRejectedValue({ code: "ER_DUP_ENTRY" });
    await expect(caller.twitterCorner.add({ managerToken: unlocked.token, url: "https://twitter.com/study/status/123456789" })).rejects.toMatchObject({ code: "CONFLICT" });

    vi.mocked(db.deleteHomeTwitterItem).mockResolvedValue(true);
    await expect(caller.twitterCorner.remove({ managerToken: unlocked.token, id: 7 })).resolves.toEqual({ success: true });
    expect(db.deleteHomeTwitterItem).toHaveBeenCalledWith(7);
    vi.mocked(db.deleteHomeTwitterItem).mockResolvedValue(false);
    await expect(caller.twitterCorner.remove({ managerToken: unlocked.token, id: 99 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("public home ticker and protected management", () => {
  it("allows anonymous visitors to read the shared ticker", async () => {
    const guest = appRouter.createCaller(makeContext(null));
    const item = { id: 2, content: "Düzenli çalışma başarıyı getirir.", createdAt: new Date() };
    vi.mocked(db.listHomeTickerItems).mockResolvedValue([item]);
    await expect(guest.homeTicker.list()).resolves.toEqual([item]);
  });

  it("adds, edits and removes shared text only with the password-issued manager token", async () => {
    const user = makeUser(81);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    vi.mocked(db.addHomeTickerItem).mockResolvedValue(undefined);
    vi.mocked(db.updateHomeTickerItem).mockResolvedValue(true);
    vi.mocked(db.deleteHomeTickerItem).mockResolvedValue(true);

    await expect(caller.homeTicker.add({ managerToken: unlocked.token, content: "  Bugün çalıştım.  " })).resolves.toEqual({ success: true });
    expect(db.addHomeTickerItem).toHaveBeenCalledWith("Bugün çalıştım.");
    await expect(caller.homeTicker.update({ managerToken: unlocked.token, id: 4, content: "Yeni metin" })).resolves.toEqual({ success: true });
    expect(db.updateHomeTickerItem).toHaveBeenCalledWith(4, "Yeni metin");
    await expect(caller.homeTicker.remove({ managerToken: unlocked.token, id: 4 })).resolves.toEqual({ success: true });
    expect(db.deleteHomeTickerItem).toHaveBeenCalledWith(4);

    const other = appRouter.createCaller(makeContext(makeUser(82)));
    await expect(other.homeTicker.add({ managerToken: unlocked.token, content: "Yetkisiz yazı" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.homeTicker.add({ managerToken: `${unlocked.token}forged`, content: "Sahte token" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.homeTicker.add({ managerToken: unlocked.token, content: "x".repeat(281) })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("returns not found for ticker text already removed", async () => {
    const user = makeUser(91);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    vi.mocked(db.updateHomeTickerItem).mockResolvedValue(false);
    vi.mocked(db.deleteHomeTickerItem).mockResolvedValue(false);
    await expect(caller.homeTicker.update({ managerToken: unlocked.token, id: 99, content: "metin" })).rejects.toMatchObject({ code: "NOT_FOUND" });
    await expect(caller.homeTicker.remove({ managerToken: unlocked.token, id: 99 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("public home photo and protected management", () => {
  it("allows anonymous visitors to read the shared image", async () => {
    const guest = appRouter.createCaller(makeContext(null));
    vi.mocked(db.getHomeFeaturedPhoto).mockResolvedValue({
      id: 1,
      storageKey: "home-photo/featured_ab12cd34.jpg",
      updatedBy: 101,
      updatedAt: new Date(),
    });
    await expect(guest.homePhoto.current()).resolves.toEqual({ url: "/manus-storage/home-photo/featured_ab12cd34.jpg" });
  });

  it("validates the manager token and image bytes before uploading and replacing the global photo", async () => {
    const user = makeUser(102);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    const imageData = makeSmallJpegDataUrl();
    const expectedKey = "home-photo/featured_ab12cd34.jpg";
    vi.mocked(storage.storagePut).mockResolvedValue({ key: expectedKey, url: `/manus-storage/${expectedKey}` });
    vi.mocked(db.setHomeFeaturedPhoto).mockResolvedValue(undefined);

    await expect(caller.homePhoto.replace({ managerToken: unlocked.token, imageData })).resolves.toEqual({ success: true });
    expect(storage.storagePut).toHaveBeenCalledWith("home-photo/featured.jpg", Buffer.from(imageData.slice("data:image/jpeg;base64,".length), "base64"), "image/jpeg");
    expect(db.setHomeFeaturedPhoto).toHaveBeenCalledWith(expectedKey, user.id);

    const other = appRouter.createCaller(makeContext(makeUser(103)));
    await expect(other.homePhoto.replace({ managerToken: unlocked.token, imageData })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.homePhoto.replace({ managerToken: unlocked.token, imageData: "data:image/jpeg;base64,Zm9v" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(storage.storagePut).toHaveBeenCalledTimes(1);
  });

  it("removes the active database pointer only with the password-issued manager token", async () => {
    const user = makeUser(104);
    const caller = appRouter.createCaller(makeContext(user));
    const unlocked = await caller.twitterCorner.unlock({ password: testOnlyPassword });
    vi.mocked(db.deleteHomeFeaturedPhoto).mockResolvedValue(true);

    await expect(caller.homePhoto.remove({ managerToken: unlocked.token })).resolves.toEqual({ success: true });
    expect(db.deleteHomeFeaturedPhoto).toHaveBeenCalledTimes(1);

    const other = appRouter.createCaller(makeContext(makeUser(105)));
    await expect(other.homePhoto.remove({ managerToken: unlocked.token })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(db.deleteHomeFeaturedPhoto).toHaveBeenCalledTimes(1);
  });
});

describe("shared daily home notes", () => {
  it("shows only the Istanbul-local current day's notes to signed-in members", async () => {
    const dayKey = getIstanbulDayKey();
    const guest = appRouter.createCaller(makeContext(null));
    await expect(guest.dailyNotes.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });

    const caller = appRouter.createCaller(makeContext(makeUser(111)));
    const timestamp = new Date();
    vi.mocked(db.listDailyHomeNotes).mockResolvedValue([{
      id: 8,
      noteDay: dayKey,
      userId: 112,
      content: "Kısa bir günlük not.",
      authorUsername: "ilayda",
      createdAt: timestamp,
      updatedAt: timestamp,
    }]);
    await expect(caller.dailyNotes.list()).resolves.toEqual({
      dayKey,
      notes: [{ id: 8, content: "Kısa bir günlük not.", authorUsername: "ilayda", updatedAt: timestamp, isMine: false }],
    });
  });

  it("lets every member save one trimmed note per day and rejects oversized notes", async () => {
    const user = makeUser(113);
    const caller = appRouter.createCaller(makeContext(user));
    vi.mocked(db.upsertDailyHomeNote).mockResolvedValue(undefined);
    const dayKey = getIstanbulDayKey();

    await expect(caller.dailyNotes.save({ content: "  Bugünkü kısa notum  " })).resolves.toEqual({ success: true, dayKey });
    expect(db.upsertDailyHomeNote).toHaveBeenCalledWith(dayKey, user.id, "Bugünkü kısa notum");
    await expect(caller.dailyNotes.save({ content: "x".repeat(161) })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("allows deletion only of the current-day note owned by that member", async () => {
    const user = makeUser(114);
    const caller = appRouter.createCaller(makeContext(user));
    vi.mocked(db.deleteDailyHomeNote).mockResolvedValue(true);
    await expect(caller.dailyNotes.remove({ id: 15 })).resolves.toEqual({ success: true });
    expect(db.deleteDailyHomeNote).toHaveBeenCalledWith(15, user.id, getIstanbulDayKey());

    vi.mocked(db.deleteDailyHomeNote).mockResolvedValue(false);
    await expect(caller.dailyNotes.remove({ id: 16 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("account-scoped home notifications", () => {
  it("requires a signed-in account and lists only that account's records", async () => {
    const guest = appRouter.createCaller(makeContext(null));
    await expect(guest.notifications.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });

    const user = makeUser(121);
    const caller = appRouter.createCaller(makeContext(user));
    const expected = {
      items: [{
        id: 4,
        kind: "direct_message" as const,
        actorLabel: "ilayda",
        referenceId: 8,
        readAt: null,
        createdAt: new Date(),
        isRead: false,
      }],
      unreadCount: 1,
    };
    vi.mocked(db.listUserNotifications).mockResolvedValue(expected);
    await expect(caller.notifications.list()).resolves.toEqual(expected);
    expect(db.listUserNotifications).toHaveBeenCalledWith(user.id);
  });

  it("marks only the signed-in member's notification as read", async () => {
    const user = makeUser(122);
    const caller = appRouter.createCaller(makeContext(user));
    vi.mocked(db.markUserNotificationRead).mockResolvedValue(true);
    await expect(caller.notifications.markRead({ id: 55 })).resolves.toEqual({ success: true });
    expect(db.markUserNotificationRead).toHaveBeenCalledWith(user.id, 55);

    vi.mocked(db.markUserNotificationRead).mockResolvedValue(false);
    await expect(caller.notifications.markRead({ id: 56 })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(db.markUserNotificationRead).toHaveBeenLastCalledWith(user.id, 56);
  });
});

describe("account-scoped daily wheel", () => {
  it("requires a signed-in account to check or spin the wheel", async () => {
    const guest = appRouter.createCaller(makeContext(null));
    await expect(guest.dailyWheel.today()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(guest.dailyWheel.spin()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("reads the signed-in member's result for the Istanbul-local day", async () => {
    const user = makeUser(131);
    const caller = appRouter.createCaller(makeContext(user));
    vi.mocked(db.getDailyWheelSpin).mockResolvedValue(80);

    await expect(caller.dailyWheel.today()).resolves.toEqual({
      dayKey: getIstanbulDayKey(),
      percentage: 80,
    });
    expect(db.getDailyWheelSpin).toHaveBeenCalledWith(user.id, getIstanbulDayKey());
  });

  it("returns the persisted result when a same-day spin already exists", async () => {
    const user = makeUser(132);
    const caller = appRouter.createCaller(makeContext(user));
    vi.mocked(db.createDailyWheelSpin).mockResolvedValue({ percentage: 70, alreadySpun: true });

    await expect(caller.dailyWheel.spin()).resolves.toEqual({
      dayKey: getIstanbulDayKey(),
      percentage: 70,
      alreadySpun: true,
    });
    expect(db.createDailyWheelSpin).toHaveBeenCalledWith(user.id, getIstanbulDayKey(), expect.any(Number));
    const candidate = vi.mocked(db.createDailyWheelSpin).mock.calls[0][2];
    expect(DAILY_WHEEL_OPTIONS.map(option => option.percentage)).toContain(candidate);
  });
});
