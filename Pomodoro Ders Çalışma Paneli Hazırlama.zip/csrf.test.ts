import { describe, expect, it } from "vitest";
import type { Request } from "express";
import { CSRF_COOKIE_NAME, CSRF_HEADER_NAME } from "../../shared/const";
import { createCsrfToken, validCsrfRequest } from "./csrf";

function makeRequest(cookieToken?: string, headerToken?: string): Request {
  const cookie = cookieToken ? `${CSRF_COOKIE_NAME}=${cookieToken}` : "";
  return {
    headers: { cookie },
    get: (name: string) => name.toLowerCase() === CSRF_HEADER_NAME ? headerToken : undefined,
  } as unknown as Request;
}

describe("double-submit CSRF protection", () => {
  it("accepts only a random token submitted in both cookie and header", () => {
    const token = createCsrfToken();
    expect(token).toMatch(/^[A-Za-z0-9_-]{40,50}$/);
    expect(validCsrfRequest(makeRequest(token, token))).toBe(true);
    expect(validCsrfRequest(makeRequest(token, `${token}x`))).toBe(false);
    expect(validCsrfRequest(makeRequest(token, undefined))).toBe(false);
    expect(validCsrfRequest(makeRequest(undefined, token))).toBe(false);
  });
});
