import { useEffect, useState, type FormEvent } from "react";
import {
  ChevronDown,
  GraduationCap,
  Pencil,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { notifyErayStudyDataChanged } from "@/lib/erayStudyEvents";
import { TYT_SUBJECTS } from "@shared/tyt";

type DesiredProgram = { id: string; name: string; requiredNet: number };
const STORAGE_PREFIX = "odak-paneli/yks-desired-programs/v1/accounts/";
const NAME_LIMIT = 120;
const PROGRAM_LIMIT = 100;
const MAX_NET = TYT_SUBJECTS.reduce(
  (total, subject) => total + subject.questionCount,
  0
);
function makeId() {
  return typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
function readPrograms(key: string): DesiredProgram[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    if (!Array.isArray(value)) return [];
    return value
      .filter(
        (item): item is DesiredProgram =>
          Boolean(item) &&
          typeof item.id === "string" &&
          typeof item.name === "string" &&
          Number.isFinite(item.requiredNet)
      )
      .slice(0, PROGRAM_LIMIT)
      .map(item => ({
        id: item.id.slice(0, 100),
        name: item.name.trim().slice(0, NAME_LIMIT),
        requiredNet: Math.max(0, Math.min(MAX_NET, Number(item.requiredNet))),
      }))
      .filter(item => item.name);
  } catch {
    return [];
  }
}
export default function YksDesiredPrograms() {
  const { user } = useAuth();
  const storageKey =
    user?.id === undefined
      ? null
      : `${STORAGE_PREFIX}${encodeURIComponent(String(user.id))}`;
  const [programs, setPrograms] = useState<DesiredProgram[]>([]);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [name, setName] = useState("");
  const [net, setNet] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  useEffect(() => {
    if (!storageKey) {
      setPrograms([]);
      setLoadedKey(null);
      return;
    }
    setPrograms(readPrograms(storageKey));
    setLoadedKey(storageKey);
    setEditingId(null);
  }, [storageKey]);
  useEffect(() => {
    if (!storageKey || loadedKey !== storageKey) return;
    try {
      const serialized = JSON.stringify(programs);
      if (localStorage.getItem(storageKey) !== serialized) {
        localStorage.setItem(storageKey, serialized);
        notifyErayStudyDataChanged();
      }
    } catch {
      toast.error("Bölümler tarayıcı hafızasına kaydedilemedi.");
    }
  }, [storageKey, loadedKey, programs]);
  const ready = Boolean(storageKey && loadedKey === storageKey);
  const reset = () => {
    setName("");
    setNet("");
    setEditingId(null);
  };
  const save = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const clean = name.trim();
    const targetNet = Number(net);
    if (!clean) {
      toast.error("Bölüm adını yaz.");
      return;
    }
    if (!Number.isFinite(targetNet) || targetNet < 0 || targetNet > MAX_NET) {
      toast.error(`Gerekli TYT neti 0 ile ${MAX_NET} arasında olmalı.`);
      return;
    }
    if (!ready) return;
    if (editingId)
      setPrograms(items =>
        items.map(item =>
          item.id === editingId
            ? {
                ...item,
                name: clean.slice(0, NAME_LIMIT),
                requiredNet: targetNet,
              }
            : item
        )
      );
    else {
      if (programs.length >= PROGRAM_LIMIT) {
        toast.error(`En fazla ${PROGRAM_LIMIT} hedef ekleyebilirsin.`);
        return;
      }
      setPrograms(items => [
        ...items,
        {
          id: makeId(),
          name: clean.slice(0, NAME_LIMIT),
          requiredNet: targetNet,
        },
      ]);
    }
    reset();
  };
  const edit = (program: DesiredProgram) => {
    setEditingId(program.id);
    setName(program.name);
    setNet(String(program.requiredNet));
  };
  return (
    <section className="space-y-4" aria-labelledby="yks-desired-title">
      <button
        type="button"
        aria-expanded={expanded}
        aria-controls="yks-desired-content"
        onClick={() => setExpanded(value => !value)}
        className="group relative mx-auto flex aspect-square w-full max-w-[350px] flex-col items-stretch justify-between gap-4 overflow-hidden rounded-2xl border border-[#bad6d5] bg-gradient-to-br from-[#e6f0f1] via-[#f8fcfc] to-[#e9f2f1] p-5 text-left shadow-[0_22px_48px_-28px_rgba(45,63,86,0.55)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_54px_-28px_rgba(45,63,86,0.65)] motion-reduce:transition-none focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-sage-ink sm:max-w-[380px] sm:rounded-[1.75rem] sm:p-7"
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-10 -top-16 h-64 w-64 rounded-full border border-white/55 bg-white/20 shadow-[0_0_0_18px_rgba(255,255,255,0.12),0_0_0_38px_rgba(255,255,255,0.08)] transition duration-500 motion-reduce:transition-none group-hover:scale-110"
        />
        <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start gap-3">
          <span className="grid h-16 w-16 place-items-center rounded-2xl border border-white/75 bg-white/65 text-[#396466] shadow-sm">
            <GraduationCap className="h-8 w-8" aria-hidden="true" />
          </span>
          <span>
            <span className="mb-2 inline-flex rounded-full border border-white/80 bg-white/60 px-3 py-1 text-[0.65rem] font-bold tracking-[0.18em] text-[#396466]">
              HEDEFLERİN
            </span>
            <span
              id="yks-desired-title"
              className="block font-display text-3xl font-bold leading-tight text-ink sm:text-4xl"
            >
              Girmek İstediğim Bölümler
            </span>
            <span className="mt-2 block text-sm text-ink-faint">
              Kendi hedef bölüm ve TYT netlerini takip et.
            </span>
            <span className="mt-3 flex flex-wrap gap-2">
              <span className="rounded-full border border-white/75 bg-white/65 px-3 py-1 text-xs font-semibold text-[#396466]">
                {programs.length} hedef
              </span>
            </span>
          </span>
        </span>
        <span className="relative z-10 flex w-full items-center justify-between border-t border-[#396466]/15 pt-3">
          <span className="text-xs font-bold tracking-wide text-[#396466]">
            {expanded ? "KAPAT" : "HEDEFLERİ AÇ"}
          </span>
          <span className="grid h-11 w-11 place-items-center rounded-full border border-white/75 bg-white/60 text-[#396466] shadow-md">
            <ChevronDown
              className={`h-5 w-5 transition-transform duration-500 motion-reduce:transition-none ${expanded ? "rotate-180" : ""}`}
              aria-hidden="true"
            />
          </span>
        </span>
      </button>
      <div
        id="yks-desired-content"
        aria-hidden={!expanded}
        inert={!expanded}
        className={`grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.22,0.8,0.3,1)] motion-reduce:transition-none ${expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
      >
        <div className="min-h-0 overflow-hidden">
          {expanded && (
            <div className="yks-panel-open rounded-2xl border border-[#bad6d5] bg-white/55 p-4 shadow-[0_24px_55px_-35px_rgba(45,63,86,0.5)] sm:p-6">
              <header className="mb-5">
                <p className="smallcaps text-[#396466]">
                  KENDİ HEDEFLERİNİ OLUŞTUR
                </p>
                <h2 className="mt-1 font-display text-2xl font-bold text-ink">
                  Bölüm hedeflerin
                </h2>
                <p className="mt-1 text-sm text-ink-faint">
                  Bu listeye yalnızca kendi belirlediğin bölüm ve net hedefleri
                  eklenir.
                </p>
              </header>
              <form
                onSubmit={save}
                className="mb-5 grid gap-3 rounded-xl border border-[#dce7e4] bg-white/75 p-4 sm:grid-cols-[minmax(0,1fr)_12rem_auto] sm:items-end"
                aria-label="İstenen bölümü ekle veya düzenle"
              >
                <label className="min-w-0">
                  <span className="mb-1.5 block text-xs font-semibold text-ink-soft">
                    Bölüm / program adı
                  </span>
                  <input
                    value={name}
                    onChange={e => setName(e.target.value)}
                    maxLength={NAME_LIMIT}
                    disabled={!ready}
                    placeholder="Örn. Bilgisayar Mühendisliği"
                    className="h-11 w-full rounded-lg border border-[#d4ddd7] bg-white px-3 text-sm text-ink outline-none focus:border-[#6e9c8c] focus:ring-2 focus:ring-[#6e9c8c]/15 disabled:opacity-50"
                  />
                </label>
                <label className="min-w-0">
                  <span className="mb-1.5 block text-xs font-semibold text-ink-soft">
                    Gerekli toplam TYT neti
                  </span>
                  <input
                    type="number"
                    min="0"
                    max={MAX_NET}
                    step="0.01"
                    value={net}
                    onChange={e => setNet(e.target.value)}
                    disabled={!ready}
                    placeholder="Örn. 85.5"
                    className="h-11 w-full rounded-lg border border-[#d4ddd7] bg-white px-3 text-sm tabular-nums text-ink outline-none focus:border-[#6e9c8c] focus:ring-2 focus:ring-[#6e9c8c]/15 disabled:opacity-50"
                  />
                </label>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    disabled={!ready || !name.trim() || net === ""}
                    className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-[#526f91] to-[#5a8875] px-4 text-sm font-bold text-white disabled:opacity-50"
                  >
                    <Plus className="h-4 w-4" aria-hidden="true" />
                    {editingId ? "Kaydet" : "Ekle"}
                  </button>
                  {editingId && (
                    <button
                      type="button"
                      onClick={reset}
                      aria-label="Düzenlemeyi iptal et"
                      className="grid h-11 w-11 place-items-center rounded-lg border border-[#d4ddd7] text-ink-soft"
                    >
                      <X className="h-4 w-4" aria-hidden="true" />
                    </button>
                  )}
                </div>
              </form>
              <div className="mb-3 flex items-baseline justify-between gap-3">
                <h3 className="font-display text-lg font-bold text-ink">
                  Kaydedilen hedefler
                </h3>
                <span className="text-xs text-ink-faint">
                  {programs.length} / {PROGRAM_LIMIT}
                </span>
              </div>
              {programs.length === 0 ? (
                <p className="rounded-xl bg-white/60 px-4 py-5 text-center text-sm text-ink-faint">
                  Henüz bölüm hedefi eklenmedi.
                </p>
              ) : (
                <ul className="space-y-2">
                  {programs.map(program => (
                    <li
                      key={program.id}
                      className="flex flex-col gap-3 rounded-xl border border-[#dfe5dd] bg-white/75 p-3 sm:flex-row sm:items-center sm:justify-between sm:px-4"
                    >
                      <div className="min-w-0">
                        <h4 className="break-words font-semibold text-ink">
                          {program.name}
                        </h4>
                        <p className="mt-1 text-sm text-ink-faint">
                          Hedef:{" "}
                          <strong className="tabular-nums text-[#4c7564]">
                            {program.requiredNet.toLocaleString("tr-TR", {
                              maximumFractionDigits: 2,
                            })}{" "}
                            net
                          </strong>{" "}
                          toplam TYT
                        </p>
                      </div>
                      <div className="flex shrink-0 gap-2">
                        <button
                          type="button"
                          onClick={() => edit(program)}
                          disabled={!ready}
                          aria-label={`${program.name} hedefini düzenle`}
                          className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#d4ddd7] bg-white px-3 text-sm font-semibold text-ink-soft hover:bg-[#f1f4ec]"
                        >
                          <Pencil className="h-4 w-4" aria-hidden="true" />
                          Düzenle
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setPrograms(items =>
                              items.filter(item => item.id !== program.id)
                            )
                          }
                          disabled={!ready}
                          aria-label={`${program.name} hedefini sil`}
                          className="grid h-10 w-10 place-items-center rounded-lg border border-[#eed4ce] bg-white text-[#985343] hover:bg-[#fff7f4]"
                        >
                          <Trash2 className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
