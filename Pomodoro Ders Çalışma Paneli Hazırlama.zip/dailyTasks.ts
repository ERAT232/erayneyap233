import type { PublicErayDailyTask } from "./erayStudyData";

export function normalizeDailyTasksForDay(
  tasks: PublicErayDailyTask[],
  todayKey: string
): PublicErayDailyTask[] {
  let changed = false;
  const next = tasks.map(task => {
    if (task.completedOn === null || task.completedOn === todayKey) return task;
    changed = true;
    return { ...task, completedOn: null };
  });
  return changed ? next : tasks;
}

export function countCompletedDailyTasks(
  tasks: PublicErayDailyTask[],
  todayKey: string
): number {
  return tasks.reduce(
    (count, task) => count + Number(task.completedOn === todayKey),
    0
  );
}

export function resolveDailyTasksForSnapshot(
  incoming: PublicErayDailyTask[] | undefined,
  existing: PublicErayDailyTask[] | undefined
): PublicErayDailyTask[] {
  return incoming === undefined ? (existing ?? []) : incoming;
}
