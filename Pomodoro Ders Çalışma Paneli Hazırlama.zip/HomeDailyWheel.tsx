import { createPortal } from "react-dom";
import { useEffect, useRef, useState } from "react";
import { Check, LoaderCircle, X } from "lucide-react";
import { toast } from "sonner";
import { DAILY_WHEEL_OPTIONS } from "../../../shared/dailyWheel";
import { trpc } from "@/lib/trpc";

const WHEEL_COLORS = ["#f6dea1", "#f3c8b4", "#e9d4a7", "#d7e3cc", "#f4b7a7", "#c6d8ed", "#f1d18f", "#dfc5df", "#e7b9ba", "#b9d6b8"];
const SPIN_DURATION_MS = 5_500;
const WHEEL_BACKGROUND = `conic-gradient(${DAILY_WHEEL_OPTIONS.map((_, index) => {
  const start = index * 36;
  return `${WHEEL_COLORS[index]} ${start}deg ${start + 36}deg`;
}).join(", ")})`;

function targetRotation(percentage: number, currentRotation: number) {
  const index = DAILY_WHEEL_OPTIONS.findIndex(option => option.percentage === percentage);
  if (index < 0) return currentRotation;
  const segmentCenter = index * 36 + 18;
  const normalizedCurrent = ((currentRotation % 360) + 360) % 360;
  const adjustment = (360 - segmentCenter - normalizedCurrent + 720) % 360;
  return currentRotation + 6 * 360 + adjustment;
}

export default function HomeDailyWheel() {
  const [isOpen, setIsOpen] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [localSpin, setLocalSpin] = useState<{ dayKey: string; percentage: number } | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const completionTimerRef = useRef<number | null>(null);
  const utils = trpc.useUtils();
  const today = trpc.dailyWheel.today.useQuery(undefined, {
    refetchInterval: 15_000,
    refetchOnWindowFocus: true,
  });
  const spin = trpc.dailyWheel.spin.useMutation();
  const dayKey = today.data?.dayKey ?? null;
  const localResult = localSpin && localSpin.dayKey === dayKey ? localSpin.percentage : null;
  const storedResult = today.data?.percentage ?? null;
  const result = localResult ?? storedResult;
  const restoringStoredResult = storedResult !== null && localResult === null && !isAnimating;
  const displayedRotation = restoringStoredResult ? targetRotation(storedResult, 0) : rotation;

  useEffect(() => {
    if (!isOpen) return;
    const previousOverflow = document.body.style.overflow;
    const focusFrame = window.requestAnimationFrame(() => closeRef.current?.focus());
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeDialog();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.cancelAnimationFrame(focusFrame);
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [isOpen]);

  useEffect(() => () => {
    if (completionTimerRef.current !== null) window.clearTimeout(completionTimerRef.current);
  }, []);

  const closeDialog = () => {
    setIsOpen(false);
    window.requestAnimationFrame(() => triggerRef.current?.focus());
  };

  const openDialog = () => {
    setIsOpen(true);
    void today.refetch();
  };

  const spinWheel = async () => {
    if (result !== null || spin.isPending || isAnimating || today.isLoading || today.isError) return;
    try {
      const response = await spin.mutateAsync();
      setLocalSpin({ dayKey: response.dayKey, percentage: response.percentage });
      if (response.alreadySpun) {
        setRotation(targetRotation(response.percentage, 0));
        await utils.dailyWheel.today.invalidate();
        return;
      }

      setRotation(current => targetRotation(response.percentage, current));
      setIsAnimating(true);
      completionTimerRef.current = window.setTimeout(() => {
        setIsAnimating(false);
        void utils.dailyWheel.today.invalidate();
      }, SPIN_DURATION_MS);
    } catch (error) {
      toast.error("Günün çarkı çevrilemedi", {
        description: error instanceof Error ? error.message : "Biraz sonra yeniden dene.",
      });
    }
  };

  const openResult = result !== null && !isAnimating;
  const currentLabel = openResult ? `Bugünkü sonucun: %${result}` : null;
  const wheelLabels = DAILY_WHEEL_OPTIONS.map((option, index) => {
    const angle = ((index * 36 + 18) * Math.PI) / 180;
    const radius = 102;
    return {
      ...option,
      left: `calc(50% + ${Math.sin(angle) * radius}px)`,
      top: `calc(50% - ${Math.cos(angle) * radius}px)`,
    };
  });

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={openDialog}
        aria-haspopup="dialog"
        aria-expanded={isOpen}
        aria-controls="home-daily-wheel-dialog"
        aria-label={result === null ? "Eray bugün seni ne kadar seviyor çarkını aç" : `Eray bugün seni ne kadar seviyor çarkını aç. Bugünkü sonuç yüzde ${result}`}
        title="Eray bugün seni ne kadar seviyor"
        className="relative grid h-10 w-10 shrink-0 place-items-center rounded-full border border-[#d5b76f] bg-[#fffaf0] shadow-[0_5px_12px_-8px_rgba(60,40,15,0.7)] transition hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-ink"
      >
        <span className="daily-wheel-emblem relative grid h-7 w-7 place-items-center rounded-full border border-white/80" aria-hidden="true">
          <span className="absolute h-2.5 w-2.5 rounded-full border border-white bg-[#fffaf0] shadow-sm" />
        </span>
        {result !== null && <span className="absolute -right-0.5 -top-0.5 grid h-4 w-4 place-items-center rounded-full border border-white bg-[#55785c] text-white"><Check className="h-2.5 w-2.5" aria-hidden="true" /></span>}
      </button>

      {isOpen && typeof document !== "undefined" && createPortal(
        <div
          className="daily-wheel-backdrop fixed inset-0 z-[95] grid place-items-center bg-[rgba(28,20,12,0.62)] p-3 backdrop-blur-[3px] sm:p-6"
          onMouseDown={event => {
            if (event.target === event.currentTarget) closeDialog();
          }}
        >
          <section
            id="home-daily-wheel-dialog"
            className="daily-wheel-dialog relative flex max-h-[94vh] w-full max-w-lg flex-col items-center overflow-y-auto rounded-md border border-[#d5c49b] bg-[#fffaf0] px-4 py-4 shadow-[0_24px_80px_rgba(20,14,8,0.4)] sm:px-6 sm:py-5"
            role="dialog"
            aria-modal="true"
            aria-labelledby="home-daily-wheel-title"
          >
            <header className="mb-3 flex w-full items-start gap-3 border-b border-[rgba(90,66,34,0.15)] pb-3">
              <div className="min-w-0 flex-1">
                <h2 id="home-daily-wheel-title" className="font-display text-lg font-semibold text-ink">Eray bugün seni ne kadar seviyor</h2>
              </div>
              <button
                ref={closeRef}
                type="button"
                onClick={closeDialog}
                aria-label="Şans çarkını kapat"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-[rgba(90,66,34,0.2)] bg-white/70 text-ink-faint transition hover:bg-white hover:text-ink focus-visible:outline-2 focus-visible:outline-amber-ink"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </header>

            {today.isError ? (
              <div className="my-5 text-center">
                <p className="text-sm text-destructive" role="alert">Bugünkü çark durumu yüklenemedi.</p>
                <button type="button" onClick={() => void today.refetch()} className="mt-2 rounded-sm px-3 py-1.5 text-xs font-semibold text-amber-ink underline">Yeniden dene</button>
              </div>
            ) : (
              <>
                <div className="relative my-2 grid h-72 w-72 shrink-0 place-items-center sm:h-80 sm:w-80" aria-label="Çarkta 10, 20, 30, 40, 50, 60, 70, 80, 90 ve 100 yüzde seçenekleri bulunur.">
                  <span className="absolute left-1/2 top-0 z-20 h-0 w-0 -translate-x-1/2 border-l-[11px] border-r-[11px] border-t-[22px] border-l-transparent border-r-transparent border-t-[#8e3e20] drop-shadow-sm" aria-hidden="true" />
                  <div
                    className={`daily-wheel-disk relative h-64 w-64 rounded-full border-[7px] border-[#fffaf0] shadow-[0_8px_24px_rgba(74,54,25,0.25)] sm:h-72 sm:w-72 ${isAnimating ? "daily-wheel-disk-active" : ""}`}
                    style={{
                      background: WHEEL_BACKGROUND,
                      transform: `rotate(${displayedRotation}deg)`,
                      ...(restoringStoredResult ? { transition: "none" } : {}),
                    }}
                    role="img"
                    aria-label="Eşit dilimlerde yüzde 10 ile yüzde 100 arasındaki on sonuç"
                  >
                    {wheelLabels.map((option, index) => (
                      <span
                        key={option.percentage}
                        className="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/70 bg-white/35 px-1.5 py-0.5 text-[10px] font-bold tabular-nums text-[#453a2a] shadow-sm sm:text-xs"
                        style={{ left: option.left, top: option.top }}
                        aria-hidden="true"
                      >
                        %{option.percentage}
                      </span>
                    ))}
                    <span className="absolute left-1/2 top-1/2 z-10 h-11 w-11 -translate-x-1/2 -translate-y-1/2 rounded-full border-[4px] border-[#fffaf0] bg-[#8e3e20] shadow-[0_2px_8px_rgba(50,30,10,0.35)]" aria-hidden="true" />
                  </div>
                </div>

                <p className="min-h-6 text-center text-sm font-semibold text-ink" aria-live="polite" role="status">
                  {isAnimating ? "Çark dönüyor…" : currentLabel ?? (spin.isPending ? "Sonuç hazırlanıyor…" : "Hazırsan çarkı çevir.")}
                </p>

                {today.data?.dayKey && <time className="mt-1 text-[11px] text-ink-faint">{today.data.dayKey} · Türkiye saati</time>}

                <button
                  ref={undefined}
                  type="button"
                  onClick={() => void spinWheel()}
                  disabled={result !== null || isAnimating || spin.isPending || today.isLoading || today.isError}
                  className="mt-3 inline-flex h-10 items-center justify-center gap-2 rounded-full border border-[#8e3e20] bg-[#8e3e20] px-5 text-sm font-semibold text-[#fffaf0] shadow-sm transition hover:-translate-y-0.5 hover:bg-[#713019] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {spin.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" /> : result !== null ? <Check className="h-4 w-4" aria-hidden="true" /> : null}
                  {spin.isPending ? "Hazırlanıyor…" : result !== null ? "Bugün çevrildi" : "Çarkı çevir"}
                </button>

                {today.isLoading && <p className="mt-2 text-xs text-ink-faint" role="status">Bugünün hakkı kontrol ediliyor…</p>}
              </>
            )}
          </section>
        </div>,
        document.body,
      )}
    </>
  );
}
