import { FormEvent, useEffect, useRef, useState } from "react";
import { CheckCheck, Copy, ImagePlus, LoaderCircle, MessageCircle, Plus, Send, Trash2, UserRound, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type ChatParticipant = {
  id: number;
  chatUserId: string;
  username: string;
  profilePhoto: string | null;
  lastSeenAt?: Date | string | null;
  lastReadMessageId?: number | null;
};

type ChatMessage = {
  id: number;
  senderId: number;
  username: string;
  message: string;
  hasImage: boolean;
  deletedAt: Date | string | null;
  createdAt: Date | string;
};

type ConversationListItem = {
  id: number;
  peer: Pick<ChatParticipant, "chatUserId" | "username" | "profilePhoto">;
  peerLastReadMessageId: number | null;
  peerLastSeenAt: Date | string | null;
  lastMessage: ChatMessage | null;
};

type OpenConversation = {
  id: number;
  me: ChatParticipant;
  peer: ChatParticipant;
  messages: ChatMessage[];
};

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

function compressChatImage(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) return Promise.reject(new Error("Yalnızca görsel dosyaları gönderilebilir."));
  if (file.size > 12 * 1024 * 1024) return Promise.reject(new Error("Seçilen görsel en fazla 12 MB olabilir."));
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Bu görsel açılamadı. JPEG, PNG veya WebP deneyebilirsin."));
    };
    image.onload = () => {
      URL.revokeObjectURL(url);
      try {
        const scale = Math.min(1, 1600 / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext("2d");
        if (!context) throw new Error("Görsel dönüştürülemedi.");
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        let quality = 0.84;
        let dataUrl = canvas.toDataURL("image/jpeg", quality);
        while ((dataUrl.length - 23) * 0.75 > MAX_IMAGE_BYTES && quality > 0.48) {
          quality -= 0.08;
          dataUrl = canvas.toDataURL("image/jpeg", quality);
        }
        if ((dataUrl.length - 23) * 0.75 > MAX_IMAGE_BYTES) throw new Error("Görsel 3 MB sınırının altına sıkıştırılamadı.");
        resolve(dataUrl);
      } catch (error) {
        reject(error instanceof Error ? error : new Error("Görsel dönüştürülemedi."));
      }
    };
    image.src = url;
  });
}

function ChatImage({ conversationId, messageId, username }: { conversationId: number; messageId: number; username: string }) {
  const imageQuery = trpc.chat.image.useQuery(
    { conversationId, messageId },
    { staleTime: Infinity, refetchOnWindowFocus: false, retry: false },
  );
  if (imageQuery.isLoading) return <div className="my-1 h-32 w-48 animate-pulse rounded-xl bg-black/10" aria-label="Görsel yükleniyor" />;
  if (!imageQuery.data?.imageData) return <p className="my-1 text-xs text-[#7a5a4e]">Görsel yüklenemedi.</p>;
  return <img src={imageQuery.data.imageData} alt={`${username} tarafından gönderilen görsel`} loading="lazy" className="my-1 max-h-72 max-w-full rounded-xl object-contain" />;
}

function ParticipantAvatar({
  participant,
  size = "h-11 w-11",
}: {
  participant: Pick<ChatParticipant, "username" | "profilePhoto"> | null | undefined;
  size?: string;
}) {
  return (
    <span className={`grid ${size} shrink-0 place-items-center overflow-hidden rounded-full bg-[#d7eee8] text-[#075e54] ring-1 ring-black/5`}>
      {participant?.profilePhoto ? (
        <img src={participant.profilePhoto} alt={`${participant.username} profil fotoğrafı`} className="h-full w-full object-cover" />
      ) : (
        <UserRound className="h-5 w-5" strokeWidth={1.6} aria-hidden="true" />
      )}
    </span>
  );
}

function formatTime(value: Date | string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
}

function lastSeenLabel(value: Date | string | null | undefined): string {
  if (!value) return "Henüz bu sohbete girmedi";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Son görülme bilgisi yok";
  return `son görülme ${date.toLocaleString("tr-TR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

export default function MemberChat() {
  const [draft, setDraft] = useState("");
  const [attachmentData, setAttachmentData] = useState<string | null>(null);
  const [attachmentName, setAttachmentName] = useState("");
  const [compressingAttachment, setCompressingAttachment] = useState(false);
  const [targetId, setTargetId] = useState("");
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(() => {
    const rawConversationId = new URLSearchParams(window.location.search).get("conversation");
    const conversationId = Number(rawConversationId);
    return rawConversationId && Number.isSafeInteger(conversationId) && conversationId > 0 ? conversationId : null;
  });
  const [followLatest, setFollowLatest] = useState(true);
  const addIdInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const enteredConversation = useRef<number | null>(null);
  const markedReadThrough = useRef(0);
  const utils = trpc.useUtils();
  const identityQuery = trpc.chat.identity.useQuery();
  const conversationsQuery = trpc.chat.list.useQuery(undefined, {
    refetchInterval: 3_000,
    refetchOnWindowFocus: true,
  });
  const conversationQuery = trpc.chat.open.useQuery(
    { conversationId: selectedConversationId ?? 0 },
    {
      enabled: selectedConversationId !== null,
      refetchInterval: 3_000,
      refetchOnWindowFocus: true,
    },
  );
  const enterConversation = trpc.chat.enter.useMutation();
  const markRead = trpc.chat.markRead.useMutation({
    onSuccess: async () => {
      await utils.chat.open.invalidate();
      await utils.chat.list.invalidate();
    },
  });
  const startConversation = trpc.chat.start.useMutation({
    onSuccess: async result => {
      setTargetId("");
      setSelectedConversationId(result.id);
      enteredConversation.current = null;
      markedReadThrough.current = 0;
      await utils.chat.list.invalidate();
    },
  });
  const sendMessage = trpc.chat.send.useMutation({
    onSuccess: async () => {
      setDraft("");
      setAttachmentData(null);
      setAttachmentName("");
      await utils.chat.open.invalidate();
      await utils.chat.list.invalidate();
    },
  });
  const hideConversation = trpc.chat.hide.useMutation({
    onSuccess: async (_result, variables) => {
      if (selectedConversationId === variables.conversationId) setSelectedConversationId(null);
      enteredConversation.current = null;
      markedReadThrough.current = 0;
      setDraft("");
      setAttachmentData(null);
      setAttachmentName("");
      await Promise.all([utils.chat.list.invalidate(), utils.chat.open.invalidate()]);
      toast.success("Sohbet yalnızca senin listenden kaldırıldı");
    },
    onError: error => toast.error("Sohbet kaldırılamadı", { description: error.message }),
  });

  const deleteMessage = trpc.chat.deleteMessage.useMutation({
    onSuccess: async () => {
      await utils.chat.open.invalidate();
      await utils.chat.list.invalidate();
      toast.success("Mesaj silindi");
    },
    onError: error => toast.error("Mesaj silinemedi", { description: error.message }),
  });

  const conversations = (conversationsQuery.data ?? []) as ConversationListItem[];
  const conversation = conversationQuery.data as OpenConversation | undefined;
  const messages = conversation?.messages ?? [];
  const latestMessageId = messages[messages.length - 1]?.id;

  useEffect(() => {
    if (!conversationsQuery.isSuccess || selectedConversationId === null) return;
    if (!conversations.some(item => item.id === selectedConversationId)) {
      setSelectedConversationId(null);
      enteredConversation.current = null;
      markedReadThrough.current = 0;
      setDraft("");
      setAttachmentData(null);
      setAttachmentName("");
    }
  }, [conversationsQuery.isSuccess, conversations, selectedConversationId]);

  useEffect(() => {
    if (selectedConversationId === null || enteredConversation.current === selectedConversationId) return;
    enteredConversation.current = selectedConversationId;
    enterConversation.mutate({ conversationId: selectedConversationId });
  }, [selectedConversationId]);

  useEffect(() => {
    if (!conversationQuery.isSuccess || selectedConversationId === null || !latestMessageId) return;
    if (latestMessageId <= markedReadThrough.current) return;
    markedReadThrough.current = latestMessageId;
    markRead.mutate({ conversationId: selectedConversationId, messageId: latestMessageId });
  }, [conversationQuery.isSuccess, selectedConversationId, latestMessageId]);

  useEffect(() => {
    const list = listRef.current;
    if (list && followLatest) list.scrollTop = list.scrollHeight;
  }, [latestMessageId, messages.length, followLatest]);

  const submitAdd = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const id = targetId.trim();
    if (!id || startConversation.isPending) return;
    if (id === identityQuery.data?.chatUserId) {
      toast.error("Kendi ID'nle sohbet başlatamazsın.");
      return;
    }
    startConversation.mutate({ chatUserId: id });
  };

  const submitMessage = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const message = draft.trim();
    if ((!message && !attachmentData) || !selectedConversationId || sendMessage.isPending || compressingAttachment) return;
    sendMessage.mutate({
      conversationId: selectedConversationId,
      message: message || undefined,
      imageData: attachmentData ?? undefined,
    });
  };

  const selectImage = async (file: File | undefined) => {
    if (!file) return;
    setCompressingAttachment(true);
    try {
      const dataUrl = await compressChatImage(file);
      setAttachmentData(dataUrl);
      setAttachmentName(file.name || "Görsel");
    } catch (error) {
      toast.error("Görsel eklenemedi", { description: error instanceof Error ? error.message : "Başka bir görsel deneyin." });
    } finally {
      setCompressingAttachment(false);
      if (imageInputRef.current) imageInputRef.current.value = "";
    }
  };

  const confirmHideConversation = (conversationId: number, username: string) => {
    if (hideConversation.isPending) return;
    if (!window.confirm(`“${username}” ile sohbeti yalnızca kendi sohbet listenden kaldırmak istiyor musun? Mesajlar karşı taraf için silinmez.`)) return;
    hideConversation.mutate({ conversationId });
  };

  const confirmDelete = (messageId: number) => {
    if (!selectedConversationId || deleteMessage.isPending) return;
    if (!window.confirm("Bu mesajı iki katılımcı için silmek istiyor musun?")) return;
    deleteMessage.mutate({ conversationId: selectedConversationId, messageId });
  };

  const copyChatId = async () => {
    const chatUserId = identityQuery.data?.chatUserId;
    if (!chatUserId) return;
    try {
      await navigator.clipboard.writeText(chatUserId);
      toast.success("Sohbet ID'si kopyalandı");
    } catch {
      toast.error("ID kopyalanamadı", { description: "ID'yi seçip elle kopyalayabilirsin." });
    }
  };

  const sendError = sendMessage.error?.message.includes("Kısa sürede")
    ? sendMessage.error.message
    : sendMessage.error
      ? "Mesaj gönderilemedi. Bu sohbete erişim olmayabilir; tekrar dene."
      : null;
  const addError = startConversation.error?.message ?? null;

  return (
    <section className="mx-auto mt-8 w-full max-w-5xl overflow-hidden rounded-[1.35rem] border border-[#d6ddd8] bg-white shadow-[0_20px_70px_rgba(23,55,48,0.18)]">
      <header className="flex items-center justify-between gap-3 bg-[#075e54] px-4 py-4 text-white sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white/15 ring-1 ring-white/25">
            <MessageCircle className="h-5 w-5" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <h2 className="truncate font-display text-lg font-bold">Sohbetler</h2>
            <p className="truncate text-xs text-white/80">ID ile özel sohbet başlat</p>
          </div>
        </div>
        <span className="shrink-0 rounded-full border border-white/25 bg-white/10 px-2.5 py-1 text-[0.65rem] font-medium text-white/90">
          {conversations.length} sohbet
        </span>
      </header>

      <div className="grid min-h-[34rem] md:grid-cols-[19rem_minmax(0,1fr)]">
        <aside className="flex flex-col border-b border-[#dce2de] bg-[#f8faf9] md:border-r md:border-b-0">
          <div className="border-b border-[#e1e7e3] px-4 py-4">
            <p className="text-[0.68rem] font-bold uppercase tracking-[0.13em] text-[#66716c]">Senin sohbet ID'n</p>
            <div className="mt-2 flex items-center gap-2 rounded-xl border border-[#dce2de] bg-white px-3 py-2">
              <code className="min-w-0 flex-1 truncate text-sm font-semibold tracking-wide text-[#075e54]">
                {identityQuery.data?.chatUserId ?? (identityQuery.isLoading ? "Yükleniyor…" : "ID alınamadı")}
              </code>
              <button
                type="button"
                onClick={() => void copyChatId()}
                disabled={!identityQuery.data?.chatUserId}
                aria-label="Sohbet ID'sini kopyala"
                title="ID'yi kopyala"
                className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[#596861] transition hover:bg-[#edf4f1] hover:text-[#075e54] disabled:opacity-40"
              >
                <Copy className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="border-b border-[#e1e7e3] px-4 py-4">
            <button
              type="button"
              onClick={() => addIdInputRef.current?.focus()}
              className="mb-2 flex items-center gap-2 text-sm font-bold text-[#34423c] hover:text-[#075e54]"
            >
              <Plus className="h-4 w-4 text-[#128c7e]" /> Sohbet ekle
            </button>
            <form onSubmit={submitAdd} className="space-y-2">
              <label htmlFor="chat-add-id" className="sr-only">Kullanıcının sohbet ID'si</label>
              <input
                ref={addIdInputRef}
                id="chat-add-id"
                value={targetId}
                onChange={event => setTargetId(event.target.value)}
                maxLength={16}
                autoCapitalize="none"
                autoComplete="off"
                placeholder="Sohbet ID'sini gir"
                className="h-10 w-full rounded-lg border border-[#d6ddd8] bg-white px-3 text-sm text-[#303b35] outline-none placeholder:text-[#929d97] focus:border-[#128c7e]/60 focus:ring-2 focus:ring-[#128c7e]/10"
              />
              <Button
                type="submit"
                disabled={!targetId.trim() || startConversation.isPending}
                className="h-9 w-full rounded-lg bg-[#128c7e] text-white hover:bg-[#075e54]"
              >
                {startConversation.isPending ? <LoaderCircle className="mr-2 h-4 w-4 animate-spin" /> : null}
                Sohbet başlat
              </Button>
              {addError && <p role="status" className="text-xs leading-relaxed text-[#9b4434]">{addError}</p>}
            </form>
          </div>

          <div className="px-3 py-3">
            <p className="px-2 pb-2 text-[0.67rem] font-bold uppercase tracking-[0.12em] text-[#7b8780]">Sohbet listen</p>
            {conversationsQuery.isLoading ? (
              <div className="flex items-center gap-2 px-2 py-3 text-sm text-[#66716c]"><LoaderCircle className="h-4 w-4 animate-spin" /> Yükleniyor…</div>
            ) : conversations.length === 0 ? (
              <p className="rounded-lg px-2 py-3 text-sm leading-relaxed text-[#758079]">Henüz sohbet yok. Bir kullanıcının ID'sini girerek sohbet başlat.</p>
            ) : (
              <ul className="space-y-1">
                {conversations.map(item => (
                  <li key={item.id} className="relative pr-7">
                    <button
                      type="button"
                      onClick={() => {
                        if (selectedConversationId !== item.id) {
                          setSelectedConversationId(item.id);
                          enteredConversation.current = null;
                          markedReadThrough.current = 0;
                        }
                      }}
                      aria-current={selectedConversationId === item.id ? "page" : undefined}
                      className={`flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition ${selectedConversationId === item.id ? "bg-[#e0f2ed]" : "hover:bg-[#edf4f1]"}`}
                    >
                      <ParticipantAvatar participant={item.peer} size="h-10 w-10" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-[#34423c]">{item.peer.username}</span>
                        <span className="block truncate text-xs text-[#758079]">{item.lastMessage?.message || (item.lastMessage?.hasImage ? "Görsel" : "Sohbet başlatıldı")}</span>
                      </span>
                      {item.lastMessage && <time className="shrink-0 text-[0.62rem] text-[#87918b]">{formatTime(item.lastMessage.createdAt)}</time>}
                    </button>
                    <button
                      type="button"
                      onClick={() => confirmHideConversation(item.id, item.peer.username)}
                      disabled={hideConversation.isPending}
                      aria-label={`${item.peer.username} sohbetini kendi listemden kaldır`}
                      title="Sohbeti yalnızca kendi listenden kaldır"
                      className="absolute right-1 top-1 grid h-7 w-7 place-items-center rounded-full text-[#758079] hover:bg-white hover:text-[#9b4434] disabled:opacity-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </aside>

        <div className="flex min-h-[26rem] min-w-0 flex-col">
          {selectedConversationId === null ? (
            <div className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center">
              <span className="grid h-14 w-14 place-items-center rounded-full bg-[#d9fdd3] text-[#075e54] shadow-sm"><MessageCircle className="h-6 w-6" /></span>
              <h3 className="mt-4 font-display text-xl font-semibold text-[#34423c]">Özel sohbetini başlat</h3>
              <p className="mt-2 max-w-sm text-sm leading-relaxed text-[#6a756f]">Sol taraftaki “Sohbet ekle” alanına bir kullanıcının sohbet ID'sini gir. Kendi ID'ni de paylaşarak bulunmanı sağlayabilirsin.</p>
              <Button type="button" onClick={() => addIdInputRef.current?.focus()} className="mt-5 rounded-lg bg-[#128c7e] text-white hover:bg-[#075e54]">
                <Plus className="mr-2 h-4 w-4" /> Sohbet ekle
              </Button>
            </div>
          ) : conversationQuery.isLoading ? (
            <div className="flex flex-1 items-center justify-center gap-2 text-sm text-[#66716c]"><LoaderCircle className="h-4 w-4 animate-spin" /> Sohbet açılıyor…</div>
          ) : conversationQuery.isError || !conversation ? (
            <div className="flex flex-1 items-center justify-center px-6 text-center text-sm text-[#8f3f30]">Bu sohbet yüklenemedi veya erişimin yok.</div>
          ) : (
            <>
              <header className="flex items-center gap-3 border-b border-[#dce2de] bg-white px-4 py-3 sm:px-5">
                <ParticipantAvatar participant={conversation.peer} size="h-10 w-10" />
                <div className="min-w-0">
                  <h3 className="truncate font-display text-base font-bold text-[#34423c]">{conversation.peer.username}</h3>
                  <p className="truncate text-xs text-[#718078]">{lastSeenLabel(conversation.peer.lastSeenAt)}</p>
                </div>
              </header>

              <div
                ref={listRef}
                role="log"
                aria-label={`${conversation.peer.username} ile sohbet mesajları`}
                aria-live="polite"
                className="flex-1 space-y-2.5 overflow-y-auto bg-[#efeae2] px-3 py-5 sm:px-6"
                style={{
                  minHeight: "18rem",
                  maxHeight: "min(55vh, 30rem)",
                  backgroundImage: "radial-gradient(circle at 18px 18px, rgba(7,94,84,0.055) 1.5px, transparent 2px), radial-gradient(circle at 40px 40px, rgba(7,94,84,0.035) 1px, transparent 1.5px)",
                  backgroundSize: "56px 56px",
                }}
                onScroll={event => {
                  const element = event.currentTarget;
                  setFollowLatest(element.scrollHeight - element.scrollTop - element.clientHeight < 96);
                }}
              >
                {messages.length === 0 ? (
                  <div className="flex h-full flex-col items-center justify-center text-center">
                    <span className="grid h-12 w-12 place-items-center rounded-full bg-[#d9fdd3] text-[#075e54] shadow-sm"><MessageCircle className="h-5 w-5" /></span>
                    <p className="mt-3 font-display text-lg font-semibold text-[#34423c]">Sohbet yeni başlıyor</p>
                    <p className="mt-1 text-sm text-[#6a756f]">İlk mesajı gönderebilirsin.</p>
                  </div>
                ) : messages.map(item => {
                  const isMine = item.senderId === conversation.me.id;
                  const sender = isMine ? conversation.me : conversation.peer;
                  return (
                    <article key={item.id} className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
                      <div className={`flex max-w-[94%] items-end gap-1.5 sm:max-w-[84%] ${isMine ? "flex-row-reverse" : ""}`}>
                        <ParticipantAvatar participant={sender} size="h-7 w-7" />
                        <div className={`max-w-[90%] rounded-2xl px-3.5 py-2.5 shadow-sm ${isMine ? "rounded-br-md bg-[#d9fdd3] text-[#26342d]" : "rounded-bl-md bg-white text-[#313b36]"}`}>
                          <div className="mb-1 flex items-baseline justify-between gap-3">
                            <span className={`max-w-[14rem] truncate text-[0.7rem] font-bold ${isMine ? "text-[#075e54]" : "text-[#128c7e]"}`}>{item.username}</span>
                            <time className="shrink-0 text-[0.62rem] tabular-nums text-[#728078]">{formatTime(item.createdAt)}</time>
                            {isMine && !item.deletedAt && (
                              <button
                                type="button"
                                onClick={() => confirmDelete(item.id)}
                                disabled={deleteMessage.isPending}
                                aria-label="Kendi mesajını herkesten sil"
                                title="Mesajı herkesten sil"
                                className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-[#65766e] transition hover:bg-black/5 hover:text-[#9b4434] disabled:opacity-50"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                          {item.deletedAt ? (
                            <p className="text-sm italic text-[#68776f]">Bu mesaj silindi.</p>
                          ) : (
                            <>
                              {item.hasImage && <ChatImage conversationId={conversation.id} messageId={item.id} username={item.username} />}
                              {item.message && <p className="whitespace-pre-wrap break-words text-sm leading-relaxed">{item.message}</p>}
                            </>
                          )}
                          {isMine && !item.deletedAt && (
                            <p className="mt-1 flex items-center justify-end gap-1 text-[0.62rem] font-medium tabular-nums text-[#667b72]">
                              {conversation.peer.lastReadMessageId != null && conversation.peer.lastReadMessageId >= item.id
                                ? <><CheckCheck className="h-3 w-3 text-[#128c7e]" /> Görüldü</>
                                : "✓ Gönderildi"}
                            </p>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>

              <form onSubmit={submitMessage} className="border-t border-[#dce2de] bg-[#f0f2f5] px-3 py-3 sm:px-5">
                <label htmlFor="member-chat-message" className="sr-only">Sohbet mesajın</label>
                {attachmentData && (
                  <div className="mb-2 flex items-center gap-3 rounded-xl border border-[#d9dfdc] bg-white p-2">
                    <img src={attachmentData} alt="Gönderilecek görsel önizlemesi" className="h-14 w-14 rounded-lg object-cover" />
                    <span className="min-w-0 flex-1 truncate text-xs text-[#596861]">{attachmentName}</span>
                    <button
                      type="button"
                      onClick={() => { setAttachmentData(null); setAttachmentName(""); }}
                      aria-label="Ekli görseli kaldır"
                      className="grid h-8 w-8 place-items-center rounded-full text-[#65766e] hover:bg-[#f0f2f5] hover:text-[#9b4434]"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}
                <div className="flex items-end gap-2">
                  <label
                    title="Görsel ekle"
                    aria-label="Sohbete görsel ekle"
                    className={`grid h-11 w-11 shrink-0 cursor-pointer place-items-center rounded-full text-[#68776f] transition hover:bg-white hover:text-[#075e54] ${compressingAttachment ? "pointer-events-none opacity-50" : ""}`}
                  >
                    <input
                      ref={imageInputRef}
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      disabled={compressingAttachment || sendMessage.isPending}
                      onChange={event => { void selectImage(event.currentTarget.files?.[0]); }}
                    />
                    {compressingAttachment ? <LoaderCircle className="h-5 w-5 animate-spin" /> : <ImagePlus className="h-5 w-5" />}
                  </label>
                  <textarea
                    id="member-chat-message"
                    value={draft}
                    onChange={event => setDraft(event.target.value)}
                    onKeyDown={event => {
                      if (event.key === "Enter" && !event.shiftKey) {
                        event.preventDefault();
                        event.currentTarget.form?.requestSubmit();
                      }
                    }}
                    rows={2}
                    maxLength={500}
                    disabled={sendMessage.isPending || compressingAttachment}
                    placeholder="Mesaj yaz…"
                    className="min-h-12 flex-1 resize-y rounded-2xl border border-[#d9dfdc] bg-white px-4 py-3 text-sm text-[#303b35] outline-none placeholder:text-[#929d97] focus:border-[#128c7e]/50 focus:ring-2 focus:ring-[#128c7e]/10 disabled:opacity-60"
                  />
                  <Button type="submit" aria-label="Mesajı gönder" disabled={(!draft.trim() && !attachmentData) || sendMessage.isPending || compressingAttachment} className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-[#128c7e] p-0 text-white hover:bg-[#075e54]">
                    {sendMessage.isPending || compressingAttachment ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  </Button>
                </div>
                <div className="mt-2 flex min-h-5 items-center justify-between gap-4">
                  <p role="status" className="text-xs text-[#9b4434]">{sendError}</p>
                  <span className="ml-auto text-[0.68rem] tabular-nums text-[#87918b]">{draft.length}/500</span>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
