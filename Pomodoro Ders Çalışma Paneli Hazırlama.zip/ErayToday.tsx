import { useEffect, useState } from "react";
import { ArrowLeft, MessageCircle, Sparkles } from "lucide-react";
import { Link } from "wouter";
import MemberChat from "@/components/MemberChat";
import MemberLogoutButton from "@/components/MemberLogoutButton";

type PageSection = "empty" | "chat";

export default function ErayToday() {
  const [section, setSection] = useState<PageSection>(() => {
    const rawConversationId = new URLSearchParams(window.location.search).get("conversation");
    const conversationId = Number(rawConversationId);
    return rawConversationId && Number.isSafeInteger(conversationId) && conversationId > 0 ? "chat" : "empty";
  });

  useEffect(() => {
    document.title = "Sohbet — Odak Paneli";
    return () => {
      document.title = "Odak Paneli — Pomodoro Çalışma Saati";
    };
  }, []);

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#f4e6cd] text-[#3e352b]">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-32 -left-24 h-[28rem] w-[28rem] rounded-full bg-[#f4a885]/65 blur-[90px]" />
        <div className="absolute top-[16%] -right-24 h-[26rem] w-[26rem] rounded-full bg-[#91b6cf]/65 blur-[100px]" />
        <div className="absolute -bottom-40 left-[28%] h-[32rem] w-[32rem] rounded-full bg-[#d7a6c7]/55 blur-[105px]" />
        <div className="absolute right-[22%] bottom-[-11rem] h-[25rem] w-[25rem] rounded-full bg-[#e9cb78]/55 blur-[90px]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(255,251,240,0.42),transparent_72%)]" />
      </div>

      <div className="relative z-10 mx-auto min-h-screen w-full max-w-6xl px-4 sm:px-6">
        <header className="flex items-center justify-between border-b border-[rgba(90,66,34,0.22)] py-5">
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-sm border border-[rgba(90,66,34,0.25)] bg-white/45 px-3 py-2 text-sm font-semibold text-[#514538] backdrop-blur-sm transition hover:-translate-y-0.5 hover:bg-white/70"
          >
            <ArrowLeft className="h-4 w-4" /> Odak Paneli
          </Link>
          <div className="flex flex-wrap items-center justify-end gap-3">
            <span className="font-display text-xs font-semibold tracking-[0.18em] text-[#665746]/75 uppercase">
              Renkli not defteri
            </span>
            <MemberLogoutButton />
          </div>
        </header>

        <nav aria-label="Sohbet seçenekleri" className="mt-5 flex flex-wrap items-center gap-3">
          <button
            type="button"
            aria-pressed={section === "chat"}
            onClick={() => setSection(current => current === "chat" ? "empty" : "chat")}
            className={`inline-flex h-10 items-center gap-2 rounded-xl border px-4 text-xs font-bold tracking-[0.16em] transition hover:-translate-y-0.5 ${
              section === "chat"
                ? "border-[#8c422d] bg-[#a75238] text-white shadow-md"
                : "border-white/70 bg-white/55 text-[#86462f] shadow-sm hover:bg-white/80"
            }`}
          >
            <MessageCircle className="h-4 w-4" /> Sohbet
          </button>
        </nav>

        {section === "chat" ? (
          <MemberChat />
        ) : (
          <section className="mx-auto mt-[7vh] max-w-3xl pb-16">
            <div className="relative overflow-hidden rounded-[2rem] border border-white/60 bg-white/40 px-6 py-14 text-center shadow-[0_24px_80px_rgba(83,62,42,0.12)] backdrop-blur-xl sm:px-14 sm:py-20">
              <span aria-hidden="true" className="absolute top-7 left-8 h-4 w-4 rounded-full bg-[#e99b77]/80 shadow-[22px_8px_0_#e6ca73,44px_-2px_0_#91b6cf]" />
              <span aria-hidden="true" className="absolute right-9 bottom-8 h-6 w-6 rounded-full bg-[#a5bd91]/75 shadow-[-22px_-10px_0_#d7a6c7,-43px_2px_0_#e99b77]" />
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-white/70 bg-white/50 text-[#a9634b] shadow-sm">
                <Sparkles className="h-5 w-5" />
              </div>
              <p className="mt-6 text-[0.68rem] font-semibold tracking-[0.22em] text-[#8a7056] uppercase">
                Özel sohbet
              </p>
              <h1 className="mt-3 font-display text-3xl leading-tight font-bold text-[#3e352b] sm:text-5xl">
                Sohbet
              </h1>
              <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-[#685c4e] sm:text-base">
                Sohbeti açmak için yukarıdaki Sohbet düğmesine bas.
              </p>
            </div>
          </section>
        )}
      </div>
    </main>
  );
}
