export function formatClock(totalSeconds: number): string {
  const safe = Math.max(0, Math.round(totalSeconds));
  const hours = Math.floor(safe / 3600);
  const minutes = Math.floor((safe % 3600) / 60);
  const seconds = safe % 60;
  const mm = String(minutes).padStart(2, "0");
  const ss = String(seconds).padStart(2, "0");
  return hours > 0 ? `${hours}:${mm}:${ss}` : `${mm}:${ss}`;
}

export function formatMinutes(seconds: number): string {
  const total = Math.round(seconds / 60);
  if (total < 60) return `${total} dk`;
  const hours = Math.floor(total / 60);
  const rest = total % 60;
  return rest === 0 ? `${hours} sa` : `${hours} sa ${rest} dk`;
}

export function dayKey(date: Date | number = new Date()): string {
  const d = typeof date === "number" ? new Date(date) : date;
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function todayKey(): string {
  return dayKey(new Date());
}

const timeFmt = new Intl.DateTimeFormat("tr-TR", { hour: "2-digit", minute: "2-digit" });
const weekdayFmt = new Intl.DateTimeFormat("tr-TR", { weekday: "short" });
const longDateFmt = new Intl.DateTimeFormat("tr-TR", {
  day: "numeric",
  month: "long",
  weekday: "long",
});

export function formatTime(ts: number): string {
  return timeFmt.format(new Date(ts));
}

export function formatWeekday(date: Date): string {
  return weekdayFmt.format(date).replace(".", "");
}

export function formatLongDate(date: Date = new Date()): string {
  const text = longDateFmt.format(date);
  return text.charAt(0).toUpperCase() + text.slice(1);
}

export function addDays(date: Date, days: number): Date {
  const copy = new Date(date);
  copy.setDate(copy.getDate() + days);
  return copy;
}
