import {
  createContext,
  createElement,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

import {
  getIstanbulDayKey,
  includeManualStudyFocusHistory,
  reconcilePomodoroFocusHistory,
  reconcilePomodoroSessionHistory,
  sanitizeStudyEntries,
  sanitizeStudySelection,
  shiftIstanbulDayKey,
  type StudyEntry,
  type StudySelection,
} from "@shared/studyTracking";
import {
  currentPermission,
  requestPermission,
  showNotification,
} from "@/lib/pomodoro/notifications";
import { playChime, playTick, primeAudio } from "@/lib/pomodoro/sound";
import {
  KEYS,
  MAX_SESSIONS,
  loadActiveTaskId,
  loadHistory,
  loadSessions,
  loadStudyEntries,
  loadSettings,
  loadTasks,
  loadTimer,
  readJson,
  writeJson,
} from "@/lib/pomodoro/storage";
import {
  DEFAULT_TIMER,
  LIMITS,
  PHASE_META,
  clampInt,
  durationOf,
  newId,
  type DayTotals,
  type Phase,
  type SessionRecord,
  type Settings,
  type Task,
  type TimerState,
} from "@/lib/pomodoro/types";

export interface DayBar {
  key: string;
  label: string;
  focusSeconds: number;
  pomodoros: number;
  isToday: boolean;
}

export interface TodayStats {
  pomodoros: number;
  focusSeconds: number;
  goal: number;
  ratio: number;
  streak: number;
}

export interface WeekBar {
  key: string;
  label: string;
  focusSeconds: number;
  pomodoros: number;
  isCurrentWeek: boolean;
}

function findSessionForEntry(entry: StudyEntry, sessions: SessionRecord[]) {
  if (entry.source !== "pomodoro") return undefined;
  if (entry.sessionId)
    return sessions.find(session => session.id === entry.sessionId && session.phase === "focus");
  return sessions.find(session => session.phase === "focus" && session.endedAt === entry.endedAt);
}

function findEntryForSession(session: SessionRecord, entries: StudyEntry[]) {
  return entries.find(entry => entry.source === "pomodoro" && entry.sessionId === session.id)
    ?? entries.find(entry => entry.source === "pomodoro" && !entry.sessionId && entry.endedAt === session.endedAt);
}

/**
 * Owns the whole Pomodoro machine: phase transitions, wall-clock accurate
 * countdown, tasks, session log and daily totals. Everything is mirrored to
 * localStorage so a reload (or a closed tab) resumes where it left off.
 */
function usePomodoroController() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [tasks, setTasks] = useState<Task[]>(loadTasks);
  const [activeTaskId, setActiveTaskId] = useState<string | null>(() =>
    loadActiveTaskId(loadTasks())
  );
  const [timer, setTimer] = useState<TimerState>(() =>
    loadTimer(loadSettings())
  );
  const [sessions, setSessions] = useState<SessionRecord[]>(loadSessions);
  const [history, setHistory] =
    useState<Record<string, DayTotals>>(loadHistory);
  const [studyEntries, setStudyEntries] =
    useState<StudyEntry[]>(loadStudyEntries);
  const [now, setNow] = useState<number>(() => Date.now());
  const [permission, setPermission] =
    useState<NotificationPermission>(currentPermission);
  const [finishedPhase, setFinishedPhase] = useState<{
    phase: Phase;
    at: number;
  } | null>(null);

  const handledEndRef = useRef<number | null>(null);

  /* ---------------------------------------------------------------- persist */

  useEffect(() => writeJson(KEYS.settings, settings), [settings]);
  useEffect(() => writeJson(KEYS.tasks, tasks), [tasks]);
  useEffect(() => writeJson(KEYS.activeTaskId, activeTaskId), [activeTaskId]);
  useEffect(() => writeJson(KEYS.timer, timer), [timer]);
  useEffect(
    () => writeJson(KEYS.sessions, sessions.slice(0, MAX_SESSIONS)),
    [sessions]
  );
  useEffect(() => writeJson(KEYS.history, history), [history]);
  useEffect(() => writeJson(KEYS.studyEntries, studyEntries), [studyEntries]);

  /* ------------------------------------------------------------------- tick */

  useEffect(() => {
    if (!timer.running) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [timer.running]);

  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === "visible") setNow(Date.now());
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);
    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
    };
  }, []);

  /* ------------------------------------------------------------- derivation */

  const totalSec = durationOf(timer.phase, settings);

  const remainingSec =
    timer.running && timer.endAt !== null
      ? Math.max(0, Math.ceil((timer.endAt - now) / 1000))
      : Math.min(timer.remainingSec, totalSec);

  const elapsedSec = Math.max(0, Math.min(totalSec, totalSec - remainingSec));
  const progress = totalSec > 0 ? elapsedSec / totalSec : 0;
  const activeTask = useMemo(
    () => tasks.find(t => t.id === activeTaskId && !t.done) ?? null,
    [tasks, activeTaskId]
  );

  /* ------------------------------------------------------------- phase move */

  const endPhase = useCallback(
    (reason: "natural" | "skip" | "switch", at: number, forced?: Phase) => {
      const phase = timer.phase;
      const planned = durationOf(phase, settings);
      const liveRemaining =
        timer.running && timer.endAt !== null
          ? Math.max(0, Math.ceil((timer.endAt - at) / 1000))
          : timer.remainingSec;
      const completed = reason === "natural";
      const counted = completed
        ? planned
        : clampInt(planned - liveRemaining, 0, planned);

      if (phase === "focus" && counted >= 60) {
        const sessionId = newId();
        const record: SessionRecord = {
          id: sessionId,
          phase: "focus",
          taskId: activeTask?.id ?? null,
          taskTitle: activeTask?.title ?? "Serbest çalışma",
          startedAt: timer.startedAt ?? at - counted * 1000,
          endedAt: at,
          plannedSec: planned,
          actualSec: counted,
          completed,
        };
        setSessions(prev => [record, ...prev].slice(0, MAX_SESSIONS));
        if (timer.studySelection) {
          const startedAt = timer.startedAt ?? at - counted * 1000;
          const studyEntry: StudyEntry = {
            id: newId(),
            source: "pomodoro",
            sessionId,
            ...timer.studySelection,
            seconds: counted,
            dayKey: getIstanbulDayKey(at),
            startedAt,
            endedAt: at,
          };
          setStudyEntries(prev => sanitizeStudyEntries([studyEntry, ...prev]));
        }
        const key = getIstanbulDayKey(at);
        setHistory(prev => {
          const current = prev[key] ?? { pomodoros: 0, focusSeconds: 0 };
          return {
            ...prev,
            [key]: {
              pomodoros: current.pomodoros + (completed ? 1 : 0),
              focusSeconds: current.focusSeconds + counted,
            },
          };
        });
        if (completed && activeTask) {
          setTasks(prev =>
            prev.map(t =>
              t.id === activeTask.id ? { ...t, completed: t.completed + 1 } : t
            )
          );
        }
      }

      if (completed) {
        setFinishedPhase({ phase, at });
        if (settings.soundEnabled)
          playChime(phase === "focus" ? "focusEnd" : "breakEnd");
        if (settings.notifyEnabled) {
          showNotification(
            phase === "focus"
              ? "Odak bitti — molaya geç"
              : "Mola bitti — masaya dön",
            phase === "focus"
              ? `${counted / 60} dakikalık tur tamamlandı.`
              : "Yeni pomodoro seni bekliyor."
          );
        }
      }

      let nextPhase: Phase;
      let cycle = timer.cycle;
      if (forced) {
        nextPhase = forced;
      } else if (phase === "focus") {
        if (completed) cycle = timer.cycle + 1;
        nextPhase =
          completed && cycle % settings.longBreakInterval === 0
            ? "long"
            : "short";
      } else {
        nextPhase = "focus";
        if (phase === "long") cycle = 0;
      }

      const nextTotal = durationOf(nextPhase, settings);
      const autoStart =
        completed &&
        settings.autoStartNext &&
        (nextPhase !== "focus" || timer.studySelection !== null);

      handledEndRef.current = null;
      setTimer({
        phase: nextPhase,
        running: autoStart,
        endAt: autoStart ? at + nextTotal * 1000 : null,
        remainingSec: nextTotal,
        startedAt: autoStart ? at : null,
        cycle,
        studySelection: timer.studySelection,
      });
      if (!autoStart) setNow(at);
    },
    [activeTask, settings, timer]
  );

  // Fire the transition the moment the deadline passes (also catches up on a
  // background tab that was throttled or a reload that happened after the end).
  useEffect(() => {
    if (!timer.running || timer.endAt === null) return;
    if (now < timer.endAt) return;
    if (handledEndRef.current === timer.endAt) return;
    handledEndRef.current = timer.endAt;
    endPhase("natural", timer.endAt);
  }, [endPhase, now, timer]);

  /* ---------------------------------------------------------------- controls */

  const start = useCallback(() => {
    if (timer.phase === "focus" && !timer.studySelection) return;
    primeAudio();
    setTimer(prev => {
      if (prev.running) return prev;
      const planned = durationOf(prev.phase, settings);
      const rest =
        prev.remainingSec > 0 && prev.remainingSec <= planned
          ? prev.remainingSec
          : planned;
      return {
        ...prev,
        running: true,
        endAt: Date.now() + rest * 1000,
        remainingSec: rest,
        startedAt: prev.startedAt ?? Date.now(),
      };
    });
    handledEndRef.current = null;
    setNow(Date.now());
  }, [settings, timer.phase, timer.studySelection]);

  const pause = useCallback(() => {
    setTimer(prev => {
      if (!prev.running || prev.endAt === null) return prev;
      const rest = Math.max(0, Math.ceil((prev.endAt - Date.now()) / 1000));
      return { ...prev, running: false, endAt: null, remainingSec: rest };
    });
  }, []);

  const toggle = useCallback(() => {
    if (timer.running) pause();
    else start();
  }, [pause, start, timer.running]);

  const reset = useCallback(() => {
    const at = Date.now();
    const plannedSeconds = durationOf(timer.phase, settings);
    const liveRemaining =
      timer.running && timer.endAt !== null
        ? Math.max(0, Math.ceil((timer.endAt - at) / 1000))
        : timer.remainingSec;
    const counted = clampInt(plannedSeconds - liveRemaining, 0, plannedSeconds);
    if (timer.phase === "focus" && counted >= 60 && timer.studySelection) {
      const startedAt = timer.startedAt ?? at - counted * 1000;
      const studyEntry: StudyEntry = {
        id: newId(),
        source: "pomodoro",
        ...timer.studySelection,
        seconds: counted,
        dayKey: getIstanbulDayKey(at),
        startedAt,
        endedAt: at,
      };
      setStudyEntries(prev => sanitizeStudyEntries([studyEntry, ...prev]));
    }
    setTimer(prev => {
      const planned = durationOf(prev.phase, settings);
      return {
        ...DEFAULT_TIMER,
        phase: prev.phase,
        cycle: prev.cycle,
        remainingSec: planned,
        studySelection: prev.studySelection,
      };
    });
    handledEndRef.current = null;
    setNow(at);
  }, [settings, timer]);

  const skip = useCallback(() => {
    endPhase("skip", Date.now());
  }, [endPhase]);

  const switchPhase = useCallback(
    (phase: Phase) => {
      if (phase === timer.phase) return;
      playTick();
      endPhase("switch", Date.now(), phase);
    },
    [endPhase, timer.phase]
  );

  /* ------------------------------------------------------------------ tasks */

  const addTask = useCallback((title: string, estimate: number) => {
    const clean = title.trim().slice(0, 80);
    if (!clean) return false;
    const task: Task = {
      id: newId(),
      title: clean,
      estimate: clampInt(estimate, LIMITS.estimate.min, LIMITS.estimate.max),
      done: false,
      completed: 0,
      createdAt: Date.now(),
    };
    setTasks(prev => [task, ...prev]);
    setActiveTaskId(current => current ?? task.id);
    return true;
  }, []);

  const removeTask = useCallback((id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    setActiveTaskId(current => (current === id ? null : current));
  }, []);

  const toggleTaskDone = useCallback((id: string) => {
    setTasks(prev =>
      prev.map(t => (t.id === id ? { ...t, done: !t.done } : t))
    );
    setActiveTaskId(current => (current === id ? null : current));
  }, []);

  /** Marks a task finished and hands the spotlight to the next unfinished one. */
  const finishTask = useCallback(
    (id: string) => {
      setTasks(prev => prev.map(t => (t.id === id ? { ...t, done: true } : t)));
      const remaining = tasks.filter(t => !t.done && t.id !== id);
      setActiveTaskId(remaining.length ? remaining[0].id : null);
      playTick();
      return remaining.length;
    },
    [tasks]
  );

  const finishActiveTask = useCallback(() => {
    if (!activeTask) return null;
    const left = finishTask(activeTask.id);
    return { title: activeTask.title, left };
  }, [activeTask, finishTask]);

  const nextTask = useCallback(() => {
    const pending = tasks.filter(t => !t.done);
    if (pending.length === 0) return null;
    const index = pending.findIndex(t => t.id === activeTaskId);
    const next = pending[(index + 1) % pending.length];
    setActiveTaskId(next.id);
    primeAudio();
    return next;
  }, [activeTaskId, tasks]);

  const selectTask = useCallback((id: string | null) => {
    setActiveTaskId(id);
    primeAudio();
  }, []);

  const setStudySelection = useCallback(
    (selection: StudySelection | null) => {
      const cleanSelection = sanitizeStudySelection(selection);
      setTimer(prev => {
        const planned = durationOf(prev.phase, settings);
        const focusSessionInProgress =
          prev.phase === "focus" &&
          (prev.running ||
            prev.startedAt !== null ||
            prev.remainingSec < planned);
        return focusSessionInProgress
          ? prev
          : { ...prev, studySelection: cleanSelection };
      });
    },
    [settings]
  );

  const addStudyEntry = useCallback((entry: StudyEntry) => {
    setStudyEntries(prev => sanitizeStudyEntries([entry, ...prev]));
  }, []);

  const updateStudyEntry = useCallback(
    (id: string, patch: Partial<StudyEntry>) => {
      const previous = studyEntries.find(entry => entry.id === id);
      if (!previous) return;
      const linkedSession = findSessionForEntry(previous, sessions);
      const updatedEntries = sanitizeStudyEntries(
        studyEntries.map(entry => {
          if (entry.id !== id) return entry;
          return {
            ...entry,
            ...patch,
            id: entry.id,
            ...(linkedSession ? { sessionId: linkedSession.id } : {}),
          };
        }),
      );
      const next = updatedEntries.find(entry => entry.id === id);
      if (!next) return;
      setStudyEntries(updatedEntries);
      if (linkedSession) {
        const updatedSession: SessionRecord = {
          ...linkedSession,
          actualSec: next.seconds,
          startedAt: next.startedAt,
          endedAt: next.endedAt,
        };
        setSessions(current => current.map(session => session.id === linkedSession.id ? updatedSession : session));
        setHistory(history => reconcilePomodoroSessionHistory(history, linkedSession, updatedSession));
      } else {
        setHistory(history => reconcilePomodoroFocusHistory(history, previous, next));
      }
    },
    [sessions, studyEntries]
  );

  const deleteStudyEntry = useCallback(
    (id: string) => {
      const deleted = studyEntries.find(entry => entry.id === id);
      if (!deleted) return;
      const linkedSession = findSessionForEntry(deleted, sessions);
      setStudyEntries(prev => prev.filter(entry => entry.id !== id));
      if (linkedSession) {
        setSessions(current => current.filter(session => session.id !== linkedSession.id));
        setHistory(history => reconcilePomodoroSessionHistory(history, linkedSession, null));
      } else {
        setHistory(history => reconcilePomodoroFocusHistory(history, deleted, null));
      }
    },
    [sessions, studyEntries]
  );

  const updateFocusSession = useCallback(
    (id: string, actualSec: number) => {
      const previous = sessions.find(session => session.id === id && session.phase === "focus");
      if (!previous) return;
      const nextSeconds = clampInt(actualSec, 60, 86_400);
      if (nextSeconds === previous.actualSec) return;
      const updated: SessionRecord = {
        ...previous,
        actualSec: nextSeconds,
        startedAt: previous.endedAt - nextSeconds * 1000,
      };
      const linkedEntry = findEntryForSession(previous, studyEntries);
      setSessions(current => current.map(session => session.id === id ? updated : session));
      if (linkedEntry) {
        setStudyEntries(current => sanitizeStudyEntries(current.map(entry => entry.id === linkedEntry.id
          ? { ...entry, sessionId: previous.id, seconds: nextSeconds, startedAt: updated.startedAt }
          : entry)));
      }
      setHistory(history => reconcilePomodoroSessionHistory(history, previous, updated));
    },
    [sessions, studyEntries],
  );

  const deleteFocusSession = useCallback(
    (id: string) => {
      const deleted = sessions.find(session => session.id === id && session.phase === "focus");
      if (!deleted) return;
      const linkedEntry = findEntryForSession(deleted, studyEntries);
      setSessions(current => current.filter(session => session.id !== id));
      if (linkedEntry) setStudyEntries(current => current.filter(entry => entry.id !== linkedEntry.id));
      setHistory(history => reconcilePomodoroSessionHistory(history, deleted, null));
    },
    [sessions, studyEntries],
  );

  /* --------------------------------------------------------------- settings */

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings(prev => {
      const next = { ...prev, ...patch };
      next.focusMin = clampInt(
        next.focusMin,
        LIMITS.minutes.min,
        LIMITS.minutes.max
      );
      next.shortMin = clampInt(
        next.shortMin,
        LIMITS.minutes.min,
        LIMITS.minutes.max
      );
      next.longMin = clampInt(
        next.longMin,
        LIMITS.minutes.min,
        LIMITS.minutes.max
      );
      next.longBreakInterval = clampInt(
        next.longBreakInterval,
        LIMITS.interval.min,
        LIMITS.interval.max
      );
      next.dailyGoal = clampInt(
        next.dailyGoal,
        LIMITS.goal.min,
        LIMITS.goal.max
      );
      return next;
    });
  }, []);

  // A never-started clock follows duration edits; a running or paused one keeps its progress.
  const previousSettingsRef = useRef(settings);
  useEffect(() => {
    const previous = previousSettingsRef.current;
    previousSettingsRef.current = settings;
    setTimer(current => {
      if (current.running || current.startedAt !== null) return current;
      const untouched =
        current.remainingSec === durationOf(current.phase, previous);
      const updated = durationOf(current.phase, settings);
      return untouched && current.remainingSec !== updated
        ? { ...current, remainingSec: updated }
        : current;
    });
  }, [settings]);

  const enableNotifications = useCallback(async () => {
    const result = await requestPermission();
    setPermission(result);
    updateSettings({ notifyEnabled: result === "granted" });
    return result;
  }, [updateSettings]);

  /* ------------------------------------------------------------------ stats */

  const focusHistory = useMemo(
    () => includeManualStudyFocusHistory(history, studyEntries),
    [history, studyEntries]
  );

  const stats: TodayStats = useMemo(() => {
    const key = getIstanbulDayKey();
    const today = focusHistory[key] ?? { pomodoros: 0, focusSeconds: 0 };
    let streak = 0;
    let cursor = today.pomodoros === 0 ? shiftIstanbulDayKey(key, -1) : key;
    for (;;) {
      const entry = history[cursor];
      if (entry && entry.pomodoros > 0) {
        streak += 1;
        cursor = shiftIstanbulDayKey(cursor, -1);
      } else break;
      if (streak > 400) break;
    }
    return {
      pomodoros: today.pomodoros,
      focusSeconds: today.focusSeconds,
      goal: settings.dailyGoal,
      ratio:
        settings.dailyGoal > 0
          ? Math.min(1, today.pomodoros / settings.dailyGoal)
          : 0,
      streak,
    };
  }, [focusHistory, history, settings.dailyGoal]);

  const week: DayBar[] = useMemo(() => {
    const bars: DayBar[] = [];
    const today = getIstanbulDayKey();
    const weekdayFormat = new Intl.DateTimeFormat("tr-TR", {
      weekday: "short",
      timeZone: "UTC",
    });
    for (let offset = 6; offset >= 0; offset -= 1) {
      const key = shiftIstanbulDayKey(today, -offset);
      const [year, month, day] = key.split("-").map(Number);
      const date = new Date(Date.UTC(year, month - 1, day, 12));
      const entry = focusHistory[key] ?? { pomodoros: 0, focusSeconds: 0 };
      bars.push({
        key,
        label: weekdayFormat.format(date).replace(/\.$/, ""),
        focusSeconds: entry.focusSeconds,
        pomodoros: entry.pomodoros,
        isToday: offset === 0,
      });
    }
    return bars;
  }, [focusHistory]);

  const weeks: WeekBar[] = useMemo(() => {
    const todayKey = getIstanbulDayKey();
    const todayDate = new Date(`${todayKey}T12:00:00.000Z`);
    const currentMondayKey = shiftIstanbulDayKey(
      todayKey,
      -((todayDate.getUTCDay() + 6) % 7)
    );
    const ranges: WeekBar[] = [];
    const dateLabel = new Intl.DateTimeFormat("tr-TR", {
      day: "numeric",
      month: "short",
      timeZone: "UTC",
    });

    for (let offset = 3; offset >= 0; offset -= 1) {
      const startKey = shiftIstanbulDayKey(currentMondayKey, -offset * 7);
      let focusSeconds = 0;
      let pomodoros = 0;
      for (let dayOffset = 0; dayOffset < 7; dayOffset += 1) {
        const key = shiftIstanbulDayKey(startKey, dayOffset);
        const totals = focusHistory[key];
        focusSeconds += totals?.focusSeconds ?? 0;
        pomodoros += totals?.pomodoros ?? 0;
      }
      const endKey = shiftIstanbulDayKey(startKey, 6);
      ranges.push({
        key: startKey,
        label: `${dateLabel.format(new Date(`${startKey}T12:00:00.000Z`))}–${dateLabel.format(new Date(`${endKey}T12:00:00.000Z`))}`,
        focusSeconds,
        pomodoros,
        isCurrentWeek: offset === 0,
      });
    }
    return ranges;
  }, [focusHistory]);

  const recentSessions = useMemo(
    () => sessions.filter(s => s.phase === "focus").slice(0, 12),
    [sessions]
  );
  const todayFocusSessions = useMemo(() => {
    const today = getIstanbulDayKey(Date.now());
    return sessions.filter(session => session.phase === "focus" && getIstanbulDayKey(session.endedAt) === today);
  }, [sessions]);

  return {
    settings,
    updateSettings,
    enableNotifications,
    permission,

    phase: timer.phase,
    running: timer.running,
    remainingSec,
    totalSec,
    progress,
    cycle: timer.cycle,

    start,
    pause,
    toggle,
    reset,
    skip,
    switchPhase,
    studySelection: timer.studySelection,
    setStudySelection,
    studyEntries,
    addStudyEntry,
    updateStudyEntry,
    deleteStudyEntry,
    todayFocusSessions,
    updateFocusSession,
    deleteFocusSession,

    tasks,
    activeTask,
    addTask,
    removeTask,
    toggleTaskDone,
    finishTask,
    finishActiveTask,
    nextTask,
    selectTask,

    stats,
    week,
    weeks,
    recentSessions,
    phaseMeta: PHASE_META[timer.phase],
    finishedPhase,
    clearFinished: useCallback(() => setFinishedPhase(null), []),
  };
}

export type PomodoroApi = ReturnType<typeof usePomodoroController>;
export type PomodoroStatus = Pick<PomodoroApi, "phase" | "running">;

const PomodoroContext = createContext<PomodoroApi | null>(null);
const PomodoroStatusContext = createContext<PomodoroStatus | null>(null);

export function PomodoroProvider({ children }: { children: ReactNode }) {
  const controller = usePomodoroController();
  const [externalStatus, setExternalStatus] = useState<PomodoroStatus | null>(
    null
  );
  const status = useMemo(
    () => ({
      phase: controller.phase,
      running: controller.running,
    }),
    [controller.phase, controller.running]
  );

  // Only mirror phase/running for display across tabs. Never hydrate the
  // controller from a storage event: each tab remains the sole timer owner.
  useEffect(() => {
    setExternalStatus(null);
  }, [controller.phase, controller.running]);

  useEffect(() => {
    const readStatus = (): PomodoroStatus | null => {
      const stored = readJson<Partial<TimerState>>(KEYS.timer);
      if (!stored || !["focus", "short", "long"].includes(String(stored.phase)))
        return null;
      return {
        phase: stored.phase as Phase,
        running:
          stored.running === true &&
          typeof stored.endAt === "number" &&
          stored.endAt > Date.now(),
      };
    };
    const sync = () => {
      const next = readStatus();
      if (!next) return;
      setExternalStatus(current =>
        current?.phase === next.phase && current.running === next.running
          ? current
          : next
      );
    };
    const onStorage = (event: StorageEvent) => {
      if (event.key === KEYS.timer) sync();
    };
    const onVisible = () => {
      if (document.visibilityState === "visible") sync();
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener("focus", sync);
    document.addEventListener("visibilitychange", onVisible);
    sync();
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("focus", sync);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);

  const displayStatus = externalStatus ?? status;
  return createElement(
    PomodoroStatusContext.Provider,
    { value: displayStatus },
    createElement(PomodoroContext.Provider, { value: controller }, children)
  );
}

export function usePomodoro(): PomodoroApi {
  const controller = useContext(PomodoroContext);
  if (!controller)
    throw new Error("usePomodoro, PomodoroProvider içinde kullanılmalıdır.");
  return controller;
}

export function usePomodoroStatus(): PomodoroStatus {
  const status = useContext(PomodoroStatusContext);
  if (!status)
    throw new Error(
      "usePomodoroStatus, PomodoroProvider içinde kullanılmalıdır."
    );
  return status;
}
